// Versão para SERVIDOR DEDICADO (BDS): tem acesso à internet via
// @minecraft/server-net, então os logs conseguem ir pro webhook do Discord.
import { http, HttpRequest, HttpRequestMethod, HttpHeader } from "@minecraft/server-net";

export const webhookSuportado = true;

export async function enviarWebhook(url, payload) {
	const req = new HttpRequest(url);
	req.method = HttpRequestMethod.Post;
	req.headers = [new HttpHeader("Content-Type", "application/json")];
	req.body = JSON.stringify(payload);
	req.timeout = 10;
	const res = await http.request(req);
	return { status: res.status, body: res.body };
}
