import { MessageFormData } from "@minecraft/server-ui";
import { teleportarComContagem } from "./teleportCountdown.js";
import { getPermissoes } from "./rank.js";
import { emCooldown } from "./cooldown.js";
import { estaEmCombate } from "./combatLog.js";

const TAG_TP_DESLIGADO = "re_tp_off";

// alvoId -> { remetente, direcao }. Guarda o pedido ate ser respondido
// com !teleporte aceitar ou !teleporte recusar.
const pendentes = new Map();

export function ativarTp(player) {
	if (!player.hasTag(TAG_TP_DESLIGADO)) {
		player.sendMessage("§eSeus pedidos de teleporte ja estavam ativados.");
		return;
	}
	player.removeTag(TAG_TP_DESLIGADO);
	player.sendMessage("§aPedidos de teleporte reativados.");
}

export function desativarTp(player) {
	if (player.hasTag(TAG_TP_DESLIGADO)) {
		player.sendMessage("§eSeus pedidos de teleporte ja estavam desativados.");
		return;
	}
	player.addTag(TAG_TP_DESLIGADO);
	player.sendMessage("§cPedidos de teleporte desativados. Use §e!teleportar ligar§c para reativar.");
}

// direcao "ate_ele": remetente teleporta ate o alvo.
// direcao "ate_mim": alvo teleporta ate o remetente.
export function pedirTeleport(remetente, alvo, direcao) {
	if (estaEmCombate(remetente)) {
		remetente.sendMessage("§cVoce nao pode pedir teleporte enquanto estiver em combate!");
		return;
	}

	const cooldownId = direcao === "ate_ele" ? "cooldownTpaAteEle" : "cooldownTpaAteMim";
	const cooldownSegundos = getPermissoes(remetente)[cooldownId];
	if (emCooldown(remetente, `tpa_${direcao}`, cooldownSegundos)) return;

	if (remetente.hasTag(TAG_TP_DESLIGADO)) {
		remetente.sendMessage("§cVoce desativou seus pedidos de teleporte. Use §e!teleportar ligar§c para reativar.");
		return;
	}
	if (alvo.hasTag(TAG_TP_DESLIGADO)) {
		remetente.sendMessage(`§c${alvo.name} desativou os pedidos de teleporte.`);
		return;
	}

	// Formulario na tela (com botoes Aceitar/Recusar) + uma mensagem de chat
	// simples avisando, so isso - sem actionbar e sem bordas.
	const corpo =
		direcao === "ate_ele"
			? `§e${remetente.name}§r quer se teleportar até você.`
			: `§e${remetente.name}§r está pedindo pra você se teleportar até ele.`;

	try {
		alvo.sendMessage(corpo);
	} catch (erro) {
		remetente.sendMessage("§cEsse jogador nao esta mais online.");
		console.warn(`Erro ao avisar alvo do pedido de teleporte: ${erro}`);
		return;
	}

	remetente.sendMessage(`§aVoce enviou solicitacao de teleporte para §e${alvo.name}§a.`);
	pendentes.set(alvo.id, { remetente, direcao });

	const form = new MessageFormData().title("Pedido de Teleporte").body(corpo).button1("Aceitar").button2("Recusar");

	form
		.show(alvo)
		.then((res) => {
			// Se fechou sem escolher, o pedido continua pendente pra
			// responder depois com !teleporte aceitar / !teleporte recusar.
			if (res.canceled) return;

			// So processa se o pedido ainda for esse mesmo (nao foi
			// respondido antes pelo comando, por exemplo).
			const aindaPendente = pendentes.get(alvo.id);
			if (!aindaPendente || aindaPendente.remetente !== remetente) return;
			pendentes.delete(alvo.id);

			if (res.selection === 1) {
				try {
					remetente.sendMessage(`§c${alvo.name} recusou o pedido de teleporte.`);
				} catch (erro) {
					console.warn(`Erro ao avisar remetente da recusa: ${erro}`);
				}
				return;
			}

			processarAceite(remetente, alvo, direcao);
		})
		.catch((erro) => {
			console.warn(`Erro ao mostrar formulario de pedido de teleporte: ${erro}`);
		});
}

function processarAceite(remetente, alvo, direcao) {
	const origem = direcao === "ate_ele" ? remetente : alvo;
	const destino = direcao === "ate_ele" ? alvo : remetente;

	try {
		remetente.sendMessage("§aPedido de teleporte aceito!");
		alvo.sendMessage("§aVoce aceitou o pedido de teleporte.");
	} catch (erro) {
		console.warn(`Erro ao avisar aceite do teleporte: ${erro}`);
	}

	teleportarComContagem(
		origem,
		() => {
			try {
				origem.teleport(
					{ x: destino.location.x, y: destino.location.y, z: destino.location.z },
					{ dimension: destino.dimension }
				);
				origem.sendMessage("§aVoce foi teleportado com sucesso!");
				destino.sendMessage(`§a§e${origem.name}§a chegou ate voce.`);
			} catch (erro) {
				console.warn(`Erro ao executar teleporte de pedido: ${erro}`);
				try {
					remetente.sendMessage("§cAlgo deu errado ao teleportar. Tente novamente.");
				} catch (erro2) {
					console.warn(`Erro ao avisar remetente do erro: ${erro2}`);
				}
			}
		},
		destino
	);
}

export function aceitarTeleportPendente(alvo) {
	const pendente = pendentes.get(alvo.id);
	if (!pendente) {
		alvo.sendMessage("§cVoce nao tem nenhum pedido de teleporte pendente.");
		return;
	}
	pendentes.delete(alvo.id);
	processarAceite(pendente.remetente, alvo, pendente.direcao);
}

export function recusarTeleportPendente(alvo) {
	const pendente = pendentes.get(alvo.id);
	if (!pendente) {
		alvo.sendMessage("§cVoce nao tem nenhum pedido de teleporte pendente.");
		return;
	}
	pendentes.delete(alvo.id);
	try {
		pendente.remetente.sendMessage(`§c${alvo.name} recusou o pedido de teleporte.`);
	} catch (erro) {
		console.warn(`Erro ao avisar remetente da recusa por comando: ${erro}`);
	}
	alvo.sendMessage("§eVoce recusou o pedido de teleporte.");
}
