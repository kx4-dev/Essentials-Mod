// Knockback de PvP, projéteis e Launch Pad (placa de pressão de ouro).
// Baseado no addon "Event knockback" (steep qd u), reescrito e integrado ao
// Painel Admin: tudo liga/desliga e se configura por menu.
import { world, system } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { pvpBloqueadoEntre } from "./protectedArea.js";
import { isCongelado } from "./moderation.js";

const KEY = "re:knockback";
const PLACA_LAUNCH = "minecraft:light_weighted_pressure_plate"; // placa de ouro
const PROJETEIS = new Set(["minecraft:fishing_hook", "minecraft:snowball", "minecraft:egg"]);
const COOLDOWN_LAUNCH_TICKS = 10;

// Limites aceitos nos formulários (evita um erro de digitação virar um
// empurrão que joga o jogador pra fora do mapa).
export const LIMITES = {
	horizontal: [0, 5],
	vertical: [0, 3],
	projetil: [0, 5],
	launchHorizontal: [0.1, 20],
	launchVertical: [0, 5]
};

export const PRESETS = {
	padrao: { nome: "Padrão", horizontal: 0.85, vertical: 0.65, projetil: 1.25, launchHorizontal: 5, launchVertical: 0.7 },
	alto: { nome: "Alto (estilo vídeo)", horizontal: 1.08, vertical: 0.75, projetil: 1.35, launchHorizontal: 6.5, launchVertical: 1.6 },
	leve: { nome: "Leve", horizontal: 0.55, vertical: 0.45, projetil: 1.0, launchHorizontal: 4, launchVertical: 0.6 }
};

// Tudo começa DESLIGADO: instalar o addon não muda o PvP do servidor até um
// admin ligar no painel.
function configPadrao() {
	const p = PRESETS.padrao;
	return {
		ativo: false,
		horizontal: p.horizontal,
		vertical: p.vertical,
		projeteis: { ativo: true, forca: p.projetil },
		launchPad: {
			ativo: false,
			horizontal: p.launchHorizontal,
			vertical: p.launchVertical,
			particula: true,
			som: true,
			mensagem: "§e§l🚀 IMPULSO!"
		}
	};
}

// Sempre devolve um objeto novo (o getData devolve o mesmo objeto do cache,
// então mexer nele direto alteraria o cache sem salvar).
export function getConfigKnockback() {
	const padrao = configPadrao();
	const salvo = getData(KEY, {}) ?? {};
	return {
		...padrao,
		...salvo,
		projeteis: { ...padrao.projeteis, ...(salvo.projeteis ?? {}) },
		launchPad: { ...padrao.launchPad, ...(salvo.launchPad ?? {}) }
	};
}

export function salvarConfigKnockback(config) {
	setData(KEY, config);
}

export function restaurarPadraoKnockback() {
	const atual = getConfigKnockback();
	const novo = configPadrao();
	// Restaurar valores não muda o que está ligado/desligado.
	novo.ativo = atual.ativo;
	novo.projeteis.ativo = atual.projeteis.ativo;
	novo.launchPad.ativo = atual.launchPad.ativo;
	salvarConfigKnockback(novo);
}

export function aplicarPreset(id) {
	const p = PRESETS[id];
	if (!p) return false;
	const config = getConfigKnockback();
	config.horizontal = p.horizontal;
	config.vertical = p.vertical;
	config.projeteis.forca = p.projetil;
	config.launchPad.horizontal = p.launchHorizontal;
	config.launchPad.vertical = p.launchVertical;
	salvarConfigKnockback(config);
	return true;
}

// Aceita "0,85" e "0.85". Devolve null se não for número ou se sair do limite.
export function lerNumero(texto, [min, max]) {
	const n = Number(String(texto ?? "").trim().replace(",", "."));
	if (!Number.isFinite(n) || String(texto ?? "").trim() === "") return null;
	if (n < min || n > max) return null;
	return n;
}

export function formatarNumero(n) {
	return String(Number(Number(n).toFixed(2)));
}

// ===== APLICAÇÃO =====

let avisouErroApi = false;

// A assinatura do applyKnockback mudou entre versões da API: a nova recebe
// ({x, z}, vertical); a antiga recebe (x, z, horizontal, vertical).
function empurrar(entidade, dirX, dirZ, horizontal, vertical) {
	try {
		entidade.applyKnockback({ x: dirX * horizontal, z: dirZ * horizontal }, vertical);
		return;
	} catch {
		// tenta a assinatura antiga abaixo
	}
	try {
		entidade.applyKnockback(dirX, dirZ, horizontal, vertical);
	} catch (erro) {
		if (!avisouErroApi) {
			avisouErroApi = true;
			console.warn(`Knockback: não foi possível aplicar o empurrão: ${erro}`);
		}
	}
}

function ehJogador(entidade) {
	return entidade?.typeId === "minecraft:player";
}

// Direção horizontal (já normalizada) de quem atacou até quem apanhou.
function direcao(atacante, alvo) {
	const dx = alvo.location.x - atacante.location.x;
	const dz = alvo.location.z - atacante.location.z;
	const tamanho = Math.hypot(dx, dz) || 1;
	return { x: dx / tamanho, z: dz / tamanho };
}

function podeEmpurrar(atacante, alvo) {
	if (!ehJogador(atacante) || !ehJogador(alvo) || atacante.id === alvo.id) return false;
	if (pvpBloqueadoEntre(alvo, atacante)) return false; // área protegida sem PvP
	if (isCongelado(alvo)) return false; // congelado fica parado
	return true;
}

function empurrarDepois(alvo, dir, horizontal, vertical) {
	// Roda no próximo tick, depois do knockback normal do jogo.
	system.run(() => {
		try {
			empurrar(alvo, dir.x, dir.z, horizontal, vertical);
		} catch {
			// jogador pode ter saído nesse meio tempo
		}
	});
}

function aoBater(ev) {
	try {
		const config = getConfigKnockback();
		if (!config.ativo) return;
		const atacante = ev.damagingEntity;
		const alvo = ev.hitEntity;
		if (!podeEmpurrar(atacante, alvo)) return;
		empurrarDepois(alvo, direcao(atacante, alvo), config.horizontal, config.vertical);
	} catch (erro) {
		console.warn(`Erro no knockback de golpe: ${erro}`);
	}
}

// No addon original esse ramo nunca rodava (o evento de golpe não informa se foi
// projétil). Aqui usa o evento de projétil de verdade.
function aoAcertarProjetil(ev) {
	try {
		const config = getConfigKnockback();
		if (!config.ativo || !config.projeteis.ativo) return;
		if (!PROJETEIS.has(ev.projectile?.typeId)) return;
		const atacante = ev.source;
		const alvo = ev.getEntityHit()?.entity;
		if (!podeEmpurrar(atacante, alvo)) return;
		const forca = config.projeteis.forca;
		empurrarDepois(alvo, direcao(atacante, alvo), forca * 0.9, forca * 0.35);
	} catch (erro) {
		console.warn(`Erro no knockback de projétil: ${erro}`);
	}
}

const ultimoLaunch = new Map();

function aoPisarPlaca(ev) {
	try {
		const config = getConfigKnockback();
		const lp = config.launchPad;
		if (!lp.ativo) return;
		const jogador = ev.source;
		const bloco = ev.block;
		if (!ehJogador(jogador) || bloco?.typeId !== PLACA_LAUNCH) return;

		// Sem isso a placa podia disparar várias vezes seguidas.
		const agora = system.currentTick;
		if (agora - (ultimoLaunch.get(jogador.id) ?? -Infinity) < COOLDOWN_LAUNCH_TICKS) return;
		if (ultimoLaunch.size > 200) ultimoLaunch.clear();
		ultimoLaunch.set(jogador.id, agora);

		const dir = jogador.getViewDirection();
		const horiz = Math.hypot(dir.x, dir.z) || 1;
		empurrar(jogador, dir.x / horiz, dir.z / horiz, lp.horizontal, lp.vertical);

		if (lp.particula) {
			jogador.dimension.spawnParticle("minecraft:totem_particle", {
				x: bloco.location.x + 0.5,
				y: bloco.location.y + 1.1,
				z: bloco.location.z + 0.5
			});
		}
		if (lp.mensagem) jogador.sendMessage(lp.mensagem);
		if (lp.som) jogador.playSound("random.explode", { volume: 0.6, pitch: 1.8 });
	} catch (erro) {
		console.warn(`Erro no launch pad: ${erro}`);
	}
}

let iniciado = false;

// Chamado uma vez pelo main.js. Cada assinatura é separada: se uma API não
// existir nessa versão do jogo, o resto continua funcionando.
export function iniciarKnockback() {
	if (iniciado) return;
	iniciado = true;

	const assinaturas = [
		["entityHitEntity", aoBater],
		["projectileHitEntity", aoAcertarProjetil],
		["pressurePlatePush", aoPisarPlaca]
	];
	for (const [evento, funcao] of assinaturas) {
		try {
			world.afterEvents[evento].subscribe(funcao);
		} catch (erro) {
			console.warn(`Knockback: evento ${evento} indisponível: ${erro}`);
		}
	}
}
