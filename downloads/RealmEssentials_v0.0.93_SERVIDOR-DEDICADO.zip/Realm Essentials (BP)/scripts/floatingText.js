import { world } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { getTopAbates, getTopRecordeCps } from "./combat.js";
import { getTopSaldo } from "./money.js";
import { getRankingClans } from "./clan.js";

const KEY = "re:floatingtexts";
const TAG_PREFIXO = "re_ft_";
const DIMENSOES = ["overworld", "nether", "the_end"];

// Cores prontas pra escolher no texto animado (nome em portugues -> codigo
// de cor do Minecraft). O dono escolhe 3 pelos dropdowns do menu.
export const CORES_TEXTO_ANIMADO = [
	{ id: "vermelho", codigo: "§c" },
	{ id: "verde", codigo: "§a" },
	{ id: "azul", codigo: "§9" },
	{ id: "amarelo", codigo: "§e" },
	{ id: "roxo", codigo: "§5" },
	{ id: "rosa", codigo: "§d" },
	{ id: "aqua", codigo: "§b" },
	{ id: "dourado", codigo: "§6" },
	{ id: "branco", codigo: "§f" },
	{ id: "cinza", codigo: "§7" }
];

function corPorId(id, corPadrao) {
	return CORES_TEXTO_ANIMADO.find((c) => c.id === id)?.codigo ?? corPadrao;
}

function getTextos() {
	return getData(KEY, {});
}

function saveTextos(textos) {
	setData(KEY, textos);
}

function idUnico() {
	return `t${Date.now()}${Math.floor(Math.random() * 1000)}`;
}

function encontrarEntidade(id) {
	for (const nomeDim of DIMENSOES) {
		try {
			const dimension = world.getDimension(nomeDim);
			const encontrada = dimension.getEntities({ type: "re:floating_text" }).find((e) => e.hasTag(TAG_PREFIXO + id));
			if (encontrada) return encontrada;
		} catch (erro) {
			console.warn(`Erro ao procurar texto voador: ${erro}`);
		}
	}
	return null;
}

function spawnar(player, id) {
	const location = { x: player.location.x, y: player.location.y + 1, z: player.location.z };
	const entidade = player.dimension.spawnEntity("re:floating_text", location);
	entidade.addTag(TAG_PREFIXO + id);
	entidade.nameTag = "§7Atualizando...";
	return location;
}

// ===== CRIACAO =====

export function criarTextoFixo(player, texto) {
	texto = (texto ?? "").trim();
	if (!texto) {
		player.sendMessage("§cDigite um texto valido.");
		return;
	}

	const id = idUnico();
	let location;
	try {
		location = spawnar(player, id);
	} catch (erro) {
		player.sendMessage("§cNao foi possivel criar o texto voador.");
		console.warn(`Erro ao criar texto voador: ${erro}`);
		return;
	}

	const textos = getTextos();
	textos[id] = { tipo: "texto", texto, x: location.x, y: location.y, z: location.z };
	saveTextos(textos);
	player.sendMessage(`§aTexto voador §e${texto}§a criado!`);
}

// Texto animado: em vez de uma cor fixa, cada letra pega uma das 3 cores
// escolhidas e a cor vai passando de letra em letra a cada atualizacao,
// dando um efeito de onda/arco-iris com as cores do dono.
export function criarTextoAnimado(player, texto, corId1, corId2, corId3) {
	texto = (texto ?? "").trim();
	if (!texto) {
		player.sendMessage("§cDigite um texto valido.");
		return;
	}

	const cores = [
		corPorId(corId1, "§d"),
		corPorId(corId2, "§b"),
		corPorId(corId3, "§e")
	];

	const id = idUnico();
	let location;
	try {
		location = spawnar(player, id);
	} catch (erro) {
		player.sendMessage("§cNao foi possivel criar o texto voador.");
		console.warn(`Erro ao criar texto animado: ${erro}`);
		return;
	}

	const textos = getTextos();
	textos[id] = { tipo: "textoAnimado", texto, cores, x: location.x, y: location.y, z: location.z };
	saveTextos(textos);
	player.sendMessage(`§aTexto animado §e${texto}§a criado!`);
}

// Texto rapido: cor muda bem mais rapido que o texto animado normal (tem
// atualizacao propria, mais frequente), e se o texto for maior que a
// "janela" escolhida, so mostra um pedaco por vez, deslizando e voltando
// (tipo um letreiro) em vez de mostrar tudo de uma vez.
export function criarTextoRapido(player, texto, corId1, corId2, corId3, janela) {
	texto = (texto ?? "").trim();
	if (!texto) {
		player.sendMessage("§cDigite um texto valido.");
		return;
	}

	const cores = [corPorId(corId1, "§d"), corPorId(corId2, "§b"), corPorId(corId3, "§e")];
	const janelaFinal = Number(janela) === 10 ? 10 : 5;

	const id = idUnico();
	let location;
	try {
		location = spawnar(player, id);
	} catch (erro) {
		player.sendMessage("§cNao foi possivel criar o texto voador.");
		console.warn(`Erro ao criar texto rapido: ${erro}`);
		return;
	}

	const textos = getTextos();
	textos[id] = { tipo: "textoRapido", texto, cores, janela: janelaFinal, x: location.x, y: location.y, z: location.z };
	saveTextos(textos);
	player.sendMessage(`§aTexto rapido §e${texto}§a criado!`);
}

function criarRanking(player, tipo, titulo, quantidade) {
	titulo = (titulo ?? "").trim() || "Ranking";
	quantidade = Math.max(1, Math.min(10, Number(quantidade) || 10));

	const id = idUnico();
	let location;
	try {
		location = spawnar(player, id);
	} catch (erro) {
		player.sendMessage("§cNao foi possivel criar o texto voador.");
		console.warn(`Erro ao criar ranking: ${erro}`);
		return;
	}

	const textos = getTextos();
	textos[id] = { tipo, titulo, quantidade, x: location.x, y: location.y, z: location.z };
	saveTextos(textos);
	player.sendMessage(`§a${titulo}§a criado!`);
}

export function criarTopAbates(player, titulo, quantidade) {
	criarRanking(player, "topAbates", titulo, quantidade);
}

export function criarTopSaldo(player, titulo, quantidade) {
	criarRanking(player, "topSaldo", titulo, quantidade);
}

export function criarTopClan(player, titulo, quantidade) {
	criarRanking(player, "topClan", titulo, quantidade);
}

export function criarTopCps(player, titulo, quantidade) {
	criarRanking(player, "topCps", titulo, quantidade);
}

export function criarListaJogadores(player, titulo) {
	titulo = (titulo ?? "").trim() || "Jogadores Online";

	const id = idUnico();
	let location;
	try {
		location = spawnar(player, id);
	} catch (erro) {
		player.sendMessage("§cNao foi possivel criar o texto voador.");
		console.warn(`Erro ao criar lista de jogadores: ${erro}`);
		return;
	}

	const textos = getTextos();
	textos[id] = { tipo: "listaJogadores", titulo, x: location.x, y: location.y, z: location.z };
	saveTextos(textos);
	player.sendMessage(`§a${titulo}§a criado!`);
}

// ===== EDICAO / REMOCAO =====

export function getListaTextos() {
	const textos = getTextos();
	return Object.keys(textos).map((id) => ({ id, ...textos[id] }));
}

// Texto curto pra mostrar como botao na lista do menu.
export function getResumoTexto(config) {
	switch (config.tipo) {
		case "texto":
			return `§fTexto: §7${config.texto.slice(0, 24)}`;
		case "textoAnimado":
			return `§d§lTexto Animado: §r§7${config.texto.slice(0, 24)}`;
		case "textoRapido":
			return `§b§lTexto Rapido: §r§7${config.texto.slice(0, 24)}`;
		case "topAbates":
			return `§cTop Abates: §7${config.titulo}`;
		case "topSaldo":
			return `§aTop Saldo: §7${config.titulo}`;
		case "topClan":
			return `§bTop Clan: §7${config.titulo}`;
		case "topCps":
			return `§dTop CPS: §7${config.titulo}`;
		case "listaJogadores":
			return `§eJogadores Online: §7${config.titulo}`;
		default:
			return "§7Texto voador";
	}
}

export function removerTexto(player, id) {
	const textos = getTextos();
	if (!textos[id]) {
		player.sendMessage("§cEsse texto voador nao existe mais.");
		return;
	}

	const entidade = encontrarEntidade(id);
	if (entidade) {
		try {
			entidade.remove();
		} catch (erro) {
			console.warn(`Erro ao remover entidade do texto voador: ${erro}`);
		}
	}

	delete textos[id];
	saveTextos(textos);
	player.sendMessage("§aTexto voador removido.");
}

export function editarTexto(player, id, novosValores) {
	const textos = getTextos();
	const atual = textos[id];
	if (!atual) {
		player.sendMessage("§cEsse texto voador nao existe mais.");
		return;
	}

	textos[id] = { ...atual, ...novosValores };
	saveTextos(textos);
	player.sendMessage("§aTexto voador atualizado!");
}

// ===== ATUALIZACAO PERIODICA =====

// Usa o top persistente (guarda quem ja passou pelo servidor, mesmo
// offline) em vez de so olhar quem ta online agora - assim ninguem some do
// ranking so por ter saido, a posicao fica guardada e volta a contar
// quando a pessoa entra nao ele.
function montarTopAbates(config) {
	const jogadores = getTopAbates(config.quantidade);

	if (jogadores.length === 0) return `§c§l${config.titulo}§r\n§7Ninguem tem abate ainda.`;
	return `§c§l${config.titulo}§r\n${jogadores.map((j, i) => `§7${i + 1}. §f${j.nome} §8- §c${j.valor} abates`).join("\n")}`;
}

function montarTopSaldo(config) {
	const jogadores = getTopSaldo(config.quantidade);

	if (jogadores.length === 0) return `§a§l${config.titulo}§r\n§7Ninguem tem saldo ainda.`;
	return `§a§l${config.titulo}§r\n${jogadores.map((j, i) => `§7${i + 1}. §f${j.nome} §8- §a${j.valor} moedas`).join("\n")}`;
}

function montarTopClan(config) {
	const clans = getRankingClans().slice(0, config.quantidade);

	if (clans.length === 0) return `§b§l${config.titulo}§r\n§7Nenhum clan criado ainda.`;
	return `§b§l${config.titulo}§r\n${clans.map((c, i) => `§7${i + 1}. §f${c.nome} §8- §c${c.totalAbates} abates §8(${c.membros} membros)`).join("\n")}`;
}

function montarTopCps(config) {
	const jogadores = getTopRecordeCps(config.quantidade);

	if (jogadores.length === 0) return `§d§l${config.titulo}§r\n§7Ninguem tem recorde de CPS ainda.`;
	return `§d§l${config.titulo}§r\n${jogadores.map((j, i) => `§7${i + 1}. §f${j.nome} §8- §d${j.valor} cps`).join("\n")}`;
}

function montarListaJogadores(config) {
	const nomes = world.getAllPlayers().map((p) => p.name);
	if (nomes.length === 0) return `§e§l${config.titulo}§r\n§7Ninguem online agora.`;
	return `§e§l${config.titulo}§r §7(${nomes.length})\n${nomes.map((n) => `§7- §f${n}`).join("\n")}`;
}

// Cada letra pega uma cor da lista de 3 cores escolhidas pelo dono,
// deslocada por "frame" - o frame avanca uma casa a cada atualizacao (ver
// atualizarTextosVoadores), entao a cor de cada letra muda com o tempo e
// da a impressao de uma onda de cor andando pelo texto.
function montarTextoAnimado(config, frame) {
	const cores = config.cores && config.cores.length === 3 ? config.cores : ["§d", "§b", "§e"];

	return config.texto
		.replaceAll("\\n", "\n")
		.split("\n")
		.map((linha) => {
			let saida = "";
			let posicao = 0;
			for (const letra of linha) {
				if (letra === " ") {
					saida += letra;
					continue;
				}
				saida += `${cores[(posicao + frame) % cores.length]}§l${letra}`;
				posicao++;
			}
			return saida;
		})
		.join("\n");
}

// Avanca 1 a cada chamada de atualizarTextosVoadores (uma vez por segundo),
// dando o passo da animacao pra todos os textos animados de uma vez.
let frameAnimacao = 0;

// Atualiza o conteudo e a posicao de todos os textos voadores. Chamado
// periodicamente pelo main.js.
export function atualizarTextosVoadores() {
	const textos = getTextos();
	frameAnimacao = (frameAnimacao + 1) % 3;

	for (const id of Object.keys(textos)) {
		const config = textos[id];
		const entidade = encontrarEntidade(id);
		if (!entidade) continue;

		try {
			if (config.tipo === "texto") entidade.nameTag = config.texto.replaceAll("\\n", "\n");
			else if (config.tipo === "textoAnimado") entidade.nameTag = montarTextoAnimado(config, frameAnimacao);
			else if (config.tipo === "topAbates") entidade.nameTag = montarTopAbates(config);
			else if (config.tipo === "topSaldo") entidade.nameTag = montarTopSaldo(config);
			else if (config.tipo === "topClan") entidade.nameTag = montarTopClan(config);
			else if (config.tipo === "topCps") entidade.nameTag = montarTopCps(config);
			else if (config.tipo === "listaJogadores") entidade.nameTag = montarListaJogadores(config);
			// "textoRapido" nao entra aqui de proposito - ele tem sua propria
			// atualizacao mais rapida em atualizarTextosRapidos().

			// Garante que ele fica sempre no mesmo lugar (caso empurrem/movam).
			entidade.teleport({ x: config.x, y: config.y, z: config.z });
		} catch (erro) {
			console.warn(`Erro ao atualizar texto voador ${id}: ${erro}`);
		}
	}
}

// Mesma ideia do texto animado, mas o texto grande (maior que a "janela"
// escolhida) so mostra um pedaco por vez, deslizando pra frente e depois
// voltando (feito um letreiro), em vez de aparecer inteiro de uma vez.
function montarTextoRapido(config, frame) {
	const cores = config.cores && config.cores.length === 3 ? config.cores : ["§d", "§b", "§e"];
	const textoBase = (config.texto ?? "").replaceAll("\\n", " ");
	const janela = config.janela === 10 ? 10 : 5;

	let visivel = textoBase;
	if (textoBase.length > janela) {
		const maxInicio = textoBase.length - janela;
		const ciclo = maxInicio * 2;
		const posicaoNoCiclo = frame % ciclo;
		const inicio = posicaoNoCiclo <= maxInicio ? posicaoNoCiclo : ciclo - posicaoNoCiclo;
		visivel = textoBase.slice(inicio, inicio + janela);
	}

	let saida = "";
	let posicaoCor = 0;
	for (const letra of visivel) {
		if (letra === " ") {
			saida += letra;
			continue;
		}
		saida += `${cores[(posicaoCor + frame) % cores.length]}§l${letra}`;
		posicaoCor++;
	}
	return saida;
}

// Avanca bem mais rapido que o frameAnimacao normal (essa funcao roda em
// intervalo proprio, mais curto - ver main.js). Rodar so os textos
// rapidos aqui, separado da atualizacao normal (que mexe com rankings
// mais pesados de recalcular), evita gastar performance a toa nos outros
// tipos de texto voador.
let frameRapido = 0;

export function atualizarTextosRapidos() {
	const textos = getTextos();
	frameRapido++;

	for (const id of Object.keys(textos)) {
		const config = textos[id];
		if (config.tipo !== "textoRapido") continue;

		const entidade = encontrarEntidade(id);
		if (!entidade) continue;

		try {
			entidade.nameTag = montarTextoRapido(config, frameRapido);
		} catch (erro) {
			console.warn(`Erro ao atualizar texto rapido ${id}: ${erro}`);
		}
	}
}
