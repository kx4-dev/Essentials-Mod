import { getData, setData } from "./database.js";

const KEY = "re:features";

function configPadrao() {
	return {
		warp: true,
		home: true,
		teleportar: true,
		voltar: true,
		reportar: true,
		loja: true,
		clan: true,
		mostrarCps: true,
		mostrarAbates: true,
		mostrarVida: false,
		mostrarCombo: false,
		mostrarPlataforma: false,
		combateLog: false,
		raioMorte: false,
		autoColeta: false
	};
}

export function getFlags() {
	return { ...configPadrao(), ...getData(KEY, {}) };
}

export function ativo(nome) {
	return getFlags()[nome] ?? true;
}

export function definirFlag(player, nome, valor) {
	const flags = getFlags();
	if (!(nome in flags)) return;
	flags[nome] = !!valor;
	setData(KEY, flags);
	player.sendMessage(`§a${nome} agora esta ${valor ? "§aativado" : "§cdesativado"}§a.`);
}
