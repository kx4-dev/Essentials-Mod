import { world } from "@minecraft/server";
import { getData, setData } from "./database.js";

// Otimizacao propria de mobs: com pouca gente no servidor, os mobs ficam
// soltos normalmente. Quando o numero de jogadores online passa dos
// limiares configurados, o addon comeca a reduzir sozinho a quantidade de
// mobs por chunk, pra segurar o tps com o servidor mais cheio.

const KEY = "re:otimizacao";
const DIMENSOES = ["overworld", "nether", "the_end"];
const TAMANHO_CHUNK = 16;

// Nunca conta como "mob" pra essa reducao (jogador, item, xp, bichos de
// estimacao, aldeao e qualquer entidade com nome custom).
const TIPOS_IGNORADOS = new Set([
	"minecraft:player",
	"minecraft:item",
	"minecraft:xp_orb",
	"minecraft:villager",
	"minecraft:wolf",
	"minecraft:cat",
	"minecraft:armor_stand"
]);

function configPadrao() {
	return {
		ativo: true,
		limiarAlto: 20, // a partir de quantos jogadores online comeca a reduzir
		limiarCritico: 50, // a partir de quantos jogadores fica bem mais agressivo
		capPorChunkAlto: 3, // maximo de mobs "comuns" por chunk no nivel alto
		capPorChunkCritico: 1, // maximo de mobs "comuns" por chunk no nivel critico
		capShulkerPorChunk: 2 // shulker por chunk: sempre limitado, mesmo com pouca gente
	};
}

export function getConfig() {
	return { ...configPadrao(), ...getData(KEY, {}) };
}

function salvarConfig(config) {
	setData(KEY, config);
}

export function definirAtivo(ativo) {
	const config = getConfig();
	config.ativo = !!ativo;
	salvarConfig(config);
}

function numeroValido(valor, minimo, maximo) {
	const numero = Math.floor(Number(valor));
	return Number.isFinite(numero) ? Math.max(minimo, Math.min(maximo, numero)) : null;
}

export function definirLimites(limiarAlto, limiarCritico, capAlto, capCritico, capShulker) {
	const config = getConfig();
	const novoLimiarAlto = numeroValido(limiarAlto, 1, 500);
	const novoLimiarCritico = numeroValido(limiarCritico, 1, 500);
	const novoCapAlto = numeroValido(capAlto, 0, 50);
	const novoCapCritico = numeroValido(capCritico, 0, 50);
	const novoCapShulker = numeroValido(capShulker, 0, 20);

	if (novoLimiarAlto !== null) config.limiarAlto = novoLimiarAlto;
	if (novoLimiarCritico !== null) config.limiarCritico = novoLimiarCritico;
	if (novoCapAlto !== null) config.capPorChunkAlto = novoCapAlto;
	if (novoCapCritico !== null) config.capPorChunkCritico = novoCapCritico;
	if (novoCapShulker !== null) config.capShulkerPorChunk = novoCapShulker;

	salvarConfig(config);
	return config;
}

function chaveDoChunk(prefixo, location) {
	const cx = Math.floor(location.x / TAMANHO_CHUNK);
	const cz = Math.floor(location.z / TAMANHO_CHUNK);
	return `${prefixo}:${cx}:${cz}`;
}

function ehMobControlavel(entidade) {
	if (TIPOS_IGNORADOS.has(entidade.typeId)) return false;
	if (entidade.nameTag && entidade.nameTag.trim() !== "") return false;
	return true;
}

function removerComSeguranca(entidade) {
	try {
		entidade.remove();
	} catch (erro) {
		console.warn(`Erro ao remover mob na otimizacao: ${erro}`);
	}
}

// Roda periodicamente (chamado pelo main.js, nao precisa ser todo tick -
// e uma varredura de todas as entidades, entao rodar rapido demais so
// gastaria mais performance do que economiza).
export function tickOtimizacao() {
	const config = getConfig();
	if (!config.ativo) return;

	const totalJogadores = world.getAllPlayers().length;
	let capGeral = null;
	if (totalJogadores >= config.limiarCritico) capGeral = config.capPorChunkCritico;
	else if (totalJogadores >= config.limiarAlto) capGeral = config.capPorChunkAlto;

	for (const nomeDim of DIMENSOES) {
		let dimension;
		try {
			dimension = world.getDimension(nomeDim);
		} catch {
			continue;
		}

		let entidades;
		try {
			entidades = dimension.getEntities();
		} catch {
			continue;
		}

		const porChunk = new Map();
		const shulkersPorChunk = new Map();

		for (const entidade of entidades) {
			try {
				if (entidade.typeId === "minecraft:shulker") {
					const chave = chaveDoChunk(nomeDim, entidade.location);
					const lista = shulkersPorChunk.get(chave) ?? [];
					lista.push(entidade);
					shulkersPorChunk.set(chave, lista);
					continue;
				}

				if (!capGeral || !ehMobControlavel(entidade)) continue;

				const chave = chaveDoChunk(nomeDim, entidade.location);
				const lista = porChunk.get(chave) ?? [];
				lista.push(entidade);
				porChunk.set(chave, lista);
			} catch (erro) {
				console.warn(`Erro ao agrupar entidade na otimizacao: ${erro}`);
			}
		}

		// Shulker: sempre limitado por chunk, mesmo com pouca gente online.
		for (const lista of shulkersPorChunk.values()) {
			if (lista.length <= config.capShulkerPorChunk) continue;
			lista.slice(config.capShulkerPorChunk).forEach(removerComSeguranca);
		}

		if (!capGeral) continue;
		for (const lista of porChunk.values()) {
			if (lista.length <= capGeral) continue;
			lista.slice(capGeral).forEach(removerComSeguranca);
		}
	}
}
