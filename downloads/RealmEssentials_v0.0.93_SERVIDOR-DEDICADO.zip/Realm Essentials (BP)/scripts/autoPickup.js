import { world } from "@minecraft/server";

const TAG_JA_TRATADO = "re_pickup_tratado";
const RAIO_CLAIM = 3;
const DURACAO_CLAIM_MS = 2000;

// Lista de "reivindicacoes": lugares onde um jogador acabou de quebrar um
// bloco ou matar algo, e por isso tem direito a pegar o item que vai
// aparecer ali direto no inventario. Cada uma expira sozinha depois de
// alguns segundos.
let claims = [];

function limparClaimsVencidas() {
	const agora = Date.now();
	claims = claims.filter((c) => c.expiraEm > agora);
}

function registrarClaim(dimensionId, location, playerId) {
	limparClaimsVencidas();
	claims.push({
		dimensionId,
		x: location.x,
		y: location.y,
		z: location.z,
		playerId,
		expiraEm: Date.now() + DURACAO_CLAIM_MS
	});
}

export function registrarClaimQuebrarBloco(player, block) {
	registrarClaim(block.dimension.id, block.location, player.id);
}

export function registrarClaimAbate(dimension, location, matador) {
	registrarClaim(dimension.id, location, matador.id);
}

function distancia(a, b) {
	const dx = a.x - b.x;
	const dy = a.y - b.y;
	const dz = a.z - b.z;
	return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function encontrarClaim(dimensionId, location) {
	limparClaimsVencidas();
	return claims.find((c) => c.dimensionId === dimensionId && distancia(c, location) <= RAIO_CLAIM);
}

// Chamado quando um item aparece no chao (entitySpawn). Se tiver uma
// reivindicacao pra esse lugar, tenta colocar o item direto no inventario
// de quem reivindicou; o que nao couber cai no chao normalmente.
export function processarItemSpawnado(entidade) {
	if (entidade.typeId !== "minecraft:item") return;
	if (entidade.hasTag(TAG_JA_TRATADO)) return;

	const claim = encontrarClaim(entidade.dimension.id, entidade.location);
	if (!claim) return;

	const jogador = world.getAllPlayers().find((p) => p.id === claim.playerId);
	if (!jogador) return;

	try {
		const itemComponent = entidade.getComponent("minecraft:item");
		if (!itemComponent) return;

		const inventario = jogador.getComponent("minecraft:inventory")?.container;
		if (!inventario) return;

		const sobra = inventario.addItem(itemComponent.itemStack);
		entidade.remove();

		if (sobra) {
			const restante = entidade.dimension.spawnItem(sobra, entidade.location);
			restante.addTag(TAG_JA_TRATADO);
		}
	} catch (erro) {
		console.warn(`Erro no auto-coleta: ${erro}`);
	}
}
