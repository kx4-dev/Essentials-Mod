// Quem é admin/dono no addon: quem tem a tag "admin" (/tag @s add admin) ou a
// tag "dono" (/tag @s add dono), OU é operador do mundo/servidor. As duas tags
// dão o mesmo acesso. O fallback por operador ajuda principalmente em Realms,
// onde o dono do Realm já é operador mas normalmente nunca criou a tag.
// Operador já consegue rodar /tag em si mesmo, então isso não abre brecha nova.
const TAGS_ADMIN = ["admin", "dono"];

export function ehDono(player) {
	try {
		if (TAGS_ADMIN.some((tag) => player.hasTag(tag))) return true;
	} catch {
		return false;
	}
	try {
		return typeof player.isOp === "function" && player.isOp();
	} catch {
		return false;
	}
}
