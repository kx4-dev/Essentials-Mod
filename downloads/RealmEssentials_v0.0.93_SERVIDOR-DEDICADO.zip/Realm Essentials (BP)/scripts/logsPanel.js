import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import {
	CATEGORIAS,
	webhookSuportado,
	getConfigLogs,
	definirWebhook,
	definirAtivoLogs,
	definirCategorias,
	getUltimosLogs,
	limparHistorico,
	getStatusEnvio,
	enviarTeste,
	formatarHora
} from "./discordLogs.js";

const ICONE_CONFIGURAR = "textures/ui/icon_setting";
const ICONE_LISTA = "textures/items/paper";
const ICONE_LIGAR = "textures/items/emerald";
const ICONE_DESLIGAR = "textures/ui/icon_trash";
const ICONE_VOLTAR = "textures/icons/left_arrow";

function textoStatusEnvio() {
	const s = getStatusEnvio();
	if (s.ok === null) return "§7nenhum envio ainda";
	const quando = s.quando ? formatarHora(s.quando) : "?";
	if (s.ok) return `§aok §7(HTTP ${s.status}, ${quando})`;
	if (s.status === 404 || s.status === 401) return `§cwebhook inválido ou apagado §7(HTTP ${s.status}, ${quando})`;
	return `§cfalhou §7(HTTP ${s.status}, ${quando})`;
}

// aoVoltar: função que reabre o painel de onde o dono veio.
export function abrirMenuLogs(player, aoVoltar) {
	const config = getConfigLogs();
	const categoriasAtivas = Object.values(config.categorias).filter(Boolean).length;
	const total = Object.keys(CATEGORIAS).length;

	let corpo =
		`§fLogs: ${config.ativo ? "§aligados" : "§cdesligados"}\n` +
		`§fCategorias ativas: §e${categoriasAtivas}§f/${total}\n`;

	if (webhookSuportado) {
		corpo +=
			`§fModo: §aservidor dedicado §7(Discord disponível)\n` +
			`§fWebhook: ${config.webhookUrl ? `§aconfigurado §7(...${config.webhookUrl.slice(-6)})` : "§cnão configurado"}\n` +
			`§fÚltimo envio: ${textoStatusEnvio()}\n` +
			`§fNa fila: §e${getStatusEnvio().pendentes}`;
	} else {
		corpo +=
			`§fModo: §eRealm / mundo local\n` +
			`§7O Minecraft não libera internet pra scripts nesse modo, então o Discord fica indisponível. Os logs ficam salvos aqui dentro (botão "Ver últimos logs"). Pra mandar pro Discord, use a versão de servidor dedicado do addon.`;
	}

	const form = new ActionFormData()
		.title("Logs")
		.body(corpo)
		.button(config.ativo ? "Desligar logs\n§7[Para de registrar tudo]" : "Ligar logs\n§7[Volta a registrar]", config.ativo ? ICONE_DESLIGAR : ICONE_LIGAR)
		.button("Categorias\n§7[Escolher o que registrar]", ICONE_CONFIGURAR)
		.button("Ver últimos logs\n§7[Histórico dentro do jogo]", ICONE_LISTA);

	const temWebhook = webhookSuportado;
	if (temWebhook) {
		form.button("Webhook do Discord\n§7[Colar ou remover o link]", ICONE_CONFIGURAR);
		form.button("Enviar teste\n§7[Manda um log de teste]", ICONE_LIGAR);
	}
	form.button("Limpar histórico\n§7[Apaga os logs salvos no jogo]", ICONE_DESLIGAR);
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		const acoes = [
			() => {
				definirAtivoLogs(!config.ativo);
				player.sendMessage(config.ativo ? "§eLogs desligados." : "§aLogs ligados!");
				abrirMenuLogs(player, aoVoltar);
			},
			() => abrirCategorias(player, aoVoltar),
			() => abrirHistorico(player, aoVoltar)
		];
		if (temWebhook) {
			acoes.push(() => abrirWebhook(player, aoVoltar));
			acoes.push(() => {
				if (!getConfigLogs().webhookUrl) {
					player.sendMessage("§cConfigure o webhook antes de enviar o teste.");
				} else {
					enviarTeste(player);
					player.sendMessage("§aTeste enviado. Confira o canal do Discord em alguns segundos.");
				}
				abrirMenuLogs(player, aoVoltar);
			});
		}
		acoes.push(() => {
			limparHistorico();
			player.sendMessage("§aHistórico de logs limpo.");
			abrirMenuLogs(player, aoVoltar);
		});
		acoes.push(() => aoVoltar?.(player));

		acoes[res.selection]?.();
	});
}

function abrirCategorias(player, aoVoltar) {
	const config = getConfigLogs();
	const ids = Object.keys(CATEGORIAS);

	const modal = new ModalFormData().title("Categorias de log");
	for (const id of ids) modal.toggle(`${CATEGORIAS[id].icone} ${CATEGORIAS[id].nome}`, { defaultValue: config.categorias[id] !== false });

	modal.show(player).then((res) => {
		if (res.canceled || !res.formValues) {
			abrirMenuLogs(player, aoVoltar);
			return;
		}
		const novo = {};
		ids.forEach((id, i) => (novo[id] = !!res.formValues[i]));
		definirCategorias(novo);
		player.sendMessage("§aCategorias de log atualizadas.");
		abrirMenuLogs(player, aoVoltar);
	});
}

function abrirWebhook(player, aoVoltar) {
	const modal = new ModalFormData()
		.title("Webhook do Discord")
		.textField(
			"Cole o link do webhook (deixe vazio pra remover)",
			"https://discord.com/api/webhooks/...",
			{ defaultValue: "" }
		);

	modal.show(player).then((res) => {
		if (res.canceled || !res.formValues) {
			abrirMenuLogs(player, aoVoltar);
			return;
		}
		const url = String(res.formValues[0] ?? "").trim();
		if (!definirWebhook(url)) {
			player.sendMessage("§cEsse link não parece um webhook do Discord. Ele começa com §ehttps://discord.com/api/webhooks/§c.");
		} else if (url) {
			player.sendMessage("§aWebhook salvo! Use §e\"Enviar teste\"§a pra conferir. §7Não compartilhe o arquivo do mundo: o link é um segredo.");
		} else {
			player.sendMessage("§eWebhook removido.");
		}
		abrirMenuLogs(player, aoVoltar);
	});
}

function abrirHistorico(player, aoVoltar) {
	const logs = getUltimosLogs(15);
	const corpo =
		logs.length === 0
			? "§7Nenhum log registrado ainda."
			: logs
					.map((l) => {
						const cat = CATEGORIAS[l.c];
						return `§8${formatarHora(l.t)} §f${cat?.icone ?? ""} ${l.a}${l.d ? `\n§7  ${l.d}` : ""}`;
					})
					.join("\n");

	new ActionFormData()
		.title("Últimos logs")
		.body(corpo)
		.button("Voltar", ICONE_VOLTAR)
		.show(player)
		.then((res) => {
			if (res.canceled) return;
			abrirMenuLogs(player, aoVoltar);
		});
}
