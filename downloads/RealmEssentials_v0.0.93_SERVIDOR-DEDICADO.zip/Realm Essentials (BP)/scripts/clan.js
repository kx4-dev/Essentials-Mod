import { world } from "@minecraft/server";
import { MessageFormData } from "@minecraft/server-ui";
import { getData, setData, getJogadoresConhecidos } from "./database.js";
import { getAbates } from "./combat.js";
import { teleportarComContagem } from "./teleportCountdown.js";
import { getPermissoes } from "./rank.js";
import { emCooldown } from "./cooldown.js";
import { cobrarCusto } from "./money.js";

const KEY = "re:clans";
const KEY_CONFIG = "re:clans:config";
const LIMITE_CARACTERES = 25;
const LIMITE_BIO = 100;
const LIMITE_MEMBROS_PADRAO = 10;
const LIMITE_TAG = 6;
const UM_DIA_MS = 24 * 60 * 60 * 1000;
const ICONE_PADRAO_CLAN = "textures/items/diamond";

// Todas as cores de texto do Minecraft. O nome da cor ja vem escrito com a
// propria cor (§4Vermelho por exemplo), assim o dropdown mostra uma previa
// de como vai ficar o nome do clan antes de escolher.
export const CORES_CLAN = [
	{ nome: "§fBranco", codigo: "§f" },
	{ nome: "§7Cinza Claro", codigo: "§7" },
	{ nome: "§8Cinza Escuro", codigo: "§8" },
	{ nome: "§0Preto", codigo: "§0" },
	{ nome: "§4Vermelho Escuro", codigo: "§4" },
	{ nome: "§cVermelho", codigo: "§c" },
	{ nome: "§6Laranja", codigo: "§6" },
	{ nome: "§eAmarelo", codigo: "§e" },
	{ nome: "§2Verde Escuro", codigo: "§2" },
	{ nome: "§aVerde", codigo: "§a" },
	{ nome: "§bCiano", codigo: "§b" },
	{ nome: "§3Azul Escuro (aqua)", codigo: "§3" },
	{ nome: "§1Azul Escuro", codigo: "§1" },
	{ nome: "§9Azul", codigo: "§9" },
	{ nome: "§5Roxo", codigo: "§5" },
	{ nome: "§dRosa", codigo: "§d" }
];

// Icones disponiveis pro lider escolher pro clan (mesma ideia da warp).
export const ICONES_CLAN = [
	{ nome: "Grupo (padrao)", icone: "textures/items/diamond" },
	{ nome: "Escudo", icone: "textures/items/shield" },
	{ nome: "Espada de Ferro", icone: "textures/items/iron_sword" },
	{ nome: "Espada de Diamante", icone: "textures/items/diamond_sword" },
	{ nome: "Diamante", icone: "textures/items/diamond" },
	{ nome: "Esmeralda", icone: "textures/items/emerald" },
	{ nome: "Estrela do Nether", icone: "textures/items/nether_star" },
	{ nome: "Totem", icone: "textures/items/totem" },
	{ nome: "Olho do Ender", icone: "textures/items/ender_eye" },
	{ nome: "Lingote de Ouro", icone: "textures/items/gold_ingot" },
	{ nome: "Coracao", icone: "textures/items/apple" },
	{ nome: "Arco", icone: "textures/items/bow" }
];

// ===== CONFIGURACAO (definida pelo dono no Painel) =====

function configClanPadrao() {
	return {
		limiteMembros: LIMITE_MEMBROS_PADRAO,
		modoCriacao: "todos", // "todos" ou "restrito"
		permitidos: [], // ids de jogador liberados quando modoCriacao = "restrito"
		custoCriar: 0
	};
}

export function getConfigClan() {
	return { ...configClanPadrao(), ...getData(KEY_CONFIG, {}) };
}

function saveConfigClan(config) {
	setData(KEY_CONFIG, config);
}

export function definirLimiteMembrosClan(limite) {
	const numero = Math.floor(Number(limite));
	if (!Number.isFinite(numero) || numero < 1) return false;
	const config = getConfigClan();
	config.limiteMembros = Math.min(100, numero);
	saveConfigClan(config);
	return true;
}

export function definirModoCriacaoClan(restrito) {
	const config = getConfigClan();
	config.modoCriacao = restrito ? "restrito" : "todos";
	saveConfigClan(config);
}

export function definirCustoCriarClan(custo) {
	const numero = Math.floor(Number(custo));
	if (!Number.isFinite(numero) || numero < 0) return false;
	const config = getConfigClan();
	config.custoCriar = numero;
	saveConfigClan(config);
	return true;
}

export function permitirCriarClan(playerId) {
	const config = getConfigClan();
	if (!config.permitidos.includes(playerId)) config.permitidos.push(playerId);
	saveConfigClan(config);
}

export function proibirCriarClan(playerId) {
	const config = getConfigClan();
	config.permitidos = config.permitidos.filter((id) => id !== playerId);
	saveConfigClan(config);
}

export function podeCriarClan(player) {
	const config = getConfigClan();
	if (config.modoCriacao !== "restrito") return true;
	return config.permitidos.includes(player.id);
}

function getClans() {
	const clans = getData(KEY, {});
	// Garante que clans antigos (criados antes da tag/pedidos de entrada existirem)
	// tenham esses campos, pra nao quebrar o resto do codigo.
	for (const nome of Object.keys(clans)) {
		if (clans[nome].tag === undefined) clans[nome].tag = "";
		if (clans[nome].solicitacoes === undefined) clans[nome].solicitacoes = [];
		if (clans[nome].criadoEm === undefined) clans[nome].criadoEm = null;
	}
	return clans;
}

function saveClans(clans) {
	setData(KEY, clans);
}

function encontrarClanDoJogador(clans, playerId) {
	for (const nome of Object.keys(clans)) {
		if (clans[nome].members.includes(playerId)) return nome;
	}
	return null;
}

// Verifica se ja existe um clan com esse nome, ignorando maiusculas/minusculas.
function nomeClanEmUso(clans, nome) {
	return Object.keys(clans).some((n) => n.toLowerCase() === nome.toLowerCase());
}

// Retorna { nome, clan } do clan do jogador, ou null se ele nao tiver clan.
export function getMeuClan(player) {
	const clans = getClans();
	const nome = encontrarClanDoJogador(clans, player.id);
	return nome ? { nome, clan: clans[nome] } : null;
}

export function criarClan(player, nome, bio, corCodigo) {
	nome = (nome ?? "").trim();

	if (!nome) {
		player.sendMessage("§cDigite um nome valido para o clan.");
		return;
	}

	if (nome.length > LIMITE_CARACTERES) {
		player.sendMessage(`§cO nome do clan deve ter no maximo ${LIMITE_CARACTERES} letras.`);
		return;
	}

	bio = (bio ?? "").trim();
	if (bio.length > LIMITE_BIO) {
		player.sendMessage(`§cA bio deve ter no maximo ${LIMITE_BIO} caracteres.`);
		return;
	}

	const cor = CORES_CLAN.some((c) => c.codigo === corCodigo) ? corCodigo : "§e";

	const clans = getClans();

	if (encontrarClanDoJogador(clans, player.id)) {
		player.sendMessage("§cVoce ja faz parte de um clan.");
		return;
	}

	if (nomeClanEmUso(clans, nome)) {
		player.sendMessage(`§cJa existe um clan chamado §e${nome}§c.`);
		return;
	}

	if (!podeCriarClan(player)) {
		player.sendMessage("§cVoce nao tem permissao pra criar um clan. Peca pro dono do servidor liberar.");
		return;
	}

	const config = getConfigClan();
	if (!cobrarCusto(player, config.custoCriar)) return;

	clans[nome] = {
		lider: player.id,
		members: [player.id],
		invites: [],
		solicitacoes: [],
		tag: "",
		bio,
		cor,
		icone: ICONE_PADRAO_CLAN,
		criadoEm: Date.now()
	};
	saveClans(clans);
	player.sendMessage(`§aClan §e${nome}§a criado com sucesso!`);
}

// So o lider pode mudar. Tag curta (ex: "FERRE") mostrada na lista de clans
// e, se definida, usada no lugar do nome completo ao lado do jogador.
export function definirTagClan(player, tag) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		player.sendMessage("§cVoce nao faz parte de nenhum clan.");
		return;
	}
	if (meuClan.clan.lider !== player.id) {
		player.sendMessage("§cApenas o lider do clan pode mudar a tag.");
		return;
	}

	tag = (tag ?? "").trim().toUpperCase();
	if (tag.length > LIMITE_TAG) {
		player.sendMessage(`§cA tag deve ter no maximo ${LIMITE_TAG} letras.`);
		return;
	}

	const clans = getClans();
	clans[meuClan.nome].tag = tag;
	saveClans(clans);
	player.sendMessage(tag ? `§aTag do clan definida como §e[${tag}]§a!` : "§aTag do clan removida.");
}

export function convidarClan(player, nomeJogador) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		player.sendMessage("§cVoce nao faz parte de nenhum clan.");
		return;
	}

	if (meuClan.clan.lider !== player.id) {
		player.sendMessage("§cApenas o lider do clan pode convidar jogadores.");
		return;
	}

	nomeJogador = (nomeJogador ?? "").trim();
	if (!nomeJogador) {
		player.sendMessage("§cDigite o nome de um jogador.");
		return;
	}

	const alvo = world.getPlayers({ name: nomeJogador })[0];
	if (!alvo) {
		player.sendMessage(`§cJogador §e${nomeJogador}§c nao encontrado online.`);
		return;
	}

	if (alvo.id === player.id) {
		player.sendMessage("§cVoce ja esta no seu proprio clan.");
		return;
	}

	const clans = getClans();
	const clan = clans[meuClan.nome];

	const limiteMembros = getConfigClan().limiteMembros;
	if (clan.members.length >= limiteMembros) {
		player.sendMessage(`§cSeu clan ja atingiu o limite de §e${limiteMembros}§c membros.`);
		return;
	}

	if (clan.members.includes(alvo.id)) {
		player.sendMessage("§cEsse jogador ja faz parte do clan.");
		return;
	}

	if (encontrarClanDoJogador(clans, alvo.id)) {
		player.sendMessage(`§e${alvo.name}§c ja faz parte de outro clan.`);
		return;
	}

	if (!clan.invites.includes(alvo.id)) clan.invites.push(alvo.id);
	saveClans(clans);

	player.sendMessage(`§aConvite enviado para §e${alvo.name}§a.`);
	mostrarPopupConvite(alvo, meuClan.nome);
}

// Mostra o convite direto na tela do jogador. Se ele fechar sem responder
// (clicar fora, apertar voltar, etc.), o convite continua salvo e pode ser
// respondido depois em "Ver Convites".
function mostrarPopupConvite(alvo, nomeClan) {
	const form = new MessageFormData()
		.title("Convite de Clan")
		.body(`Voce foi convidado para o clan §e${nomeClan}§r. Aceitar?`)
		.button1("Aceitar")
		.button2("Recusar");

	form
		.show(alvo)
		.then((res) => {
			if (res.canceled) return;
			if (res.selection === 0) aceitarConvite(alvo, nomeClan);
			if (res.selection === 1) recusarConvite(alvo, nomeClan);
		})
		.catch((erro) => {
			console.warn(`Erro ao mostrar popup de convite: ${erro}`);
		});
}

// Lista os nomes dos clans que convidaram o jogador.
export function getConvites(player) {
	const clans = getClans();
	return Object.keys(clans).filter((nome) => clans[nome].invites.includes(player.id));
}

export function aceitarConvite(player, nomeClan) {
	if (getMeuClan(player)) {
		player.sendMessage("§cVoce ja faz parte de um clan.");
		return;
	}

	const clans = getClans();
	const clan = clans[nomeClan];
	if (!clan || !clan.invites.includes(player.id)) {
		player.sendMessage("§cEsse convite nao existe mais.");
		return;
	}

	const limiteMembros = getConfigClan().limiteMembros;
	if (clan.members.length >= limiteMembros) {
		player.sendMessage(`§cEsse clan ja atingiu o limite de §e${limiteMembros}§c membros.`);
		return;
	}

	clan.invites = clan.invites.filter((id) => id !== player.id);
	clan.members.push(player.id);
	saveClans(clans);

	player.sendMessage(`§aVoce entrou no clan §e${nomeClan}§a!`);

	const lider = world.getAllPlayers().find((p) => p.id === clan.lider);
	if (lider) lider.sendMessage(`§e${player.name}§a entrou no seu clan!`);
}

export function recusarConvite(player, nomeClan) {
	const clans = getClans();
	const clan = clans[nomeClan];
	if (!clan || !clan.invites.includes(player.id)) {
		player.sendMessage("§cEsse convite nao existe mais.");
		return;
	}

	clan.invites = clan.invites.filter((id) => id !== player.id);
	saveClans(clans);
	player.sendMessage(`§eVoce recusou o convite do clan §c${nomeClan}§e.`);
}

export function sairClan(player) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		player.sendMessage("§cVoce nao faz parte de nenhum clan.");
		return;
	}

	if (meuClan.clan.lider === player.id) {
		player.sendMessage("§cO lider nao pode sair. Use a opcao Deletar Clan.");
		return;
	}

	const clans = getClans();
	const clan = clans[meuClan.nome];
	clan.members = clan.members.filter((id) => id !== player.id);
	saveClans(clans);
	player.sendMessage(`§aVoce saiu do clan §e${meuClan.nome}§a.`);
}

export function deletarClan(player) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		player.sendMessage("§cVoce nao faz parte de nenhum clan.");
		return;
	}

	if (meuClan.clan.lider !== player.id) {
		player.sendMessage("§cApenas o lider pode deletar o clan.");
		return;
	}

	const clans = getClans();
	delete clans[meuClan.nome];
	saveClans(clans);
	player.sendMessage(`§cClan §e${meuClan.nome}§c deletado.`);
}

export function expulsarClan(player, nomeJogador) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		player.sendMessage("§cVoce nao faz parte de nenhum clan.");
		return;
	}

	if (meuClan.clan.lider !== player.id) {
		player.sendMessage("§cApenas o lider do clan pode expulsar membros.");
		return;
	}

	nomeJogador = (nomeJogador ?? "").trim();
	const clans = getClans();
	const clan = clans[meuClan.nome];
	const alvo = world.getPlayers({ name: nomeJogador })[0];

	if (!alvo || !clan.members.includes(alvo.id)) {
		player.sendMessage(`§cJogador §e${nomeJogador}§c nao faz parte do seu clan.`);
		return;
	}

	clan.members = clan.members.filter((id) => id !== alvo.id);
	saveClans(clans);
	player.sendMessage(`§aVoce expulsou §e${alvo.name}§a do clan.`);
	alvo.sendMessage(`§cVoce foi expulso do clan §e${meuClan.nome}§c.`);
}

// ===== LISTA PUBLICA / PEDIDO DE ENTRADA =====
// Qualquer jogador pode ver todos os clans e pedir pra entrar num deles.
// O lider aceita ou recusa o pedido depois (nao entra na hora, como no convite).

// Lista resumida de todos os clans, pra tela "Lista de Clans".
export function getTodosClans() {
	const clans = getClans();
	return Object.keys(clans)
		.sort((a, b) => a.localeCompare(b))
		.map((nome) => {
			const clan = clans[nome];
			const donoOnline = world.getAllPlayers().find((p) => p.id === clan.lider);
			const donoNome = donoOnline?.name ?? getJogadoresConhecidos()[clan.lider] ?? "§7(desconhecido)";
			return {
				nome,
				tag: clan.tag ?? "",
				membros: clan.members.length,
				dono: donoNome,
				icone: clan.icone ?? ICONE_PADRAO_CLAN,
				cor: clan.cor ?? "§e"
			};
		});
}

// Informacoes publicas de um clan especifico, pra tela de inspecionar.
export function getInfoPublicaClan(nomeClan) {
	const clans = getClans();
	const clan = clans[nomeClan];
	if (!clan) return null;

	const donoOnline = world.getAllPlayers().find((p) => p.id === clan.lider);
	const donoNome = donoOnline?.name ?? getJogadoresConhecidos()[clan.lider] ?? "§7(desconhecido)";
	const diasCriado = clan.criadoEm !== null ? Math.max(0, Math.floor((Date.now() - clan.criadoEm) / UM_DIA_MS)) : null;

	return {
		nome: nomeClan,
		tag: clan.tag ?? "",
		cor: clan.cor ?? "§e",
		bio: clan.bio ?? "",
		dono: donoNome,
		membros: clan.members.length,
		limite: getConfigClan().limiteMembros,
		diasCriado
	};
}

export function solicitarEntrada(player, nomeClan) {
	if (getMeuClan(player)) {
		player.sendMessage("§cVoce ja faz parte de um clan.");
		return;
	}

	const clans = getClans();
	const clan = clans[nomeClan];
	if (!clan) {
		player.sendMessage("§cEsse clan nao existe mais.");
		return;
	}

	const limiteMembros = getConfigClan().limiteMembros;
	if (clan.members.length >= limiteMembros) {
		player.sendMessage(`§cEsse clan ja atingiu o limite de §e${limiteMembros}§c membros.`);
		return;
	}

	if (clan.solicitacoes.includes(player.id)) {
		player.sendMessage("§eVoce ja solicitou entrada nesse clan. Aguarde o lider responder.");
		return;
	}

	clan.solicitacoes.push(player.id);
	saveClans(clans);

	player.sendMessage(`§aPedido enviado para o clan §e${nomeClan}§a! Aguarde o lider aceitar.`);

	const lider = world.getAllPlayers().find((p) => p.id === clan.lider);
	if (lider) lider.sendMessage(`§e${player.name}§a quer entrar no seu clan! Veja em §eMeu Clan > Pedidos de Entrada§a.`);
}

export function cancelarSolicitacao(player, nomeClan) {
	const clans = getClans();
	const clan = clans[nomeClan];
	if (!clan || !clan.solicitacoes.includes(player.id)) {
		player.sendMessage("§cEsse pedido nao existe mais.");
		return;
	}

	clan.solicitacoes = clan.solicitacoes.filter((id) => id !== player.id);
	saveClans(clans);
	player.sendMessage(`§eVoce cancelou o pedido de entrada no clan §c${nomeClan}§e.`);
}

// Nomes dos clans onde o jogador tem um pedido de entrada pendente.
export function getSolicitacoesEnviadas(player) {
	const clans = getClans();
	return Object.keys(clans).filter((nome) => clans[nome].solicitacoes.includes(player.id));
}

// Pedidos pendentes no clan do jogador (so retorna algo se ele for o lider).
export function getSolicitacoesDoClan(player) {
	const meuClan = getMeuClan(player);
	if (!meuClan || meuClan.clan.lider !== player.id) return [];

	return meuClan.clan.solicitacoes.map((id) => {
		const online = world.getAllPlayers().find((p) => p.id === id);
		return { id, nome: online?.name ?? getJogadoresConhecidos()[id] ?? "§7(offline)" };
	});
}

export function aceitarSolicitacao(player, alvoId) {
	const meuClan = getMeuClan(player);
	if (!meuClan || meuClan.clan.lider !== player.id) {
		player.sendMessage("§cApenas o lider do clan pode aceitar pedidos.");
		return;
	}

	const clans = getClans();
	const clan = clans[meuClan.nome];
	if (!clan.solicitacoes.includes(alvoId)) {
		player.sendMessage("§cEsse pedido nao existe mais.");
		return;
	}

	const limiteMembros = getConfigClan().limiteMembros;
	if (clan.members.length >= limiteMembros) {
		player.sendMessage(`§cSeu clan ja atingiu o limite de §e${limiteMembros}§c membros.`);
		return;
	}

	clan.solicitacoes = clan.solicitacoes.filter((id) => id !== alvoId);
	clan.members.push(alvoId);
	saveClans(clans);

	const alvo = world.getAllPlayers().find((p) => p.id === alvoId);
	player.sendMessage(`§a${alvo?.name ?? "Jogador"} agora faz parte do clan!`);
	if (alvo) alvo.sendMessage(`§aSeu pedido para entrar no clan §e${meuClan.nome}§a foi aceito!`);
}

export function recusarSolicitacao(player, alvoId) {
	const meuClan = getMeuClan(player);
	if (!meuClan || meuClan.clan.lider !== player.id) {
		player.sendMessage("§cApenas o lider do clan pode recusar pedidos.");
		return;
	}

	const clans = getClans();
	const clan = clans[meuClan.nome];
	clan.solicitacoes = clan.solicitacoes.filter((id) => id !== alvoId);
	saveClans(clans);

	const alvo = world.getAllPlayers().find((p) => p.id === alvoId);
	player.sendMessage("§ePedido recusado.");
	if (alvo) alvo.sendMessage(`§cSeu pedido para entrar no clan §e${meuClan.nome}§c foi recusado.`);
}

// Texto formatado com as informacoes completas do clan (usado no menu "Meu Clan").
export function getInfoClanTexto(player) {
	const meuClan = getMeuClan(player);
	if (!meuClan) return null;

	const { nome, clan } = meuClan;
	const online = clan.members.filter((id) => world.getAllPlayers().some((p) => p.id === id)).length;
	const nomeLider = world.getAllPlayers().find((p) => p.id === clan.lider)?.name ?? "§7(offline)";

	let totalAbates = 0;
	const linhasMembros = clan.members.map((id) => {
		const online = world.getAllPlayers().find((p) => p.id === id);
		const abates = online ? getAbates(online) : 0;
		totalAbates += abates;
		const nomeMembro = online?.name ?? "§7(offline)";
		return `§7- §f${nomeMembro} §8(§c${abates} abates§8)`;
	});

	const diasCriado =
		clan.criadoEm !== null ? Math.max(0, Math.floor((Date.now() - clan.criadoEm) / UM_DIA_MS)) : null;

	const cor = (clan.cor ?? "§e").replace("§l", "");

	return (
		`${cor}${nome}§r\n` +
		(clan.bio ? `§7${clan.bio}§r\n` : "") +
		`\n§bTag: §f${clan.tag ? `[${clan.tag}]` : `[${nome}]`}\n` +
		`§6Lider: §e${nomeLider}\n` +
		`§bOnline: §f${online}/${clan.members.length} §7(limite: ${getConfigClan().limiteMembros})\n` +
		(diasCriado !== null ? `§dCriado: §f${diasCriado} dias atras\n` : "") +
		`§aMembros:\n` +
		linhasMembros.join("\n") +
		`\n§cTotal de abates do clan: §e${totalAbates}`
	);
}

// Retorna a tag (ou o nome, se nao tiver tag) do clan do jogador, ja formatado
// pra ir do lado do nome dele no chat/nametag. Vazio se nao tiver clan.
export function getClanDisplay(player) {
	const meuClan = getMeuClan(player);
	if (!meuClan) return "";
	const cor = meuClan.clan.cor ?? "§e";
	const rotulo = meuClan.clan.tag ? meuClan.clan.tag : meuClan.nome;
	// Mesma "borda" cinza escuro suave usada nas tags de rank: §8[§r§lNome§r§8].
	return `§8[§r§l${cor}${rotulo}§r§8]§r `;
}

// So o lider pode mudar. "icone" tem que ser um dos valores em ICONES_CLAN.
export function definirIconeClan(player, icone) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		player.sendMessage("§cVoce nao faz parte de nenhum clan.");
		return;
	}
	if (meuClan.clan.lider !== player.id) {
		player.sendMessage("§cApenas o lider do clan pode mudar o icone.");
		return;
	}
	if (!ICONES_CLAN.some((i) => i.icone === icone)) {
		player.sendMessage("§cIcone invalido.");
		return;
	}

	const clans = getClans();
	clans[meuClan.nome].icone = icone;
	saveClans(clans);
	player.sendMessage("§aIcone do clan atualizado!");
}

export function getIconeClan(nomeClan) {
	const clans = getClans();
	return clans[nomeClan]?.icone ?? ICONE_PADRAO_CLAN;
}
export function definirCorClan(player, codigoCor) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		player.sendMessage("§cVoce nao faz parte de nenhum clan.");
		return;
	}
	if (meuClan.clan.lider !== player.id) {
		player.sendMessage("§cApenas o lider do clan pode mudar a cor.");
		return;
	}

	codigoCor = (codigoCor ?? "").trim();
	if (!/^§[0-9a-fk-or]$/i.test(codigoCor)) {
		player.sendMessage("§cDigite um codigo de cor valido, tipo §e3§c pra §3azul§c.");
		return;
	}

	const clans = getClans();
	clans[meuClan.nome].cor = `§l${codigoCor}`;
	saveClans(clans);
	player.sendMessage(`§aCor do clan atualizada!`);
}

// Lista todos os clans com o total de abates dos membros online, do maior pro menor.
export function getRankingClans() {
	const clans = getClans();
	return Object.keys(clans)
		.map((nome) => {
			const clan = clans[nome];
			const totalAbates = clan.members.reduce((soma, id) => {
				const p = world.getAllPlayers().find((pl) => pl.id === id);
				return soma + (p ? getAbates(p) : 0);
			}, 0);
			return { nome, totalAbates, membros: clan.members.length };
		})
		.sort((a, b) => b.totalAbates - a.totalAbates);
}

// ===== WARP DO CLAN =====
// So o lider cria/remove. So os membros do clan (e o lider) podem ver/usar.

const LIMITE_WARPS_CLAN = 5;

export function getWarpsClan(player) {
	const meuClan = getMeuClan(player);
	return meuClan ? meuClan.clan.warps ?? {} : {};
}

export function criarWarpClan(player, nome) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		player.sendMessage("§cVoce nao faz parte de nenhum clan.");
		return;
	}
	if (meuClan.clan.lider !== player.id) {
		player.sendMessage("§cApenas o lider do clan pode criar warps do clan.");
		return;
	}

	nome = (nome ?? "").trim();
	if (!nome) {
		player.sendMessage("§cDigite um nome valido para a warp.");
		return;
	}

	const clans = getClans();
	const clan = clans[meuClan.nome];
	if (!clan.warps) clan.warps = {};

	if (Object.keys(clan.warps).length >= LIMITE_WARPS_CLAN && !clan.warps[nome]) {
		player.sendMessage(`§cSeu clan ja atingiu o limite de §e${LIMITE_WARPS_CLAN}§c warps.`);
		return;
	}

	clan.warps[nome] = {
		x: Math.floor(player.location.x),
		y: Math.floor(player.location.y),
		z: Math.floor(player.location.z),
		dimension: player.dimension.id
	};
	saveClans(clans);
	player.sendMessage(`§aWarp do clan §e${nome}§a criada com sucesso!`);
}

export function removerWarpClan(player, nome) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		player.sendMessage("§cVoce nao faz parte de nenhum clan.");
		return;
	}
	if (meuClan.clan.lider !== player.id) {
		player.sendMessage("§cApenas o lider do clan pode remover warps do clan.");
		return;
	}

	const clans = getClans();
	const clan = clans[meuClan.nome];
	if (!clan.warps || !clan.warps[nome]) {
		player.sendMessage(`§cNao existe uma warp do clan chamada §e${nome}§c.`);
		return;
	}

	delete clan.warps[nome];
	saveClans(clans);
	player.sendMessage(`§aWarp do clan §e${nome}§a removida.`);
}

export function teleportarWarpClan(player, nome) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		player.sendMessage("§cVoce nao faz parte de nenhum clan.");
		return;
	}

	const warp = (meuClan.clan.warps ?? {})[nome];
	if (!warp) {
		player.sendMessage(`§cNao existe uma warp do clan chamada §e${nome}§c.`);
		return;
	}

	const cooldownWarpClan = getPermissoes(player).cooldownWarpClan;
	if (emCooldown(player, "warpclan", cooldownWarpClan)) return;

	teleportarComContagem(player, () => {
		const dimension = world.getDimension(warp.dimension.replace("minecraft:", ""));
		player.teleport({ x: warp.x, y: warp.y, z: warp.z }, { dimension });
		player.sendMessage(`§aVoce foi teleportado para a warp do clan §e${nome}§a.`);
	});
}
