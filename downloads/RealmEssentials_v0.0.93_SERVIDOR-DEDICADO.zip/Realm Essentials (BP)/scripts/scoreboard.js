import { world, DisplaySlotId, ObjectiveSortOrder } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { getTps } from "./tps.js";
import { getTotalAbates, getTopRecordeCps, getUltimoGolpe, getUltimoAbate } from "./combat.js";
import { getTotalSaldo } from "./money.js";
import { getRankingClans } from "./clan.js";

// Scoreboard (a "sidebar" do lado direito da tela). Importante: essa
// sidebar do Minecraft e sempre igual pra todo mundo conectado - nao tem
// como o Rank ou o Saldo aparecerem diferentes pra cada jogador ao mesmo
// tempo, isso e uma limitacao do jogo mesmo (nao da API). Por isso os
// tipos de linha aqui mostram numeros gerais do servidor (total de
// abates, total de moedas em circulacao, recorde de cps, etc) em vez de
// "seu" abate ou "seu" saldo.

const KEY = "re:scoreboard";
const OBJECTIVE_ID = "re_scoreboard";
const LIMITE_LINHAS = 20;

const TIPOS_LINHA = [
	{ id: "divisor", nome: "Divisor animado" },
	{ id: "texto", nome: "Texto livre" },
	{ id: "textoAnimado", nome: "Texto animado (cores mudando)" },
	{ id: "duasColunas", nome: "Duas colunas (2 status juntos)" },
	{ id: "data", nome: "Data real" },
	{ id: "online", nome: "Jogadores online" },
	{ id: "tempoOnline", nome: "Tempo online (do servidor)" },
	{ id: "abates", nome: "Abates (total do servidor)" },
	{ id: "moedas", nome: "Moedas (total em circulacao)" },
	{ id: "cps", nome: "CPS (recorde)" },
	{ id: "cpsAoVivo", nome: "CPS ao vivo (de quem bateu agora)" },
	{ id: "abateAoVivo", nome: "Ultimo abate (ao vivo)" },
	{ id: "xp", nome: "XP (maior nivel online)" },
	{ id: "clan", nome: "Facao/Clan com mais abates" },
	{ id: "tps", nome: "TPS do servidor" }
];

// Os tipos "simples" sao os que tem so um rotulo + um valor - sao esses
// que podem ser combinados numa linha de "duas colunas".
const TIPOS_SIMPLES = TIPOS_LINHA.filter((t) => !["divisor", "texto", "textoAnimado", "duasColunas"].includes(t.id));

export function getTiposLinha() {
	return TIPOS_LINHA;
}

export function getTiposSimples() {
	return TIPOS_SIMPLES;
}

function linhaPadrao() {
	return [
		{ id: gerarId(), tipo: "data" },
		{ id: gerarId(), tipo: "divisor", cor: "§7" },
		{ id: gerarId(), tipo: "duasColunas", tipo1: "cpsAoVivo", rotulo1: "CPS", tipo2: "tps", rotulo2: "TPS" },
		{ id: gerarId(), tipo: "divisor", cor: "§7" },
		{ id: gerarId(), tipo: "online", rotulo: "Online" },
		{ id: gerarId(), tipo: "clan", rotulo: "Clã" },
		{ id: gerarId(), tipo: "moedas", rotulo: "Moedas" },
		{ id: gerarId(), tipo: "divisor", cor: "§7" },
		{ id: gerarId(), tipo: "xp", rotulo: "XP" },
		{ id: gerarId(), tipo: "abates", rotulo: "Abates" },
		{ id: gerarId(), tipo: "divisor", cor: "§7" }
	];
}

function configPadrao() {
	return { ativo: false, titulo: "§6§lRealm Essentials", linhas: linhaPadrao() };
}

function gerarId() {
	return `${Date.now()}_${Math.floor(Math.random() * 10000)}`;
}

export function getConfig() {
	const salvo = getData(KEY, null);
	if (!salvo) return configPadrao();
	return { ...configPadrao(), ...salvo, linhas: salvo.linhas ?? linhaPadrao() };
}

function salvarConfig(config) {
	setData(KEY, config);
}

export function definirAtivo(ativo) {
	const config = getConfig();
	config.ativo = !!ativo;
	salvarConfig(config);
	if (!config.ativo) desligarSidebar();
}

export function definirTitulo(titulo) {
	const config = getConfig();
	config.titulo = (titulo ?? "").trim() || "§6§lRealm Essentials";
	salvarConfig(config);
}

export function adicionarLinha(tipo, dados) {
	const config = getConfig();
	if (config.linhas.length >= LIMITE_LINHAS) return false;
	if (!TIPOS_LINHA.some((t) => t.id === tipo)) return false;

	config.linhas.push({ id: gerarId(), tipo, ...dados });
	salvarConfig(config);
	return true;
}

export function editarLinha(id, dados) {
	const config = getConfig();
	const linha = config.linhas.find((l) => l.id === id);
	if (!linha) return false;
	Object.assign(linha, dados);
	salvarConfig(config);
	return true;
}

export function removerLinha(id) {
	const config = getConfig();
	config.linhas = config.linhas.filter((l) => l.id !== id);
	salvarConfig(config);
}

export function moverLinha(id, direcao) {
	const config = getConfig();
	const indice = config.linhas.findIndex((l) => l.id === id);
	if (indice === -1) return;
	const novoIndice = indice + direcao;
	if (novoIndice < 0 || novoIndice >= config.linhas.length) return;
	const [linha] = config.linhas.splice(indice, 1);
	config.linhas.splice(novoIndice, 0, linha);
	salvarConfig(config);
}

export function restaurarPadrao() {
	const config = getConfig();
	config.linhas = linhaPadrao();
	salvarConfig(config);
}

const inicioServidor = Date.now();

function formatarTempoOnline() {
	const segundos = Math.floor((Date.now() - inicioServidor) / 1000);
	const dias = Math.floor(segundos / 86400);
	const horas = Math.floor((segundos % 86400) / 3600);
	const minutos = Math.floor((segundos % 3600) / 60);
	return `${dias}d, ${horas}h, ${minutos}m`;
}

function formatarDataReal() {
	const agora = new Date();
	const dia = String(agora.getDate()).padStart(2, "0");
	const mes = String(agora.getMonth() + 1).padStart(2, "0");
	return `${dia}/${mes}/${agora.getFullYear()}`;
}

function maiorNivelOnline() {
	const players = world.getAllPlayers();
	if (players.length === 0) return 0;
	return Math.max(0, ...players.map((p) => p.level ?? 0));
}

let frameAnimacao = 0;

const LARGURA_DIVISOR = 12;

// Uma seta anda pelos tracos, vai ate o final e volta (ping-pong). Quando
// esta indo pra frente usa ">"; quando esta voltando usa "<" - igual o
// exemplo que foi pedido.
function montarDivisorAnimado(cor) {
	const corFinal = cor && cor.length ? cor : "§7";
	const maxPos = LARGURA_DIVISOR - 1;
	const ciclo = maxPos * 2;
	const posicaoNoCiclo = frameAnimacao % ciclo;
	const indoPraFrente = posicaoNoCiclo <= maxPos;
	const posicao = indoPraFrente ? posicaoNoCiclo : ciclo - posicaoNoCiclo;
	const seta = indoPraFrente ? ">" : "<";

	let saida = corFinal;
	for (let i = 0; i < LARGURA_DIVISOR; i++) {
		saida += i === posicao ? `§f${seta}${corFinal}` : "-";
	}
	return `${saida}§r`;
}

// Mesma ideia do texto animado do texto voador: cada letra pega uma cor
// da lista, deslocada por frame, dando um efeito de onda de cor.
function montarTextoAnimado(texto, cores) {
	const paleta = cores && cores.length === 3 ? cores : ["§d", "§b", "§e"];
	let saida = "";
	let posicao = 0;
	for (const letra of texto) {
		if (letra === " ") {
			saida += letra;
			continue;
		}
		saida += `${paleta[(posicao + frameAnimacao) % paleta.length]}§l${letra}`;
		posicao++;
	}
	return saida || " ";
}

// So o "valor" de um tipo simples, sem rotulo - usado tanto pra montar uma
// linha normal quanto pra montar as "duas colunas".
function calcularValor(tipo) {
	switch (tipo) {
		case "data":
			return formatarDataReal();
		case "online":
			return String(world.getAllPlayers().length);
		case "tempoOnline":
			return formatarTempoOnline();
		case "abates":
			return String(getTotalAbates());
		case "moedas":
			return String(getTotalSaldo());
		case "cps":
			return String(getTopRecordeCps(1)[0]?.valor ?? 0);
		case "cpsAoVivo":
			return String(getUltimoGolpe()?.cps ?? 0);
		case "abateAoVivo":
			return String(getUltimoAbate()?.total ?? 0);
		case "xp":
			return String(maiorNivelOnline());
		case "clan": {
			const top = getRankingClans()[0];
			return top ? `${top.nome} (${top.totalAbates})` : "Nenhuma";
		}
		case "tps":
			return String(getTps());
		default:
			return "";
	}
}

function renderizarLinha(linha) {
	switch (linha.tipo) {
		case "texto":
			return (linha.texto ?? "").replaceAll("\\n", "\n") || " ";
		case "textoAnimado":
			return montarTextoAnimado((linha.texto ?? "").replaceAll("\\n", " "), linha.cores);
		case "divisor":
			// Compatibilidade com scoreboards antigos que ainda tem "cores"
			// (lista de 3) em vez do campo "cor" (unico) atual.
			return montarDivisorAnimado(linha.cor ?? linha.cores?.[0]);
		case "duasColunas":
			return `§b${linha.rotulo1 ?? "A"}:§f${calcularValor(linha.tipo1)} §7:§r §b${linha.rotulo2 ?? "B"}:§f${calcularValor(linha.tipo2)}`;
		case "data":
			// Sem marcador, igual uma "legenda" logo abaixo do titulo.
			return `§7${calcularValor("data")}`;
		// Essas duas somem da sidebar de vez (nao mostram "0") quando
		// ninguem bateu/matou nos ultimos 3 segundos - ver VALIDADE_MS.
		case "cpsAoVivo": {
			const golpe = getUltimoGolpe();
			if (!golpe) return "";
			return `§7×§r §b${linha.rotulo ?? "CPS"}: §f${golpe.nome} (${golpe.cps})`;
		}
		case "abateAoVivo": {
			const abate = getUltimoAbate();
			if (!abate) return "";
			return `§7×§r §b${linha.rotulo ?? "Ultimo Abate"}: §f${abate.nome} (${abate.total})`;
		}
		default: {
			const rotulo = linha.rotulo ?? linha.tipo;
			return `§7×§r §b${rotulo}: §f${calcularValor(linha.tipo)}`;
		}
	}
}

function desligarSidebar() {
	try {
		world.scoreboard.clearObjectiveAtDisplaySlot(DisplaySlotId.Sidebar);
	} catch (erro) {
		console.warn(`Erro ao desligar o scoreboard: ${erro}`);
	}
	try {
		const objetivo = world.scoreboard.getObjective(OBJECTIVE_ID);
		if (objetivo) world.scoreboard.removeObjective(objetivo);
	} catch (erro) {
		console.warn(`Erro ao remover objetivo do scoreboard: ${erro}`);
	}
}

// Chamado periodicamente (main.js). Reconstroi a sidebar do zero a cada
// chamada - com poucas linhas e chamando 1x por segundo, o custo e baixo,
// e evita entrada duplicada/velha quando uma linha muda de texto (o nome
// da "linha" no scoreboard e a propria identidade dela, entao pra mudar o
// texto precisa remover e recriar mesmo).
export function tickScoreboard() {
	const config = getConfig();
	if (!config.ativo) return;

	frameAnimacao++;

	try {
		let objetivo = world.scoreboard.getObjective(OBJECTIVE_ID);
		if (!objetivo) objetivo = world.scoreboard.addObjective(OBJECTIVE_ID, config.titulo);

		const atual = world.scoreboard.getObjectiveAtDisplaySlot(DisplaySlotId.Sidebar);
		if (!atual?.objective || atual.objective.id !== OBJECTIVE_ID) {
			world.scoreboard.setObjectiveAtDisplaySlot(DisplaySlotId.Sidebar, {
				objective: objetivo,
				sortOrder: ObjectiveSortOrder.Descending
			});
		}

		for (const identidade of objetivo.getParticipants()) {
			try {
				objetivo.removeParticipant(identidade);
			} catch (erro) {
				console.warn(`Erro ao limpar linha antiga do scoreboard: ${erro}`);
			}
		}

		const total = config.linhas.length;
		config.linhas.forEach((linha, indice) => {
			const texto = renderizarLinha(linha);
			if (!texto) return;
			// Cada linha do scoreboard e identificada pelo proprio texto - se
			// duas linhas renderizassem o mesmo texto (ex: dois divisores no
			// mesmo frame da animacao) elas colariam numa unica linha. Um
			// numero de "§r" invisiveis no final, diferente por linha, evita
			// isso sem mudar nada visualmente.
			const textoUnico = `${texto}${"§r".repeat(indice + 1)}`;
			try {
				objetivo.setScore(textoUnico, total - indice);
			} catch (erro) {
				console.warn(`Erro ao desenhar linha do scoreboard: ${erro}`);
			}
		});
	} catch (erro) {
		console.warn(`Erro ao atualizar o scoreboard: ${erro}`);
	}
}
