import { world } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { getCps } from "./combat.js";
import { congelarJogador, kickJogador } from "./moderation.js";
import { ehDono } from "./permissoes.js";
import { logar, escapar } from "./discordLogs.js";

const KEY = "re:anticheat";
const MAX_DETECCOES_LOG = 30;

function configPadrao() {
	return { ativo: false, limiteCps: 20, acao: "congelar", deteccoes: 0, log: [] };
}

export function getConfig() {
	return { ...configPadrao(), ...getData(KEY, {}) };
}

function saveConfig(config) {
	setData(KEY, config);
}

export function ativar(player) {
	const config = getConfig();
	config.ativo = true;
	saveConfig(config);
	player.sendMessage("§aLimitador de CPS ativado.");
}

export function desativar(player) {
	const config = getConfig();
	config.ativo = false;
	saveConfig(config);
	player.sendMessage("§cLimitador de CPS desativado.");
}

export function definirLimite(player, valor) {
	const numero = Number(valor);
	if (!Number.isFinite(numero) || numero < 1 || numero > 1000) {
		player.sendMessage("§cDigite um numero valido entre 1 e 1000.");
		return;
	}
	const config = getConfig();
	config.limiteCps = Math.floor(numero);
	saveConfig(config);
	player.sendMessage(`§aLimite de CPS definido para §e${config.limiteCps}§a.`);
}

export function definirAcao(player, acao) {
	if (!["avisar", "congelar", "expulsar"].includes(acao)) return;
	const config = getConfig();
	config.acao = acao;
	saveConfig(config);
	player.sendMessage(`§aAcao ao detectar definida para §e${acao}§a.`);
}

export function limparLogs(player) {
	const config = getConfig();
	config.deteccoes = 0;
	config.log = [];
	saveConfig(config);
	player.sendMessage("§aLogs de deteccao limpos.");
}

// Chamado a cada golpe do jogador (main.js), depois de registrar o cps.
export function checarClicker(player) {
	const config = getConfig();
	if (!config.ativo) return;

	const cps = getCps(player.id);
	if (cps <= config.limiteCps) return;

	config.deteccoes++;
	config.log.unshift({
		nome: player.name,
		cps,
		data: new Date().toISOString(),
		x: Math.floor(player.location.x),
		y: Math.floor(player.location.y),
		z: Math.floor(player.location.z)
	});
	config.log = config.log.slice(0, MAX_DETECCOES_LOG);
	saveConfig(config);

	logar("anticheat", "CPS suspeito", `**${escapar(player.name)}** passou do limite de CPS.`, [
		{ nome: "CPS", valor: String(cps) },
		{ nome: "Limite", valor: String(config.limiteCps) },
		{ nome: "Ação", valor: config.acao },
		{ nome: "Local", valor: `${Math.floor(player.location.x)}, ${Math.floor(player.location.y)}, ${Math.floor(player.location.z)}` }
	]);

	aplicarAcao(player, config);
}

// Avisa todo mundo com a tag "dono" (mesma tag usada no resto do addon pros
// comandos de administracao - antes isso usava "isOp()", que nao e a mesma
// coisa e por isso o aviso nunca aparecia pra ninguem no chat).
function avisarDonos(mensagem) {
	world
		.getAllPlayers()
		.filter((p) => ehDono(p))
		.forEach((dono) => {
			try {
				dono.sendMessage(mensagem);
			} catch (erro) {
				console.warn(`Erro ao avisar dono sobre deteccao de cps: ${erro}`);
			}
		});
}

function aplicarAcao(player, config) {
	try {
		if (config.acao === "avisar") {
			player.sendMessage("§cVoce foi detectado usando cliques automaticos.");
			avisarDonos(`§c[CPS] §e${player.name}§c foi detectado com CPS alto.`);
			return;
		}

		if (config.acao === "congelar") {
			congelarJogador(player);
			player.sendMessage("§cVoce foi congelado por 5 segundos por CPS suspeito. Um admin vai verificar.");
			avisarDonos(`§c[CPS] §e${player.name}§c foi congelado automaticamente por CPS alto.`);
			return;
		}

		if (config.acao === "expulsar") {
			kickJogador(player, "Cliques automaticos detectados.");
			avisarDonos(`§c[CPS] §e${player.name}§c foi expulso automaticamente por CPS alto.`);
		}
	} catch (erro) {
		console.warn(`Erro ao aplicar acao do limitador de cps: ${erro}`);
	}
}
