import { world } from "@minecraft/server";
import { ativo } from "./featureFlags.js";
import { getData, setData } from "./database.js";
import { estaEmAreaSegura } from "./protectedArea.js";

const KEY_CONFIG = "re:combatlog:config";

function configPadrao() {
	return { duracaoSegundos: 15 };
}

export function getConfigCombatLog() {
	return { ...configPadrao(), ...getData(KEY_CONFIG, {}) };
}

export function definirDuracaoCombatLog(segundos) {
	const numero = Math.floor(Number(segundos));
	if (!Number.isFinite(numero) || numero < 1) return false;
	setData(KEY_CONFIG, { duracaoSegundos: Math.min(600, numero) });
	return true;
}

const emCombate = new Map();

// Chamado quando um jogador acerta outro (PVP).
export function registrarCombate(atacante, alvo) {
	if (!ativo("combateLog")) return;
	const agora = Date.now();
	const duracaoMs = getConfigCombatLog().duracaoSegundos * 1000;
	emCombate.set(atacante.id, { oponenteNome: alvo.name, expiraEm: agora + duracaoMs });
	emCombate.set(alvo.id, { oponenteNome: atacante.name, expiraEm: agora + duracaoMs });
}

// Trava de teleporte por combate PVP: independente da flag "combateLog"
// (que so controla o castigo de perder item ao sair), essa aqui fica
// sempre ativa e so serve pra bloquear teleporte enquanto luta.
const DURACAO_TRAVA_TELEPORTE_MS = 10 * 1000;
const ultimoCombatePvp = new Map();

export function registrarCombatePvp(atacante, alvo) {
	const expiraEm = Date.now() + DURACAO_TRAVA_TELEPORTE_MS;
	ultimoCombatePvp.set(atacante.id, expiraEm);
	ultimoCombatePvp.set(alvo.id, expiraEm);
}

export function estaEmCombate(player) {
	const expiraEm = ultimoCombatePvp.get(player.id);
	return !!expiraEm && Date.now() < expiraEm;
}

// Tira o jogador do estado de combate na hora (usado quando ele entra numa
// area segura - ele nao deve continuar travado nem correndo risco de
// perder item so por ter levado um golpe antes de chegar la).
function sairDoCombateAgora(player) {
	emCombate.delete(player.id);
	ultimoCombatePvp.delete(player.id);
}

// Mostra "Em combate com Fulano - 12s" na actionbar de quem esta em
// combate, atualizando o tempo restante. Quando o tempo acaba, mostra
// "Voce saiu do combate" e para de mostrar. Tambem cancela o combate na
// hora se o jogador entrar numa area segura (sem pvp) - la dentro ele nao
// pode continuar "em combate" so por ter apanhado antes de entrar.
export function tickCombatLog() {
	if (!ativo("combateLog")) return;
	const agora = Date.now();

	for (const player of world.getAllPlayers()) {
		let emAreaSegura = false;
		try {
			emAreaSegura = estaEmAreaSegura(player);
		} catch (erro) {
			console.warn(`Erro ao checar area segura no combat log: ${erro}`);
		}

		if (emAreaSegura && (emCombate.has(player.id) || ultimoCombatePvp.has(player.id))) {
			sairDoCombateAgora(player);
			try {
				player.onScreenDisplay.setActionBar("§aVoce esta em uma area segura, o combate foi encerrado!");
			} catch (erro) {
				console.warn(`Erro ao avisar fim de combate por area segura: ${erro}`);
			}
			continue;
		}

		const info = emCombate.get(player.id);
		if (!info) continue;

		const restanteMs = info.expiraEm - agora;

		if (restanteMs <= 0) {
			emCombate.delete(player.id);
			try {
				player.onScreenDisplay.setActionBar("§aVoce saiu do combate!");
			} catch (erro) {
				console.warn(`Erro ao avisar fim de combate: ${erro}`);
			}
			continue;
		}

		const segundosRestantes = Math.ceil(restanteMs / 1000);
		try {
			player.onScreenDisplay.setActionBar(`§cEm combate com §f${info.oponenteNome} §c- §f${segundosRestantes}s`);
		} catch (erro) {
			console.warn(`Erro ao mostrar combat log na actionbar: ${erro}`);
		}
	}
}

// Chamado quando o jogador sai do mundo. Se ele estava em combate ativo de
// verdade (nao numa area segura), morre: dropa o inventario inteiro no
// chao e e contado como morte, igual sairia se tivesse continuado
// lutando. Numa area segura (sem pvp) isso nunca acontece - ver
// estaEmAreaSegura.
export function processarSaidaEmCombate(player) {
	if (!ativo("combateLog")) return;

	const info = emCombate.get(player.id);
	if (!info || Date.now() > info.expiraEm) return;

	try {
		if (estaEmAreaSegura(player)) {
			sairDoCombateAgora(player);
			return;
		}
	} catch (erro) {
		console.warn(`Erro ao checar area segura na saida em combate: ${erro}`);
	}

	try {
		const inventory = player.getComponent("minecraft:inventory")?.container;
		if (inventory) {
			for (let i = 0; i < inventory.size; i++) {
				const item = inventory.getItem(i);
				if (item) {
					player.dimension.spawnItem(item, player.location);
					inventory.setItem(i, undefined);
				}
			}
		}
	} catch (erro) {
		console.warn(`Erro ao dropar itens por combat log: ${erro}`);
	}

	// Mata o jogador de verdade (nao so tira os itens) - assim ele conta
	// como morto igual contaria se tivesse ficado lutando.
	try {
		player.kill();
	} catch (erro) {
		console.warn(`Erro ao matar jogador por combat log: ${erro}`);
	}

	try {
		world.sendMessage(`§c${player.name} morreu ao sair do jogo durante um combate!`);
	} catch (erro) {
		console.warn(`Erro ao avisar combat log: ${erro}`);
	}

	sairDoCombateAgora(player);
}
