import { adicionarSaldo } from "./money.js";

// Chefes: recompensa bem maior.
const MOBS_BOSS = new Set(["minecraft:wither", "minecraft:warden", "minecraft:ender_dragon"]);

// Mobs do End.
const MOBS_END = new Set(["minecraft:enderman", "minecraft:shulker", "minecraft:endermite"]);

// Mobs do Nether.
const MOBS_NETHER = new Set([
	"minecraft:blaze",
	"minecraft:ghast",
	"minecraft:piglin",
	"minecraft:piglin_brute",
	"minecraft:hoglin",
	"minecraft:zoglin",
	"minecraft:magma_cube",
	"minecraft:wither_skeleton",
	"minecraft:strider"
]);

// Mobs pacificos.
const MOBS_PASSIVOS = new Set([
	"minecraft:cow",
	"minecraft:mooshroom",
	"minecraft:pig",
	"minecraft:sheep",
	"minecraft:chicken",
	"minecraft:rabbit",
	"minecraft:horse",
	"minecraft:donkey",
	"minecraft:mule",
	"minecraft:llama",
	"minecraft:trader_llama",
	"minecraft:villager",
	"minecraft:wandering_trader",
	"minecraft:cat",
	"minecraft:wolf",
	"minecraft:fox",
	"minecraft:bee",
	"minecraft:squid",
	"minecraft:glow_squid",
	"minecraft:turtle",
	"minecraft:panda",
	"minecraft:parrot",
	"minecraft:ocelot",
	"minecraft:bat",
	"minecraft:cod",
	"minecraft:salmon",
	"minecraft:pufferfish",
	"minecraft:tropicalfish",
	"minecraft:axolotl",
	"minecraft:frog",
	"minecraft:allay",
	"minecraft:camel",
	"minecraft:sniffer",
	"minecraft:goat"
]);

const VALOR_BOSS = 1000;
const VALOR_END = 80;
const VALOR_NETHER = 70;
const VALOR_PASSIVO = 25;
const VALOR_HOSTIL = 50; // qualquer outro mob (zumbi, esqueleto, aranha, creeper, etc.)

function calcularRecompensa(typeId) {
	if (MOBS_BOSS.has(typeId)) return VALOR_BOSS;
	if (MOBS_END.has(typeId)) return VALOR_END;
	if (MOBS_NETHER.has(typeId)) return VALOR_NETHER;
	if (MOBS_PASSIVOS.has(typeId)) return VALOR_PASSIVO;
	return VALOR_HOSTIL;
}

// Chamado no entityDie: se um jogador matou um mob (nao outro jogador),
// da o saldo correspondente ao tipo do mob.
export function processarRecompensaDeMob(mob, matador) {
	if (mob.typeId === "minecraft:player") return;

	const valor = calcularRecompensa(mob.typeId);
	adicionarSaldo(matador, valor);
	matador.sendMessage(`§fVoce ganhou \uE102§e§l${valor}§r §7(matou ${mob.typeId.replace("minecraft:", "")})`);
}
