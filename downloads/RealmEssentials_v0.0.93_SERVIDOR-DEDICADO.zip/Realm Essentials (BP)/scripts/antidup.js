import { world, system } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { congelarJogador, kickJogador } from "./moderation.js";
import { ehDono } from "./permissoes.js";
import { logar, escapar } from "./discordLogs.js";

const KEY = "re:antidup";
const MAX_LOG = 30;

// Itens monitorados por padrao, com o limite de ganho permitido por intervalo.
function limiaresPadrao() {
	return {
		"minecraft:diamond": 32,
		"minecraft:netherite_ingot": 8,
		"minecraft:netherite_scrap": 16,
		"minecraft:totem_of_undying": 2,
		"minecraft:emerald": 32,
		"minecraft:nether_star": 1,
		"minecraft:enchanted_golden_apple": 1
	};
}

function configPadrao() {
	return {
		ativo: false,
		intervaloSegundos: 10,
		acao: "avisar",
		limiares: limiaresPadrao(),
		deteccoes: 0,
		acoesExecutadas: 0,
		suspeitos: [],
		log: []
	};
}

export function getConfig() {
	return { ...configPadrao(), ...getData(KEY, {}) };
}

function saveConfig(config) {
	setData(KEY, config);
}

const contagemAnterior = new Map();
let agendado = false;

export function ativar(player) {
	const config = getConfig();
	config.ativo = true;
	saveConfig(config);
	if (!agendado) {
		agendado = true;
		system.runTimeout(ciclo, config.intervaloSegundos * 20);
	}
	player.sendMessage("§aAnti-Dup ativado.");
}

export function desativar(player) {
	const config = getConfig();
	config.ativo = false;
	saveConfig(config);
	agendado = false;
	player.sendMessage("§cAnti-Dup desativado.");
}

export function definirIntervalo(player, segundos) {
	const numero = Number(segundos);
	if (!Number.isFinite(numero) || numero < 2) {
		player.sendMessage("§cDigite um numero valido (minimo 2 segundos).");
		return;
	}
	const config = getConfig();
	config.intervaloSegundos = Math.floor(numero);
	saveConfig(config);
	player.sendMessage(`§aIntervalo de auditoria definido para §e${config.intervaloSegundos}s§a.`);
}

export function definirAcao(player, acao) {
	if (!["avisar", "congelar", "expulsar"].includes(acao)) return;
	const config = getConfig();
	config.acao = acao;
	saveConfig(config);
	player.sendMessage(`§aAcao automatica definida para §e${acao}§a.`);
}

export function definirLimiar(player, typeId, valor) {
	typeId = (typeId ?? "").trim();
	const numero = Number(valor);
	if (!typeId || !Number.isFinite(numero) || numero <= 0) {
		player.sendMessage("§cDigite um item e um numero validos.");
		return;
	}
	const config = getConfig();
	config.limiares[typeId] = Math.floor(numero);
	saveConfig(config);
	player.sendMessage(`§a${typeId}§r§a agora tem limiar de §e${Math.floor(numero)}§a por intervalo.`);
}

export function removerLimiar(player, typeId) {
	const config = getConfig();
	delete config.limiares[typeId];
	saveConfig(config);
	player.sendMessage(`§aLimiar de §e${typeId}§a removido.`);
}

export function limparEstatisticas(player) {
	const config = getConfig();
	config.deteccoes = 0;
	config.acoesExecutadas = 0;
	config.suspeitos = [];
	config.log = [];
	saveConfig(config);
	player.sendMessage("§aEstatisticas e logs do Anti-Dup limpos.");
}

function contarItem(player, typeId) {
	const inventory = player.getComponent("minecraft:inventory")?.container;
	if (!inventory) return 0;
	let total = 0;
	for (let i = 0; i < inventory.size; i++) {
		const slot = inventory.getItem(i);
		if (slot && slot.typeId === typeId) total += slot.amount;
	}
	return total;
}

function registrarDeteccao(player, typeId, ganho, config) {
	config.deteccoes++;
	config.log.unshift({ nome: player.name, item: typeId, ganho, data: new Date().toISOString() });
	config.log = config.log.slice(0, MAX_LOG);

	if (!config.suspeitos.some((s) => s.nome === player.name && s.item === typeId)) {
		config.suspeitos.unshift({ nome: player.name, item: typeId, ganho, data: new Date().toISOString() });
		config.suspeitos = config.suspeitos.slice(0, MAX_LOG);
	}

	logar("anticheat", "Suspeita de duplicação de itens", `**${escapar(player.name)}** ganhou **${ganho}x** \`${escapar(typeId, 60)}\` num intervalo só.`, [
		{ nome: "Item", valor: typeId },
		{ nome: "Ganho", valor: String(ganho) },
		{ nome: "Ação", valor: config.acao }
	]);

	try {
		if (config.acao === "avisar") {
			world
				.getAllPlayers()
				.filter((p) => ehDono(p))
				.forEach((dono) =>
					dono.sendMessage(`§c[Anti-Dup] §e${player.name}§c recebeu §e${ganho}x ${typeId}§c num intervalo so.`)
				);
		} else if (config.acao === "congelar") {
			congelarJogador(player);
			player.sendMessage("§cVoce foi congelado por atividade suspeita de duplicacao. Um admin vai verificar.");
		} else if (config.acao === "expulsar") {
			kickJogador(player, "Atividade suspeita de duplicacao de itens.");
		}
		config.acoesExecutadas++;
	} catch (erro) {
		console.warn(`Erro ao aplicar acao do anti-dup: ${erro}`);
	}
}

function ciclo() {
	const config = getConfig();
	if (!config.ativo) {
		agendado = false;
		return;
	}

	world.getAllPlayers().forEach((player) => {
		const anterior = contagemAnterior.get(player.id) ?? {};
		const atual = {};

		for (const typeId of Object.keys(config.limiares)) {
			let total = 0;
			try {
				total = contarItem(player, typeId);
			} catch (erro) {
				console.warn(`Erro ao contar item no anti-dup: ${erro}`);
			}
			atual[typeId] = total;

			const antes = anterior[typeId] ?? total;
			const ganho = total - antes;
			if (ganho > config.limiares[typeId]) {
				registrarDeteccao(player, typeId, ganho, config);
			}
		}

		contagemAnterior.set(player.id, atual);
	});

	saveConfig(config);
	system.runTimeout(ciclo, Math.max(2, config.intervaloSegundos) * 20);
}

export function retomarSeAtivo() {
	const config = getConfig();
	if (config.ativo && !agendado) {
		agendado = true;
		system.runTimeout(ciclo, config.intervaloSegundos * 20);
	}
}
