import { system } from "@minecraft/server";
import { getData, setData, registrarAoFalharSalvar } from "./database.js";
import { webhookSuportado, enviarWebhook } from "./netAdapter.js";

// ===== LOGS DO ADDON =====
// Todo log vai pra 2 lugares:
//  1) um histórico dentro do jogo (funciona em Realm, mundo local e servidor);
//  2) o webhook do Discord (só em servidor dedicado, que é o único modo em que
//     o Minecraft deixa scripts acessarem a internet).

export { webhookSuportado };

const KEY_CONFIG = "re:logs:config";
const KEY_BUFFER = "re:logs:buffer";
const MAX_BUFFER = 60; // ~13KB, bem abaixo do limite de 32KB por chave
const MAX_FILA = 100;
const EMBEDS_POR_ENVIO = 10; // limite do Discord por mensagem
const INTERVALO_ENVIO_TICKS = 40; // 2s: respeita o rate limit do webhook
const FUSO_HORAS = -3; // horário de Brasília

export const CATEGORIAS = {
	entrada: { nome: "Entradas", cor: 0x57f287, icone: "🟢" },
	saida: { nome: "Saídas", cor: 0x95a5a6, icone: "⚪" },
	morte: { nome: "Mortes e abates", cor: 0xed4245, icone: "💀" },
	moderacao: { nome: "Moderação (ban, mute, kick...)", cor: 0xe67e22, icone: "🔨" },
	denuncia: { nome: "Denúncias", cor: 0xf1c40f, icone: "🚨" },
	anticheat: { nome: "Anti-cheat e anti-dup", cor: 0xe74c3c, icone: "🛡️" },
	comandos: { nome: "Comandos usados", cor: 0x3498db, icone: "⌨️" },
	chat: { nome: "Chat", cor: 0x9b59b6, icone: "💬" },
	economia: { nome: "Economia (transferências)", cor: 0x2ecc71, icone: "💰" },
	sistema: { nome: "Erros do sistema", cor: 0x992d22, icone: "⚠️" }
};

function configPadrao() {
	const categorias = {};
	for (const id of Object.keys(CATEGORIAS)) categorias[id] = id !== "chat"; // chat gera muito volume
	return { ativo: true, webhookUrl: "", categorias };
}

export function getConfigLogs() {
	const salvo = getData(KEY_CONFIG, {});
	const padrao = configPadrao();
	return {
		...padrao,
		...salvo,
		categorias: { ...padrao.categorias, ...(salvo.categorias ?? {}) }
	};
}

function salvarConfig(config) {
	setData(KEY_CONFIG, config);
}

const REGEX_WEBHOOK = /^https:\/\/(?:canary\.|ptb\.)?(?:discord|discordapp)\.com\/api\/(?:v\d+\/)?webhooks\/\d+\/[\w-]+$/;

// Vazio remove o webhook. Retorna false se a URL não parece um webhook do Discord.
export function definirWebhook(url) {
	url = (url ?? "").trim();
	if (url && !REGEX_WEBHOOK.test(url)) return false;
	const config = getConfigLogs();
	config.webhookUrl = url;
	salvarConfig(config);
	statusEnvio = { ok: null, status: null, quando: null };
	return true;
}

export function definirAtivoLogs(valor) {
	const config = getConfigLogs();
	config.ativo = !!valor;
	salvarConfig(config);
}

export function definirCategorias(mapa) {
	const config = getConfigLogs();
	for (const id of Object.keys(CATEGORIAS)) {
		if (id in mapa) config.categorias[id] = !!mapa[id];
	}
	salvarConfig(config);
}

// ===== TEXTO =====

// Tira os códigos de cor (§a, §l...) que o Discord mostraria como lixo.
export function limpar(texto, max = 1000) {
	return String(texto ?? "")
		.replace(/§./g, "")
		.slice(0, max);
}

// Impede que o texto de um jogador vire formatação/menção no Discord.
export function escapar(texto, max = 1000) {
	return limpar(texto, max).replace(/([\\*_`~|>])/g, "\\$1").replace(/@/g, "@\u200b");
}

// ===== HISTÓRICO DENTRO DO JOGO =====

let buffer = null; // carregado só depois do mundo abrir (não dá pra ler no início)
let bufferSujo = false;

function getBuffer() {
	if (buffer === null) buffer = getData(KEY_BUFFER, []);
	return buffer;
}

system.runInterval(() => {
	if (!bufferSujo || buffer === null) return;
	bufferSujo = false;
	setData(KEY_BUFFER, buffer);
}, 100);

export function getUltimosLogs(quantidade = 15) {
	return getBuffer().slice(0, quantidade);
}

export function limparHistorico() {
	buffer = [];
	bufferSujo = true;
}

export function formatarHora(iso) {
	const d = new Date(Date.parse(iso) + FUSO_HORAS * 3600 * 1000);
	const dois = (n) => String(n).padStart(2, "0");
	return `${dois(d.getUTCDate())}/${dois(d.getUTCMonth() + 1)} ${dois(d.getUTCHours())}:${dois(d.getUTCMinutes())}`;
}

// ===== ENVIO PRO DISCORD =====

let fila = [];
let enviando = false;
let pausadoAteTick = 0;
let statusEnvio = { ok: null, status: null, quando: null };

export function getStatusEnvio() {
	return { ...statusEnvio, pendentes: fila.length };
}

function enfileirar(embed) {
	if (fila.length >= MAX_FILA) fila.shift(); // descarta o mais antigo em vez de crescer sem fim
	fila.push(embed);
}

async function processarFila() {
	if (enviando || fila.length === 0 || system.currentTick < pausadoAteTick) return;

	const config = getConfigLogs();
	if (!webhookSuportado || !config.webhookUrl) {
		fila = [];
		return;
	}

	enviando = true;
	const lote = fila.splice(0, EMBEDS_POR_ENVIO);
	try {
		const res = await enviarWebhook(config.webhookUrl, {
			username: "Realm Essentials",
			allowed_mentions: { parse: [] },
			embeds: lote
		});
		const status = res?.status ?? 0;
		statusEnvio = { ok: status >= 200 && status < 300, status, quando: new Date().toISOString() };

		if (status === 429) {
			// Rate limit: devolve o lote pra frente da fila e espera um pouco.
			fila = lote.concat(fila).slice(0, MAX_FILA);
			pausadoAteTick = system.currentTick + 100;
		} else if (status >= 500) {
			fila = lote.concat(fila).slice(0, MAX_FILA);
			pausadoAteTick = system.currentTick + 200;
		}
		// 4xx (webhook apagado/inválido): descarta o lote; o status aparece no painel.
	} catch (erro) {
		statusEnvio = { ok: false, status: 0, quando: new Date().toISOString() };
		fila = lote.concat(fila).slice(0, MAX_FILA);
		pausadoAteTick = system.currentTick + 200;
		console.warn(`Erro ao enviar logs pro Discord: ${erro}`);
	} finally {
		enviando = false;
	}
}

system.runInterval(() => {
	processarFila();
}, INTERVALO_ENVIO_TICKS);

// ===== API PRINCIPAL =====
// logar("moderacao", "Jogador banido", "**Fulano** foi banido.", [{ nome: "Motivo", valor: "..." }])
// Nunca lança erro: log não pode derrubar o resto do addon.
export function logar(categoria, titulo, descricao = "", campos = []) {
	try {
		const config = getConfigLogs();
		const cat = CATEGORIAS[categoria];
		if (!config.ativo || !cat || config.categorias[categoria] === false) return;

		const agora = new Date().toISOString();

		const historico = getBuffer();
		historico.unshift({
			t: agora,
			c: categoria,
			a: limpar(titulo, 60),
			d: limpar(descricao, 140).replace(/\*\*/g, "")
		});
		if (historico.length > MAX_BUFFER) historico.length = MAX_BUFFER;
		bufferSujo = true;

		if (webhookSuportado && config.webhookUrl) {
			enfileirar({
				title: limpar(`${cat.icone} ${titulo}`, 256),
				description: limpar(descricao, 2000),
				color: cat.cor,
				timestamp: agora,
				fields: campos.slice(0, 10).map((c) => ({
					name: limpar(c.nome, 256) || "-",
					value: limpar(c.valor, 1024) || "-",
					inline: c.inline ?? true
				})),
				footer: { text: "Realm Essentials" }
			});
		}
	} catch (erro) {
		console.warn(`Erro ao registrar log: ${erro}`);
	}
}

export function enviarTeste(jogador) {
	logar("sistema", "Teste de log", `Mensagem de teste enviada por **${escapar(jogador?.name ?? "alguém")}**.`);
}

// Avisa no Discord quando algum dado do addon não conseguir ser gravado
// (no máximo 1 aviso por chave a cada 10 minutos, pra não virar spam).
const ultimoAvisoPorChave = new Map();
registrarAoFalharSalvar((chave) => {
	if (chave.startsWith("re:logs:")) return; // evita loop se o próprio log falhar
	const ultimo = ultimoAvisoPorChave.get(chave) ?? -Infinity;
	if (system.currentTick - ultimo < 12000) return;
	ultimoAvisoPorChave.set(chave, system.currentTick);
	logar(
		"sistema",
		"Falha ao salvar dados",
		`Não foi possível gravar \`${limpar(chave, 80)}\` (provável limite de 32KB). Esses dados voltam ao estado anterior se o servidor reiniciar.`
	);
});
