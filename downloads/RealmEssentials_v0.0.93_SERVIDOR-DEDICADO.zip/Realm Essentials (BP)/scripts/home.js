import { world } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { teleportarComContagem } from "./teleportCountdown.js";
import { getPermissoes } from "./rank.js";
import { emCooldown } from "./cooldown.js";
import { cobrarCusto } from "./money.js";

function key(player) {
	return `re:homes:${player.id}`;
}

export function getHomes(player) {
	return getData(key(player), {});
}

function saveHomes(player, homes) {
	setData(key(player), homes);
}

export function criarHome(player, nome) {
	nome = (nome ?? "").trim();
	if (!nome) {
		player.sendMessage("§cDigite um nome valido para a home.");
		return;
	}

	const homes = getHomes(player);
	const permissoes = getPermissoes(player);

	if (!homes[nome] && Object.keys(homes).length >= permissoes.limiteHomes) {
		player.sendMessage(`§cVoce atingiu o limite de §e${permissoes.limiteHomes}§c homes do seu rank.`);
		return;
	}

	homes[nome] = {
		x: Math.floor(player.location.x),
		y: Math.floor(player.location.y),
		z: Math.floor(player.location.z),
		dimension: player.dimension.id
	};
	saveHomes(player, homes);
	player.sendMessage(`§aHome §e${nome}§a criada com sucesso!`);
}

export function removerHome(player, nome) {
	const homes = getHomes(player);
	if (!homes[nome]) {
		player.sendMessage(`§cVoce nao possui uma home chamada §e${nome}§c.`);
		return;
	}

	delete homes[nome];
	saveHomes(player, homes);
	player.sendMessage(`§aHome §e${nome}§a removida com sucesso!`);
}

export function listarHomesTexto(player) {
	const nomes = Object.keys(getHomes(player));
	if (nomes.length === 0) {
		player.sendMessage("§cVoce ainda nao possui nenhuma home.");
		return;
	}
	player.sendMessage(`§aSuas homes: §e${nomes.join("§7, §e")}`);
}

export function teleportarHome(player, nome) {
	const homes = getHomes(player);
	const home = homes[nome];
	if (!home) {
		player.sendMessage(`§cVoce nao possui uma home chamada §e${nome}§c.`);
		return;
	}

	const permissoes = getPermissoes(player);
	if (emCooldown(player, "home", permissoes.cooldownHome)) return;
	if (!cobrarCusto(player, permissoes.custoHome)) return;

	teleportarComContagem(player, () => {
		const dimension = world.getDimension(home.dimension.replace("minecraft:", ""));
		player.teleport({ x: home.x, y: home.y, z: home.z }, { dimension });
		player.sendMessage(`§aVoce foi teleportado para a home §e${nome}§a.`);
	});
}
