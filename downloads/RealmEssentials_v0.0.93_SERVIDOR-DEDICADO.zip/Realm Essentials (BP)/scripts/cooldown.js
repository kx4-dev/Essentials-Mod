const ultimoUso = new Map();

// Retorna true (e avisa o jogador) se ele ainda estiver em cooldown.
export function emCooldown(player, acao, segundos) {
	if (!segundos || segundos <= 0) return false;

	const chave = `${player.id}:${acao}`;
	const agora = Date.now();
	const ultimo = ultimoUso.get(chave) ?? 0;
	const faltam = segundos * 1000 - (agora - ultimo);

	if (faltam > 0) {
		player.sendMessage(`§cEspere §e${Math.ceil(faltam / 1000)}s§c antes de fazer isso de novo.`);
		return true;
	}

	ultimoUso.set(chave, agora);
	return false;
}
