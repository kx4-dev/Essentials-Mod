import { world } from "@minecraft/server";
import { getPermissoes } from "./rank.js";
import { emCooldown } from "./cooldown.js";
import { cobrarCusto } from "./money.js";
import { teleportarComContagem } from "./teleportCountdown.js";
import { ativo } from "./featureFlags.js";

const ultimaLocalizacao = new Map();

// So guarda uma localizacao se o jogador morrer, e so se o "Comando !voltar"
// estiver ligado em Configuracao.
export function registrarLocalDeMorte(player) {
	if (!ativo("voltar")) return;
	ultimaLocalizacao.set(player.id, {
		x: player.location.x,
		y: player.location.y,
		z: player.location.z,
		dimension: player.dimension.id
	});
	player.sendMessage("§7Voce morreu! Use §a!voltar §7para retornar a este local.");
}

export function voltar(player) {
	if (!ativo("voltar")) {
		player.sendMessage("§cEsse recurso esta desativado no servidor.");
		return;
	}

	const permissoes = getPermissoes(player);
	if (emCooldown(player, "back", permissoes.cooldownBack)) return;

	const local = ultimaLocalizacao.get(player.id);
	if (!local) {
		player.sendMessage("§cVoce nao tem nenhum local de morte pra voltar ainda.");
		return;
	}

	if (!cobrarCusto(player, permissoes.custoBack)) return;

	teleportarComContagem(player, () => {
		const dimension = world.getDimension(local.dimension.replace("minecraft:", ""));
		player.teleport({ x: local.x, y: local.y, z: local.z }, { dimension });
		player.sendMessage("§aVoce voltou para o local da sua morte.");
		ultimaLocalizacao.delete(player.id);
	});
}
