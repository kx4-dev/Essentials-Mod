import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import {
	getConfig,
	ativar,
	desativar,
	definirIntervalo,
	definirAcao,
	definirLimiar,
	removerLimiar,
	limparEstatisticas
} from "./antidup.js";
import { formatarNomeItem } from "./itemNomes.js";
import { formatarHora } from "./discordLogs.js";

const ICONE_CONFIGURAR = "textures/ui/icon_setting";
const ICONE_LISTA = "textures/items/paper";
const ICONE_LIGAR = "textures/items/emerald";
const ICONE_DESLIGAR = "textures/ui/icon_trash";
const ICONE_ACAO = "textures/items/diamond_sword";
const ICONE_VOLTAR = "textures/icons/left_arrow";

const ACOES = [
	{ id: "avisar", nome: "Só avisar os donos" },
	{ id: "congelar", nome: "Congelar o jogador" },
	{ id: "expulsar", nome: "Expulsar o jogador" }
];

function nomeAcao(id) {
	return ACOES.find((a) => a.id === id)?.nome ?? id;
}

// aoVoltar: função que reabre o painel de onde o dono veio.
export function abrirMenuAntiDup(player, aoVoltar) {
	const config = getConfig();
	const qtdItens = Object.keys(config.limiares).length;

	const form = new ActionFormData()
		.title("Anti-Dup")
		.body(
			`§7Vigia o inventário dos jogadores e age quando alguém ganha itens valiosos rápido demais (sinal de duplicação).\n\n` +
				`§fStatus: ${config.ativo ? "§aAtivado" : "§cDesativado"}\n` +
				`§fAuditoria a cada: §e${config.intervaloSegundos}s\n` +
				`§fAção ao detectar: §e${nomeAcao(config.acao)}\n` +
				`§fItens monitorados: §e${qtdItens}\n` +
				`§fDetecções: §e${config.deteccoes} §7| §fAções executadas: §e${config.acoesExecutadas}`
		)
		.button(config.ativo ? "Desativar\n§7[Para de vigiar]" : "Ativar\n§7[Começa a vigiar]", config.ativo ? ICONE_DESLIGAR : ICONE_LIGAR)
		.button("Ação ao detectar\n§7[Avisar, congelar ou expulsar]", ICONE_ACAO)
		.button("Intervalo\n§7[De quanto em quanto tempo checa]", ICONE_CONFIGURAR)
		.button("Itens monitorados\n§7[Limites por item]", ICONE_CONFIGURAR)
		.button("Ver suspeitos\n§7[Quem foi detectado]", ICONE_LISTA)
		.button("Limpar estatísticas\n§7[Zera detecções e suspeitos]", ICONE_DESLIGAR)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		const reabrir = () => abrirMenuAntiDup(player, aoVoltar);

		switch (res.selection) {
			case 0:
				if (config.ativo) desativar(player);
				else ativar(player);
				reabrir();
				break;
			case 1:
				abrirAcao(player, config, reabrir);
				break;
			case 2:
				abrirIntervalo(player, config, reabrir);
				break;
			case 3:
				abrirItens(player, reabrir);
				break;
			case 4:
				abrirSuspeitos(player, config, reabrir);
				break;
			case 5:
				limparEstatisticas(player);
				reabrir();
				break;
			default:
				aoVoltar?.(player);
		}
	});
}

function abrirAcao(player, config, reabrir) {
	const indiceAtual = Math.max(0, ACOES.findIndex((a) => a.id === config.acao));
	new ModalFormData()
		.title("Ação ao detectar")
		.dropdown(
			"O que fazer quando detectar",
			ACOES.map((a) => a.nome),
			{ defaultValueIndex: indiceAtual }
		)
		.show(player)
		.then((res) => {
			if (!res.canceled && res.formValues) definirAcao(player, ACOES[res.formValues[0]]?.id);
			reabrir();
		});
}

function abrirIntervalo(player, config, reabrir) {
	new ModalFormData()
		.title("Intervalo da auditoria")
		.textField("Segundos entre cada checagem (mínimo 2)", "Ex: 10", { defaultValue: String(config.intervaloSegundos) })
		.show(player)
		.then((res) => {
			if (!res.canceled && res.formValues) definirIntervalo(player, res.formValues[0]);
			reabrir();
		});
}

function abrirItens(player, reabrirAnterior) {
	const config = getConfig();
	const ids = Object.keys(config.limiares);
	const lista = ids.length
		? ids.map((id) => `§f${formatarNomeItem(id)} §7(${id}): §e${config.limiares[id]}`).join("\n")
		: "§7Nenhum item monitorado.";

	new ActionFormData()
		.title("Itens monitorados")
		.body(`§7Limite = quanto o jogador pode ganhar do item entre duas auditorias.\n\n${lista}`)
		.button("Adicionar / alterar item", ICONE_LIGAR)
		.button("Remover item", ICONE_DESLIGAR)
		.button("Voltar", ICONE_VOLTAR)
		.show(player)
		.then((res) => {
			if (res.canceled) return;
			const reabrir = () => abrirItens(player, reabrirAnterior);

			if (res.selection === 0) {
				new ModalFormData()
					.title("Adicionar / alterar item")
					.textField("Item (ex: diamond ou minecraft:diamond)", "diamond")
					.textField("Limite por auditoria", "Ex: 32")
					.show(player)
					.then((r) => {
						if (!r.canceled && r.formValues) {
							let id = String(r.formValues[0] ?? "").trim().toLowerCase().replace(/\s+/g, "_");
							if (id && !id.includes(":")) id = `minecraft:${id}`;
							definirLimiar(player, id, r.formValues[1]);
						}
						reabrir();
					});
				return;
			}

			if (res.selection === 1) {
				if (ids.length === 0) {
					player.sendMessage("§cNão há itens pra remover.");
					reabrir();
					return;
				}
				new ModalFormData()
					.title("Remover item")
					.dropdown("Item a remover", ids.map((id) => formatarNomeItem(id)), { defaultValueIndex: 0 })
					.show(player)
					.then((r) => {
						if (!r.canceled && r.formValues) removerLimiar(player, ids[r.formValues[0]]);
						reabrir();
					});
				return;
			}

			reabrirAnterior();
		});
}

function abrirSuspeitos(player, config, reabrir) {
	const corpo = config.suspeitos.length
		? config.suspeitos
				.map((s) => `§f${s.nome} §7- ${formatarNomeItem(s.item)} +${s.ganho} §8(${formatarHora(s.data)})`)
				.join("\n")
		: "§7Nenhum suspeito registrado.";

	new ActionFormData()
		.title("Suspeitos")
		.body(corpo)
		.button("Voltar", ICONE_VOLTAR)
		.show(player)
		.then((res) => {
			if (!res.canceled) reabrir();
		});
}
