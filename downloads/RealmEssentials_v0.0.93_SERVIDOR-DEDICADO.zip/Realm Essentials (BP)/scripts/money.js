import { world } from "@minecraft/server";
import { getData, setData, getJogadoresConhecidos } from "./database.js";
import { getPermissoes } from "./rank.js";
import { logar, escapar } from "./discordLogs.js";

const KEY_CONFIG = "re:money:config";

function configPadrao() {
	return { saldoInicial: 0, saldoMaximo: 1000000 };
}

export function getConfigMoney() {
	return { ...configPadrao(), ...getData(KEY_CONFIG, {}) };
}

export function definirSaldoInicial(valor) {
	const numero = Math.floor(Number(valor));
	if (!Number.isFinite(numero) || numero < 0) return false;
	const config = getConfigMoney();
	config.saldoInicial = numero;
	setData(KEY_CONFIG, config);
	return true;
}

export function definirSaldoMaximo(valor) {
	const numero = Math.floor(Number(valor));
	if (!Number.isFinite(numero) || numero < 1) return false;
	const config = getConfigMoney();
	config.saldoMaximo = numero;
	setData(KEY_CONFIG, config);
	return true;
}

function key(player) {
	return `re:money:${player.id}`;
}

// Chamado uma unica vez, na primeira entrada do jogador no servidor, pra dar
// o saldo inicial configurado. Se ele ja tem saldo salvo (mesmo que seja 0
// porque gastou tudo), nao mexe em nada.
export function garantirSaldoInicial(player) {
	if (world.getDynamicProperty(key(player)) !== undefined) return;
	setSaldo(player, getConfigMoney().saldoInicial);
}

export function getSaldo(player) {
	return getData(key(player), 0);
}

function setSaldo(player, valor) {
	setData(key(player), valor);
}

export function adicionarSaldo(player, valor) {
	const limite = Math.min(getPermissoes(player).limiteSaldo, getConfigMoney().saldoMaximo);
	const novoSaldo = Math.min(limite, getSaldo(player) + valor);
	setSaldo(player, Math.max(0, novoSaldo));
}

// Cobra um custo em moedas. Retorna false (e avisa) se nao tiver saldo.
export function cobrarCusto(player, valor) {
	if (!valor || valor <= 0) return true;

	const saldo = getSaldo(player);
	if (saldo < valor) {
		player.sendMessage(`§cVoce precisa de §e${valor} moedas§c pra fazer isso. §7(Seu saldo: ${saldo})`);
		return false;
	}

	adicionarSaldo(player, -valor);
	player.sendMessage(`§7-${valor} moedas`);
	return true;
}

// Lista os N jogadores com mais saldo (inclui quem ta offline).
export function getTopSaldo(limite = 10) {
	const jogadores = getJogadoresConhecidos();
	return Object.entries(jogadores)
		.map(([id, nome]) => ({ nome, valor: getData(`re:money:${id}`, 0) }))
		.filter((j) => j.valor > 0)
		.sort((a, b) => b.valor - a.valor)
		.slice(0, limite);
}

// Soma o saldo de todo mundo que ja passou pelo servidor - usado no
// scoreboard, que so pode mostrar um numero geral (nao um por jogador).
export function getTotalSaldo() {
	const jogadores = getJogadoresConhecidos();
	return Object.keys(jogadores).reduce((soma, id) => soma + getData(`re:money:${id}`, 0), 0);
}

export function enviarDinheiro(remetente, destinatario, valorTexto) {
	const valor = Math.floor(Number(valorTexto));

	if (!Number.isFinite(valor) || valor <= 0) {
		remetente.sendMessage("§cDigite uma quantidade válida (número inteiro maior que zero).");
		return false;
	}

	if (remetente.id === destinatario.id) {
		remetente.sendMessage("§cVocê não pode enviar dinheiro pra si mesmo.");
		return false;
	}

	const saldo = getSaldo(remetente);
	if (saldo < valor) {
		remetente.sendMessage(`§cVocê não tem moedas suficientes. §7(Seu saldo: ${saldo})`);
		return false;
	}

	// Antes o dinheiro saía do remetente mesmo quando o destinatário já estava no
	// limite de saldo, e o que passava do limite simplesmente sumia.
	const limiteDestino = Math.min(getPermissoes(destinatario).limiteSaldo, getConfigMoney().saldoMaximo);
	if (getSaldo(destinatario) + valor > limiteDestino) {
		remetente.sendMessage(`§c${destinatario.name} não pode receber esse valor (limite de saldo: §e${limiteDestino}§c).`);
		return false;
	}

	setSaldo(remetente, saldo - valor);
	adicionarSaldo(destinatario, valor);

	remetente.sendMessage(`§aVocê enviou §e${valor} moedas§a para §e${destinatario.name}§a.`);
	destinatario.sendMessage(`§aVocê recebeu §e${valor} moedas§a de §e${remetente.name}§a.`);

	logar("economia", "Transferência de moedas", `**${escapar(remetente.name)}** enviou **${valor}** moedas para **${escapar(destinatario.name)}**.`, [
		{ nome: "Valor", valor: String(valor) },
		{ nome: "Saldo do remetente", valor: String(getSaldo(remetente)) }
	]);
	return true;
}
