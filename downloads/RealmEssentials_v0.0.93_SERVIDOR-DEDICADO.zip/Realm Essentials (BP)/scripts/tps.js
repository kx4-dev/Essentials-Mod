import { system } from "@minecraft/server";

// Estimativa simples de TPS: mede quanto tempo real passou entre uma leva de
// 20 ticks e outra. Se o servidor estiver rodando liso, 20 ticks levam ~1000ms
// (20 TPS). Se estiver com lag, leva mais tempo, entao o TPS calculado cai.
let ultimaMarcacaoMs = Date.now();
let tpsAtual = 20;

system.runInterval(() => {
	const agora = Date.now();
	const decorridoMs = agora - ultimaMarcacaoMs;
	ultimaMarcacaoMs = agora;

	if (decorridoMs > 0) {
		const tps = Math.min(20, (20 * 1000) / decorridoMs);
		tpsAtual = Math.round(tps * 10) / 10;
	}
}, 20);

export function getTps() {
	return tpsAtual;
}
