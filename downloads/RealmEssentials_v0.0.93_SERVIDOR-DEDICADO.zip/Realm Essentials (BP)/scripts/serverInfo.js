import { world } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { getTps } from "./tps.js";

const KEY_CONFIG = "re:serverinfo:config";
const KEY_PICO = "re:serverinfo:pico";

function configPadrao() {
	return {
		nome: "Meu Servidor",
		ip: "nao configurado",
		porta: "19132",
		discord: "nao configurado"
	};
}

export function getConfigServidor() {
	return { ...configPadrao(), ...getData(KEY_CONFIG, {}) };
}

function saveConfigServidor(config) {
	setData(KEY_CONFIG, config);
}

export function definirNomeServidor(nome) {
	nome = (nome ?? "").trim();
	if (!nome) return false;
	const config = getConfigServidor();
	config.nome = nome;
	saveConfigServidor(config);
	return true;
}

export function definirIpServidor(ip) {
	ip = (ip ?? "").trim();
	if (!ip) return false;
	const config = getConfigServidor();
	config.ip = ip;
	saveConfigServidor(config);
	return true;
}

export function definirPortaServidor(porta) {
	porta = (porta ?? "").trim();
	if (!porta) return false;
	const config = getConfigServidor();
	config.porta = porta;
	saveConfigServidor(config);
	return true;
}

export function definirDiscordServidor(link) {
	link = (link ?? "").trim();
	if (!link) return false;
	const config = getConfigServidor();
	config.discord = link;
	saveConfigServidor(config);
	return true;
}

export function getPicoOnline() {
	return getData(KEY_PICO, 0);
}

// Chamado periodicamente. Se o online de agora for maior que o recorde
// salvo, atualiza o recorde.
export function atualizarPicoOnline() {
	const online = world.getAllPlayers().length;
	if (online > getPicoOnline()) setData(KEY_PICO, online);
}

export function montarTextoServidor() {
	const config = getConfigServidor();
	const online = world.getAllPlayers().length;

	return (
		`§b§lNOME: §r§f${config.nome}\n` +
		`§b§lIP: §r§f${config.ip}\n` +
		`§b§lPORTA: §r§f${config.porta}\n` +
		`§b§lDISCORD: §r§f${config.discord}\n` +
		`§a§lONLINE: §r§f${online}\n` +
		`§d§lPICO: §r§f${getPicoOnline()}\n` +
		`§e§lTPS: §r§f${getTps()}`
	);
}
