import { world, system } from "@minecraft/server";
import { getClanDisplay } from "./clan.js";
import { getRankDisplay, getPermissoes, criarRank, darRank, removerRankDoJogador, apagarRank, encontrarIdPorNome } from "./rank.js";
import { abrirLoja, criarLoja } from "./shop.js";
import { emCooldown } from "./cooldown.js";
import { voltar, registrarLocalDeMorte } from "./back.js";
import {
	registrarGolpe,
	adicionarAbate,
	getLinhaCps,
	getLinhaAbates,
	getLinhaVida,
	getLinhaCombo,
	getLinhaPlataforma,
	registrarComboGolpe,
	resetarCombo
} from "./combat.js";
import { abrirMenuPrincipal, abrirMenuReportar } from "./menu.js";
import { executarRtp, getConfigRtp } from "./rtp.js";
import { criarHome, teleportarHome, listarHomesTexto } from "./home.js";
import { criarClan, deletarClan, sairClan } from "./clan.js";
import { ativarTp, desativarTp, aceitarTeleportPendente, recusarTeleportPendente } from "./teleportRequest.js";
import { abrirPainelDono, abrirPainelPorNome, listarAtalhosPainel } from "./ownerPanel.js";
import { checarBanNaEntrada, bloquearSeMutado, aplicarCongelamentoTick, banirJogador, desbanirJogador, mutarJogador, desmutarJogador, kickJogador, congelarJogador, descongelarJogador } from "./moderation.js";
import { criarWarp, removerWarp, teleportarWarp, listarWarpsTexto, encontrarWarpPorComando } from "./warp.js";
import { abrirRenomearWarp } from "./ownerPanel.js";
import { atualizarTextosVoadores, atualizarTextosRapidos } from "./floatingText.js";
import { processarRecompensaDeMob } from "./mobRewards.js";
import { retomarSeAtivo } from "./clearLag.js";
import { estaCastigado, castigarJogador, retirarCastigo, aplicarCastigoTick } from "./castigo.js";
import { estaNaJaula, tentarPrender } from "./jaulaPvp.js";
import { checarClicker } from "./anticheat.js";
import { retomarSeAtivo as retomarAntiDupSeAtivo } from "./antidup.js";
import { ativo } from "./featureFlags.js";
import { ehDono } from "./permissoes.js";
import { logar, escapar, getUltimosLogs, formatarHora } from "./discordLogs.js";
import { iniciarKnockback } from "./knockback.js";
import { formatarNomeItem } from "./itemNomes.js";
import { registrarCombate, registrarCombatePvp, processarSaidaEmCombate, tickCombatLog } from "./combatLog.js";
import { registrarJogadorConhecido } from "./database.js";
import { garantirSaldoInicial, getSaldo, enviarDinheiro } from "./money.js";
import { montarTextoServidor, atualizarPicoOnline } from "./serverInfo.js";
import { tickAutoMensagens } from "./autoMessages.js";
import { tickOtimizacao } from "./otimizacao.js";
import { tickScoreboard } from "./scoreboard.js";
import { registrarClaimQuebrarBloco, registrarClaimAbate, processarItemSpawnado } from "./autoPickup.js";
import {
	getRegras,
	registrarEntradaEObterNumero,
	abrirFormularioBoasVindas,
	getBoasVindasAtivo,
	getMensagemReentrada
} from "./welcome.js";
import { getTps } from "./tps.js";
import {
	tickAreasProtegidas,
	bloquearQuebraBlocoProtegido,
	bloquearColocarBlocoProtegido,
	bloquearInteracaoProtegida,
	restaurarVidaSePvpBloqueado,
	pvpBloqueadoEntre,
} from "./protectedArea.js";

function bloqueadoPorFeature(player, flag, nomeExibicao) {
	if (ativo(flag)) return false;
	player.sendMessage(`§c${nomeExibicao} esta desativado no servidor.`);
	return true;
}

try {
	iniciarKnockback();
} catch (erro) {
	console.warn(`Erro ao iniciar o knockback: ${erro}`);
}

system.run(() => {
	try {
		retomarAntiDupSeAtivo();
	} catch (erro) {
		console.warn(`Erro ao retomar anti-dup na inicializacao: ${erro}`);
	}
});

system.run(() => {
	try {
		retomarSeAtivo();
	} catch (erro) {
		console.warn(`Erro ao retomar clearlag na inicializacao: ${erro}`);
	}
});

const TEXTO_CREDITOS =
	"§b=====================§r\n" +
	"§eRealm Essentials§r\n" +
	"§aEssa versão foi feita por §dvx0831§r\n" +
	"§bDiscord: §fhttps://discord.gg/YBy2qZXr5a§r\n\n" +
	"§aRealm Essentials é grátis, todo mundo pode usar!§r\n" +
	"§b=====================§r";

// Deixa o comando com duas cores (rosa + roxo) tipo §d!war§5p lista, em vez
// de uma cor so - da uma cara mais "premium" pro !ajudar.
function corComando(comando) {
	const meio = Math.ceil(comando.length / 2);
	return `§d${comando.slice(0, meio)}§5${comando.slice(meio)}`;
}

function linha(comando, explicacao) {
	return `${corComando(comando)} §7- ${explicacao}\n`;
}

function montarTextoAjuda() {
	return (
		"§5Realm Essentials\n" +
		linha("!ajudar", "mostra essa lista") +
		linha("!menu", "abre o menu sem a bussola") +
		linha("!rtp", `teleporta ${getConfigRtp().distancia} blocos de distancia`) +
		linha("!tps", "mostra o tps atual do servidor") +
		linha("!voltar", "volta pro local de onde voce morreu") +
		linha("!credito", "mostra quem fez essa versão do addon") +
		linha("!servidor", "mostra info do servidor (ip, discord, online...)") +
		linha("!saldo", "mostra quantas moedas você tem") +
		linha("!pagar (jogador) (valor)", "envia moedas pra outro jogador") +
		linha("!regras", "mostra as regras do servidor") +
		linha("!criar home (nome)", "cria uma home") +
		linha("!home (nome)", "teleporta pra uma home") +
		linha("!home listar", "lista suas homes") +
		linha("!criar clan (nome)", "cria um clan") +
		linha("!deletar clan", "deleta seu clan (dono do clan)") +
		linha("!sair clan", "sai do seu clan") +
		linha("!teleporte aceitar", "aceita um pedido de teleporte") +
		linha("!teleporte recusar", "recusa um pedido de teleporte") +
		linha("!teleportar ligar", "reativa pedidos de teleporte") +
		linha("!teleportar desligar", "desativa pedidos de teleporte") +
		linha("!reportar", "denunciar jogador ou servidor") +
		linha("!warp (nome)", "teleporta pra uma warp") +
		linha("!warp lista", "lista as warps e os comandos delas") +
		linha("!loja", "abre a loja (criar, vender ou comprar itens)") +
		linha("!criar loja (nome)", "cria sua loja pra vender itens").trimEnd()
	);
}

const TEXTO_AJUDA_DONO =
	"\n§5Comandos do Dono\n" +
	linha("!banir (nome)", "bane o jogador") +
	linha("!mutar (nome)", "muta o jogador") +
	linha("!desmutar (nome)", "remove o mute") +
	linha("!expulsar (nome)", "da kick no jogador") +
	linha("!desbanir (nome)", "remove o banimento (funciona offline)") +
	linha("!anunciar (mensagem)", "manda um aviso pra todo mundo") +
	linha("!logs", "mostra os últimos logs do addon") +
	linha("!adminpanel", "abre o painel do dono (também: !painel, !admin ou clique com o relógio)") +
	linha("!adminpanel (seção)", "abre direto: clearlag, cps, antidup, otimizacao, logs, jogadores, config...") +
	linha("!congelar (nome)", "congela o jogador") +
	linha("!descongelar (nome)", "descongela o jogador") +
	linha("!criar warp (nome)", "cria uma warp aqui (sem comando/icone - use o menu pra escolher)") +
	"§7    (Bussola > Warp > Criar Warp abre um formulario com nome, comando customizado tipo !spawn e icone)\n" +
	linha("!deletar warp (nome)", "apaga uma warp") +
	linha("!editar warp (nome)", "abre a UI pra renomear a warp") +
	linha("!rank criar (nome) (aparencia)", "cria um rank") +
	linha("!rank dar (jogador) (rank)", "da um rank") +
	linha("!rank remover (jogador) (rank)", "remove um rank do jogador") +
	linha("!rank apagar (rank)", "apaga um rank") +
	linha("!castigar (nome)", "prende o jogador numa jaula") +
	linha("!soltar (nome)", "libera o jogador do castigo").trimEnd();

// Linha 1 da nametag / prefixo do chat: rank + clan + nome.
function montarNomeExibido(player) {
	// Rank e clan ficam colados um no outro (ex: [Membro][ClaTag]) e so
	// depois vem o nome. Se algum dos dois estiver vazio, nao sobra espaco
	// duplicado ou faltando entre eles.
	const tagRank = getRankDisplay(player);
	const tagClan = getClanDisplay(player); // ja termina com um espaco quando existe
	const prefixo = tagRank + tagClan;
	const espacoAntesDoNome = prefixo && !tagClan ? " " : "";
	return `${prefixo}${espacoAntesDoNome}§7${player.name}`;
}

function atualizarNameTag(player) {
	// 5 modelos independentes (Configuracao > Funcionalidades): cps, abates,
	// vida, combo e plataforma. Cada um so aparece na cabeca do jogador se
	// estiver ligado - a contagem em si (cps, abates, combo) continua
	// rodando por baixo dos panos mesmo com a linha desligada, pra nao
	// zerar o top abates/cps quando o dono so quer esconder da cabeca.
	const linhas = [];
	try {
		if (ativo("mostrarCps")) linhas.push(getLinhaCps(player));
		if (ativo("mostrarAbates")) linhas.push(getLinhaAbates(player));
		if (ativo("mostrarVida")) linhas.push(getLinhaVida(player));
		if (ativo("mostrarCombo")) linhas.push(getLinhaCombo(player));
		if (ativo("mostrarPlataforma")) linhas.push(getLinhaPlataforma(player));
	} catch (erro) {
		console.warn(`Erro ao montar linhas da nametag de ${player.name}: ${erro}`);
	}

	const linhaCombate = linhas.length > 0 ? `\n${linhas.join(" §8| ")}` : "";
	player.nameTag = `${montarNomeExibido(player)}${linhaCombate}`;
}

// Trava quebra de bloco pra quem esta de castigo, ou dentro de uma area
// protegida sem permissao pra quebrar bloco.
world.beforeEvents.playerBreakBlock.subscribe((ev) => {
	if (estaCastigado(ev.player) || estaNaJaula(ev.player)) {
		ev.cancel = true;
		return;
	}
	if (bloquearQuebraBlocoProtegido(ev.player, ev.block)) ev.cancel = true;
});

// Trava abertura de bau/interacao com bloco dentro de uma area protegida
// sem a permissao correspondente.
world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
	if (bloquearInteracaoProtegida(ev.player, ev.block)) ev.cancel = true;
});

// Colocar bloco nunca e permitido dentro de uma area protegida.
world.beforeEvents.playerPlaceBlock.subscribe((ev) => {
	if (bloquearColocarBlocoProtegido(ev.player)) ev.cancel = true;
});

// Bloqueia perola do ender pra quem esta preso na jaula (antes de lancar).
world.beforeEvents.itemUse.subscribe((ev) => {
	if (ev.itemStack?.typeId === "minecraft:ender_pearl" && estaNaJaula(ev.source)) {
		ev.cancel = true;
		try {
			ev.source.sendMessage("§cVoce nao pode usar perola do ender preso na jaula.");
		} catch (erro) {
			console.warn(`Erro ao avisar perola bloqueada: ${erro}`);
		}
	}
});

// Bussola abre o menu normal. Relogio abre o painel do dono, so pra quem
// tiver a tag "admin" ou "dono" (/tag @s add admin).
world.afterEvents.itemUse.subscribe((ev) => {
	if (estaCastigado(ev.source)) return;

	const item = ev.itemStack?.typeId;

	if (item === "minecraft:compass") {
		abrirMenuPrincipal(ev.source);
		return;
	}

	if (item === "minecraft:clock" && ehDono(ev.source)) {
		abrirPainelDono(ev.source);
	}
});

// Mensagem exibida uma unica vez quando o jogador entra no mundo.
world.afterEvents.playerSpawn.subscribe((ev) => {
	registrarJogadorConhecido(ev.player);
	atualizarPicoOnline();

	if (!ev.initialSpawn) {
		atualizarNameTag(ev.player);
		return;
	}

	// Se o jogador estiver banido, expulsa antes de mostrar qualquer coisa.
	checarBanNaEntrada(ev.player);
	garantirSaldoInicial(ev.player);

	atualizarNameTag(ev.player);

	const numeroDeEntrada = registrarEntradaEObterNumero(ev.player);

	logar("entrada", "Jogador entrou", `**${escapar(ev.player.name)}** entrou no servidor.`, [
		{ nome: "Online agora", valor: String(world.getAllPlayers().length) },
		{ nome: "Primeira vez?", valor: numeroDeEntrada ? `Sim (jogador nº ${numeroDeEntrada})` : "Não" }
	]);

	system.runTimeout(() => {
		try {
			if (numeroDeEntrada && getBoasVindasAtivo()) {
				abrirFormularioBoasVindas(ev.player, numeroDeEntrada, montarTextoAjuda());
			} else {
				ev.player.sendMessage(getMensagemReentrada());
			}
		} catch (erro) {
			console.warn(`Erro ao dar boas-vindas pra ${ev.player.name}: ${erro}`);
		}
	}, 20);
});

// Mantem a nametag (rank + clan + cps/abates) sempre atualizada.
system.runInterval(() => {
	world.getAllPlayers().forEach((player) => atualizarNameTag(player));
}, 4);

// Trava jogadores congelados no lugar, cegos, com o aviso na tela.
system.runInterval(() => {
	aplicarCongelamentoTick();
}, 2);

// Mostra o titulo de castigo pra quem tiver preso.
system.runInterval(() => {
	aplicarCastigoTick();
}, 30);

// Atualiza o conteudo (ex: top abates) e a posicao dos textos voadores.
system.runInterval(() => {
	atualizarTextosVoadores();
}, 20);

// Texto rapido: atualizacao bem mais frequente (5x por segundo), so pra
// esse tipo especifico - o resto do texto voador (que recalcula rankings)
// continua no ritmo normal acima.
system.runInterval(() => {
	atualizarTextosRapidos();
}, 4);

// Mensagens automaticas: verifica a cada segundo se ja passou o intervalo
// configurado pra mandar a proxima.
system.runInterval(() => {
	tickAutoMensagens();
}, 20);

// Otimizacao de mobs por chunk: varre todas as entidades, entao roda a
// cada 5s (100 ticks) em vez de todo tick - o suficiente pra segurar o tps
// sem virar ela mesma um gasto extra de performance.
system.runInterval(() => {
	tickOtimizacao();
}, 100);

// Scoreboard (sidebar): reconstroi as linhas configuradas uma vez por
// segundo.
system.runInterval(() => {
	tickScoreboard();
}, 20);

// Combat log: mostra "Em combate com Fulano - Ns" na actionbar de quem
// esta em combate, e avisa quando o combate acaba.
system.runInterval(() => {
	tickCombatLog();
}, 20);

// Aplica os efeitos e a actionbar de quem esta dentro de uma area protegida.
system.runInterval(() => {
	tickAreasProtegidas();
}, 60);

// PVP: se a area protegida onde a vitima ou o atacante estiver tiver pvp
// desligado, desfaz o dano na hora.
world.afterEvents.entityHurt.subscribe((ev) => {
	const vitima = ev.hurtEntity;
	const atacante = ev.damageSource?.damagingEntity;
	restaurarVidaSePvpBloqueado(vitima, atacante, ev.damage);

	// Levar dano de outro jogador quebra o combo (igual em servidor de pvp).
	if (vitima?.typeId === "minecraft:player" && atacante?.typeId === "minecraft:player" && atacante.id !== vitima.id) {
		resetarCombo(vitima.id);
	}
});
world.afterEvents.entityHitEntity.subscribe((ev) => {
	// Conta os golpes (CPS) e mostra na hotbar sempre que o jogador acerta algo.
	const atacante = ev.damagingEntity;
	if (atacante?.typeId !== "minecraft:player") return;

	checarClicker(atacante);

	const alvo = ev.hitEntity;
	if (alvo?.typeId === "minecraft:player") {
		// So entra em "combate" de verdade se o golpe valeu (fora de area
		// segura). Um golpe dado num lugar sem pvp nao pode travar teleporte
		// nem deixar ninguem sujeito a perder item ao sair.
		if (!pvpBloqueadoEntre(alvo, atacante)) {
			registrarCombate(atacante, alvo);
			registrarCombatePvp(atacante, alvo);
		}
		tentarPrender(atacante, alvo);
	}

	// A contagem roda sempre (alimenta o top abates/cps mesmo com a linha
	// desligada na cabeca) - so a exibicao na hotbar depende da flag.
	registrarGolpe(atacante.id, atacante.name);
	registrarComboGolpe(atacante.id);

	const linhasHotbar = [];
	if (ativo("mostrarCps")) linhasHotbar.push(getLinhaCps(atacante));
	if (ativo("mostrarAbates")) linhasHotbar.push(getLinhaAbates(atacante));
	if (ativo("mostrarCombo")) linhasHotbar.push(getLinhaCombo(atacante));
	if (linhasHotbar.length > 0) atacante.onScreenDisplay.setActionBar(linhasHotbar.join(" §8| "));
});

// Auto-coleta: quebrou bloco ou item apareceu no chao (de bloco quebrado
// ou de abate), manda direto pro inventario de quem tem direito.
world.afterEvents.playerBreakBlock.subscribe((ev) => {
	if (!ativo("autoColeta")) return;
	registrarClaimQuebrarBloco(ev.player, ev.block);
});

world.afterEvents.entitySpawn.subscribe((ev) => {
	if (!ativo("autoColeta")) return;
	processarItemSpawnado(ev.entity);
});

function localTexto(entidade) {
	const l = entidade.location;
	const dim = entidade.dimension.id.replace("minecraft:", "");
	return `${Math.floor(l.x)}, ${Math.floor(l.y)}, ${Math.floor(l.z)} (${dim})`;
}

function nomeItemNaMao(jogador) {
	try {
		const item = jogador.getComponent("inventory")?.container?.getItem(jogador.selectedSlotIndex);
		return item ? formatarNomeItem(item.typeId.replace("minecraft:", "")) : "Mão";
	} catch {
		return "Desconhecida";
	}
}

function logarMorteDeJogador(morto, matador, causa) {
	try {
		if (matador?.typeId === "minecraft:player" && matador.id !== morto.id) {
			logar("morte", "Abate PvP", `**${escapar(matador.name)}** matou **${escapar(morto.name)}**.`, [
				{ nome: "Arma", valor: nomeItemNaMao(matador) },
				{ nome: "Local", valor: localTexto(morto) }
			]);
			return;
		}
		logar("morte", "Morte", `**${escapar(morto.name)}** morreu.`, [
			{ nome: "Causa", valor: String(causa ?? "desconhecida") },
			{ nome: "Local", valor: localTexto(morto) }
		]);
	} catch (erro) {
		console.warn(`Erro ao registrar log de morte: ${erro}`);
	}
}

// Conta abates quando um jogador mata outro jogador.
world.afterEvents.entityDie.subscribe((ev) => {
	const morto = ev.deadEntity;
	const matador = ev.damageSource?.damagingEntity;

	if (morto?.typeId === "minecraft:player") {
		registrarLocalDeMorte(morto);
		logarMorteDeJogador(morto, matador, ev.damageSource?.cause);
		if (matador?.typeId === "minecraft:player" && matador.id !== morto.id) {
			adicionarAbate(matador);
			registrarClaimAbate(morto.dimension, morto.location, matador);
			if (ativo("raioMorte")) {
				try {
					morto.dimension.spawnEntity("minecraft:lightning_bolt", morto.location);
				} catch (erro) {
					console.warn(`Erro ao criar raio de morte: ${erro}`);
				}
			}
		}
		return;
	}

	if (matador?.typeId === "minecraft:player") {
		registrarClaimAbate(morto.dimension, morto.location, matador);
		processarRecompensaDeMob(morto, matador);
	}
});

world.afterEvents.playerLeave.subscribe((ev) => {
	logar("saida", "Jogador saiu", `**${escapar(ev.playerName)}** saiu do servidor.`);
});

// Combat log: se sair durante um combate ativo, perde os itens.
world.beforeEvents.playerLeave.subscribe((ev) => {
	processarSaidaEmCombate(ev.player);
});

// Comandos com "!" e formata o resto do chat com rank + clan + nome.
world.beforeEvents.chatSend.subscribe((ev) => {
	ev.cancel = true;
	const player = ev.sender;
	const mensagem = ev.message;

	if (!mensagem.startsWith("!")) {
		system.run(() => {
			if (bloquearSeMutado(player)) return;
			if (emCooldown(player, "chat", getPermissoes(player).cooldownChat)) return;
			world.sendMessage(`${montarNomeExibido(player)} §r>> §f${mensagem}`);
			logar("chat", "Mensagem no chat", `**${escapar(player.name)}**: ${escapar(mensagem, 400)}`);
		});
		return;
	}

	const args = mensagem.slice(1).trim().split(/\s+/);
	const cmd = (args[0] ?? "").toLowerCase();

	logar("comandos", "Comando usado", `**${escapar(player.name)}** usou \`${escapar(mensagem, 150).replace(/`/g, "'")}\``);

	system.run(() => {
		try {
			if (estaCastigado(player)) {
				player.sendMessage("§cVoce esta de castigo e nao pode usar comandos.");
				return;
			}
			switch (cmd) {
			case "ajudar":
				// Manda em duas mensagens separadas (em vez de uma unica mensagem
				// gigante) - mensagens muito longas podem nao aparecer direito no
				// chat do Bedrock, principalmente pro dono que recebe a lista extra.
				player.sendMessage(montarTextoAjuda());
				if (ehDono(player)) {
					system.runTimeout(() => player.sendMessage(TEXTO_AJUDA_DONO), 2);
				}
				break;

			case "menu":
				system.runTimeout(() => {
					try {
						abrirMenuPrincipal(player);
					} catch (erro) {
						console.warn(`Erro ao abrir o menu: ${erro}`);
					}
				}, 5);
				break;

			case "rtp":
				executarRtp(player);
				break;

			case "tps": {
				const tps = getTps();
				const cor = tps >= 18 ? "§a" : tps >= 15 ? "§e" : "§c";
				player.sendMessage(`§fTPS do servidor: ${cor}${tps}§f/20`);
				break;
			}

			case "credito":
			case "creditos":
				player.sendMessage(TEXTO_CREDITOS);
				break;

			case "servidor":
				player.sendMessage(montarTextoServidor());
				break;

			case "regras":
				player.sendMessage(getRegras());
				break;

			case "saldo":
				player.sendMessage(`§fSeu saldo: §e${getSaldo(player)} moedas`);
				break;

			case "pagar": {
				const valor = args[args.length - 1];
				const nomeDestino = args.slice(1, -1).join(" ");
				if (args.length < 3 || !nomeDestino) {
					player.sendMessage("§cUse: !pagar (jogador) (valor)");
					break;
				}
				const destino = world.getPlayers({ name: nomeDestino })[0];
				if (!destino) {
					player.sendMessage(`§cJogador §e${nomeDestino}§c não encontrado online.`);
					break;
				}
				enviarDinheiro(player, destino, valor);
				break;
			}

			case "adminpanel":
			case "painel":
			case "admin": {
				if (!ehDono(player)) {
					player.sendMessage("§cVocê não tem permissão para usar esse comando.");
					break;
				}
				const secao = (args[1] ?? "").toLowerCase();
				// Formulário não abre com o chat ainda aberto, então espera uns ticks (igual ao !menu).
				system.runTimeout(() => {
					try {
						if (!abrirPainelPorNome(player, secao)) {
							player.sendMessage(`§cSeção §e${secao}§c não existe. Opções: §f${listarAtalhosPainel()}`);
							abrirPainelDono(player);
						}
					} catch (erro) {
						console.warn(`Erro ao abrir o painel: ${erro}`);
					}
				}, 5);
				break;
			}

			case "desbanir": {
				if (!ehDono(player)) {
					player.sendMessage("§cVocê não tem permissão para usar esse comando.");
					break;
				}
				const nomeAlvo = args.slice(1).join(" ");
				if (!nomeAlvo) {
					player.sendMessage("§cUse: !desbanir (nome)");
					break;
				}
				if (desbanirJogador(nomeAlvo)) player.sendMessage(`§a${nomeAlvo} foi desbanido.`);
				else player.sendMessage(`§cNão existe banimento para §e${nomeAlvo}§c.`);
				break;
			}

			case "anunciar": {
				if (!ehDono(player)) {
					player.sendMessage("§cVocê não tem permissão para usar esse comando.");
					break;
				}
				const texto = args.slice(1).join(" ").trim();
				if (!texto) {
					player.sendMessage("§cUse: !anunciar (mensagem)");
					break;
				}
				world.sendMessage(`§5§l[Aviso] §r§f${texto}`);
				logar("moderacao", "Anúncio", `**${escapar(player.name)}** anunciou: ${escapar(texto, 500)}`);
				break;
			}

			case "logs": {
				if (!ehDono(player)) {
					player.sendMessage("§cVocê não tem permissão para usar esse comando.");
					break;
				}
				const ultimos = getUltimosLogs(10);
				if (ultimos.length === 0) {
					player.sendMessage("§7Nenhum log registrado ainda.");
					break;
				}
				player.sendMessage(
					"§5Últimos logs\n" + ultimos.map((l) => `§8${formatarHora(l.t)} §f${l.a}§7${l.d ? ` - ${l.d}` : ""}`).join("\n")
				);
				break;
			}

			case "reportar":
				if (bloqueadoPorFeature(player, "reportar", "Reportar")) break;
				system.runTimeout(() => {
					try {
						abrirMenuReportar(player);
					} catch (erro) {
						console.warn(`Erro ao abrir o menu de reportar: ${erro}`);
					}
				}, 5);
				break;

			case "rank": {
				if (!ehDono(player)) {
					player.sendMessage("§cApenas o dono do servidor pode usar esse comando.");
					break;
				}
				const sub = (args[1] ?? "").toLowerCase();

				if (sub === "criar") {
					const nome = args[2];
					const aparencia = args.slice(3).join(" ");
					criarRank(player, nome, aparencia);
					break;
				}

				if (sub === "dar" || sub === "remover") {
					const nomeJogador = args[2];
					const nomeRank = args.slice(3).join(" ");
					const alvo = world.getPlayers({ name: nomeJogador })[0];
					if (!alvo) {
						player.sendMessage(`§cJogador §e${nomeJogador}§c nao encontrado online.`);
						break;
					}
					const id = encontrarIdPorNome(nomeRank);
					if (!id) {
						player.sendMessage(`§cNao existe nenhum rank chamado §e${nomeRank}§c.`);
						break;
					}
					if (sub === "dar") darRank(player, alvo, id);
					else removerRankDoJogador(player, alvo, id);
					break;
				}

				if (sub === "apagar") {
					const nomeRank = args.slice(2).join(" ");
					const id = encontrarIdPorNome(nomeRank);
					if (!id) {
						player.sendMessage(`§cNao existe nenhum rank chamado §e${nomeRank}§c.`);
						break;
					}
					apagarRank(player, id);
					break;
				}

				player.sendMessage(
					"§cUse: !rank criar (nome) (aparencia) | !rank dar (jogador) (rank) | !rank remover (jogador) (rank) | !rank apagar (rank)"
				);
				break;
			}

			case "voltar":
				if (bloqueadoPorFeature(player, "voltar", "!voltar")) break;
				voltar(player);
				break;

			case "warp": {
				if (bloqueadoPorFeature(player, "warp", "Warp")) break;
				const sub = (args[1] ?? "").toLowerCase();
				if (sub === "lista" || sub === "listar") {
					listarWarpsTexto(player);
				} else if (sub) {
					teleportarWarp(player, args.slice(1).join(" "));
				} else {
					player.sendMessage("§cUse: !warp lista ou !warp (nome)");
				}
				break;
			}

			case "loja":
				if (bloqueadoPorFeature(player, "loja", "Loja")) break;
				system.runTimeout(() => abrirLoja(player), 5);
				break;

			case "criar": {
				const tipo = (args[1] ?? "").toLowerCase();
				const nome = args.slice(2).join(" ");
				if (tipo === "home") {
					if (bloqueadoPorFeature(player, "home", "Home")) break;
					criarHome(player, nome);
				} else if (tipo === "clan") {
					if (bloqueadoPorFeature(player, "clan", "Clan")) break;
					criarClan(player, nome);
				} else if (tipo === "warp") {
					if (bloqueadoPorFeature(player, "warp", "Warp")) break;
					criarWarp(player, nome);
				} else if (tipo === "loja") {
					if (bloqueadoPorFeature(player, "loja", "Loja")) break;
					criarLoja(player, nome);
				} else player.sendMessage("§cUse: !criar home (nome), !criar clan (nome), !criar warp (nome) ou !criar loja (nome)");
				break;
			}

			case "home": {
				if (bloqueadoPorFeature(player, "home", "Home")) break;
				const sub = (args[1] ?? "").toLowerCase();
				if (sub === "listar") {
					listarHomesTexto(player);
				} else {
					teleportarHome(player, args.slice(1).join(" "));
				}
				break;
			}

			case "deletar": {
				const tipo = (args[1] ?? "").toLowerCase();
				if (tipo === "clan") {
					if (bloqueadoPorFeature(player, "clan", "Clan")) break;
					deletarClan(player);
				} else if (tipo === "warp") {
					if (bloqueadoPorFeature(player, "warp", "Warp")) break;
					removerWarp(player, args.slice(2).join(" "));
				} else player.sendMessage("§cUse: !deletar clan ou !deletar warp (nome)");
				break;
			}

			case "editar": {
				const tipo = (args[1] ?? "").toLowerCase();
				if (tipo === "warp") {
					if (!ehDono(player)) {
						player.sendMessage("§cVoce nao tem permissao para usar esse comando.");
						break;
					}
					abrirRenomearWarp(player, args.slice(2).join(" "));
				} else {
					player.sendMessage("§cUse: !editar warp (nome)");
				}
				break;
			}

			case "sair": {
				const tipo = (args[1] ?? "").toLowerCase();
				if (tipo === "clan") {
					if (bloqueadoPorFeature(player, "clan", "Clan")) break;
					sairClan(player);
				} else player.sendMessage("§cUse: !sair clan");
				break;
			}

			case "teleporte": {
				if (bloqueadoPorFeature(player, "teleportar", "Teleportar")) break;
				const sub = (args[1] ?? "").toLowerCase();
				if (sub === "aceitar") aceitarTeleportPendente(player);
				else if (sub === "recusar") recusarTeleportPendente(player);
				else if (sub === "on" || sub === "ligar") ativarTp(player);
				else if (sub === "off" || sub === "desligar") desativarTp(player);
				else player.sendMessage("§cUse: !teleporte aceitar, !teleporte recusar, !teleporte on ou !teleporte off");
				break;
			}

			case "teleportar": {
				if (bloqueadoPorFeature(player, "teleportar", "Teleportar")) break;
				const sub = (args[1] ?? "").toLowerCase();
				if (sub === "ligar" || sub === "on") ativarTp(player);
				else if (sub === "desligar" || sub === "off") desativarTp(player);
				else player.sendMessage("§cUse: !teleportar ligar ou !teleportar desligar (tambem aceita on/off)");
				break;
			}

			case "banir":
			case "mutar":
			case "expulsar":
			case "congelar":
			case "descongelar": {
				if (!ehDono(player)) {
					player.sendMessage("§cVoce nao tem permissao para usar esse comando.");
					break;
				}

				const nomeAlvo = args.slice(1).join(" ");
				const alvo = world.getPlayers({ name: nomeAlvo })[0];
				if (!alvo && cmd === "banir" && nomeAlvo) {
					// Jogador offline: bane só pelo nome, ele é expulso se tentar entrar.
					banirJogador({ name: nomeAlvo }, "Banido via comando", player);
					player.sendMessage(`§a${nomeAlvo} foi banido §7(estava offline)§a.`);
					break;
				}
				if (!alvo) {
					player.sendMessage(`§cJogador §e${nomeAlvo}§c nao encontrado online.`);
					break;
				}

				if (cmd === "banir") banirJogador(alvo, "Banido via comando", player);
				if (cmd === "mutar") mutarJogador(alvo, "Mutado via comando", player);
				if (cmd === "expulsar") kickJogador(alvo, "Expulso via comando", player);
				if (cmd === "congelar") congelarJogador(alvo);
				if (cmd === "descongelar") descongelarJogador(alvo);
				if (cmd === "congelar" || cmd === "descongelar") {
					logar("moderacao", cmd === "congelar" ? "Jogador congelado" : "Jogador descongelado", `**${escapar(alvo.name)}** foi ${cmd === "congelar" ? "congelado" : "descongelado"}.`, [
						{ nome: "Por", valor: player.name }
					]);
				}

				const particípios = {
					banir: "banido",
					mutar: "mutado",
					expulsar: "expulso",
					congelar: "congelado",
					descongelar: "descongelado"
				};
				player.sendMessage(`§a${alvo.name} foi ${particípios[cmd]}.`);
				break;
			}

			case "desmutar": {
				if (!ehDono(player)) {
					player.sendMessage("§cVoce nao tem permissao para usar esse comando.");
					break;
				}
				const nomeAlvo = args.slice(1).join(" ");
				desmutarJogador(nomeAlvo);
				player.sendMessage(`§a${nomeAlvo} foi desmutado.`);
				break;
			}

			case "castigar": {
				if (!ehDono(player)) {
					player.sendMessage("§cVoce nao tem permissao para usar esse comando.");
					break;
				}
				const nomeAlvo = args.slice(1).join(" ");
				const alvo = world.getPlayers({ name: nomeAlvo })[0];
				if (!alvo) {
					player.sendMessage(`§cJogador §e${nomeAlvo}§c nao encontrado online.`);
					break;
				}
				castigarJogador(player, alvo);
				break;
			}

			case "soltar": {
				if (!ehDono(player)) {
					player.sendMessage("§cVoce nao tem permissao para usar esse comando.");
					break;
				}
				retirarCastigo(player, args.slice(1).join(" "));
				break;
			}

			default: {
				// Se nao bateu com nenhum comando conhecido, verifica se e um
				// comando customizado de warp (ex: !spawn -> teleporta na warp
				// que tiver esse comando registrado).
				const nomeDaWarp = encontrarWarpPorComando(cmd);
				if (nomeDaWarp) {
					if (bloqueadoPorFeature(player, "warp", "Warp")) break;
					teleportarWarp(player, nomeDaWarp);
					break;
				}
				player.sendMessage("§cComando desconhecido. Use §e!ajudar§c para ver a lista de comandos.");
			}
			}
		} catch (erro) {
			console.warn(`Erro ao executar comando !${cmd}: ${erro}`);
			player.sendMessage("§cAlgo deu errado ao executar esse comando. Tente de novo.");
		}
	});
});
