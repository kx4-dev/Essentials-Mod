import { world } from "@minecraft/server";
import { abrirMenuLogs } from "./logsPanel.js";
import { abrirMenuKnockback } from "./knockbackPanel.js";
import { logar, escapar } from "./discordLogs.js";
import { abrirMenuAntiDup } from "./antiDupPanel.js";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import {
	getBans,
	desbanirJogador,
	banirJogador,
	kickJogador,
	getMutes,
	isMutado,
	mutarJogador,
	desmutarJogador,
	isCongelado,
	congelarJogador,
	descongelarJogador,
	getCongeladosOnline
} from "./moderation.js";
import { abrirInventarioJogador, verBauDoEnder, abrirHomesJogador } from "./adminTools.js";
import { getWarps, criarWarp, removerWarp, renomearWarp, ICONES_WARP } from "./warp.js";
import { getConfigRtp, definirDistanciaRtp } from "./rtp.js";
import { getConfigCombatLog, definirDuracaoCombatLog } from "./combatLog.js";
import { getConfigMoney, definirSaldoInicial, definirSaldoMaximo } from "./money.js";
import {
	getConfigServidor,
	definirNomeServidor,
	definirIpServidor,
	definirPortaServidor,
	definirDiscordServidor
} from "./serverInfo.js";
import {
	getConfigAuto,
	getMensagens,
	adicionarMensagem,
	removerMensagem,
	definirAtivo as definirAutoAtivo,
	definirIntervaloMinutos,
	definirSom as definirSomAuto,
	getSonsDisponiveis as getSonsAuto
} from "./autoMessages.js";
import { getConfig as getConfigOtimizacao, definirAtivo as definirAtivoOtimizacao, definirLimites as definirLimitesOtimizacao } from "./otimizacao.js";
import {
	getConfig as getConfigScoreboard,
	definirAtivo as definirAtivoScoreboard,
	definirTitulo as definirTituloScoreboard,
	getTiposLinha,
	getTiposSimples,
	adicionarLinha as adicionarLinhaScoreboard,
	editarLinha as editarLinhaScoreboard,
	removerLinha as removerLinhaScoreboard,
	moverLinha as moverLinhaScoreboard,
	restaurarPadrao as restaurarPadraoScoreboard
} from "./scoreboard.js";
import {
	getConfigClan,
	definirLimiteMembrosClan,
	definirModoCriacaoClan,
	definirCustoCriarClan,
	permitirCriarClan,
	proibirCriarClan
} from "./clan.js";
import {
	criarTextoFixo,
	criarTextoAnimado,
	criarTextoRapido,
	CORES_TEXTO_ANIMADO,
	criarTopAbates,
	criarTopSaldo,
	criarTopClan,
	criarTopCps,
	criarListaJogadores,
	getListaTextos,
	getResumoTexto,
	removerTexto,
	editarTexto
} from "./floatingText.js";
import {
	getConfig as getConfigClearLag,
	ativar as ativarClearLag,
	desativar as desativarClearLag,
	limparAgora as limparAgoraClearLag,
	definirIntervalo as definirIntervaloClearLag,
	definirSom as definirSomClearLag,
	definirSomAtivo as definirSomAtivoClearLag,
	definirTextoAviso as definirTextoAvisoClearLag,
	getSonsDisponiveis as getSonsClearLag,
	definirItemProtegidoToggle as definirItemProtegidoToggleClearLag,
	definirItensExtras as definirItensExtrasClearLag,
	definirCoresContagem as definirCoresContagemClearLag,
	definirLimparMobsHostis as definirLimparMobsHostisClearLag,
	definirLimparItensChao as definirLimparItensChaoClearLag,
	definirLimparOrbesXp as definirLimparOrbesXpClearLag
} from "./clearLag.js";
import {
	getConfig as getConfigAntiCheat,
	ativar as ativarAntiCheat,
	desativar as desativarAntiCheat,
	definirLimite as definirLimiteAntiCheat,
	definirAcao as definirAcaoAntiCheat,
	limparLogs as limparLogsAntiCheat
} from "./anticheat.js";
import { getReports, limparDenuncias } from "./report.js";
import { estaCastigado, castigarJogador, retirarCastigo, getListaCastigados } from "./castigo.js";
import { getFlags as getFeatureFlags, definirFlag as definirFeatureFlag } from "./featureFlags.js";
import {
	getRanks,
	criarRank,
	apagarRank,
	editarAparenciaRank,
	darRank,
	removerRankDoJogador,
	editarPermissoes,
	getRanksDoJogadorComNome
} from "./rank.js";
import { getTps } from "./tps.js";
import {
	getRegras,
	definirRegras,
	getTextoBoasVindas,
	definirTextoBoasVindas,
	getNomeMenu,
	definirNomeMenu,
	getMensagemReentrada,
	definirMensagemReentrada,
	getBoasVindasAtivo,
	definirBoasVindasAtivo
} from "./welcome.js";
import {
	listarAreas,
	criarArea,
	deletarArea,
	definirPermissaoArea,
	EFEITOS_DISPONIVEIS,
	getEfeitosArea,
	alternarEfeitoArea
} from "./protectedArea.js";

const ICONE_VOLTAR = "textures/icons/left_arrow";
const ICONE_JOGADORES = "textures/icons/players";
const ICONE_BANS = "textures/icons/bans";
const ICONE_BAN = "textures/icons/ban";
const ICONE_KICK = "textures/icons/kick";
const ICONE_MUTE = "textures/icons/mute";
const ICONE_UNMUTE = "textures/icons/unmute";
const ICONE_FREEZE = "textures/icons/freeze";
const ICONE_UNFREEZE = "textures/icons/unfreeze";
const ICONE_INVENTARIO = "textures/icons/inventory";
const ICONE_HOME = "textures/icons/home";
const ICONE_ENDERCHEST = "textures/icons/enderchest";
const ICONE_WARP = "textures/icons/warps";
const ICONE_CRIAR = "textures/ui/color_plus";
const ICONE_RENOMEAR = "textures/items/name_tag";
const ICONE_APAGAR = "textures/ui/icon_trash";
const ICONE_TEXTO_VOADOR = "textures/ui/new_offer_symbol";
const ICONE_CLEARLAG = "textures/items/diamond";
const ICONE_LIGAR = "textures/items/emerald";
const ICONE_DESLIGAR = "textures/ui/icon_trash";
const ICONE_CONFIGURAR = "textures/ui/icon_setting";
const ICONE_EDITAR = "textures/ui/pencil_edit_icon";
const ICONE_ANTICHEAT = "textures/items/diamond_sword";
const ICONE_LISTA = "textures/items/paper";
const ICONE_CLAN = "textures/items/name_tag";
const ICONE_RANK = "textures/ui/color_picker";
const ICONE_DINHEIRO = "textures/items/emerald";
const ICONE_MENSAGENS = "textures/icons/comment";
const ICONE_LIXO = "textures/ui/icon_trash";
const ICONE_AREA = "textures/ui/icon_recipe_nature";

// ===== PAINEL PRINCIPAL =====

// Cada seção do painel. "chaves" são os atalhos aceitos em !adminpanel (ex: !adminpanel clearlag).
function secoesPainel() {
	return [
		{ chaves: ["jogadores", "gerenciamento", "gerenciar"], texto: "Gerenciamento\n§7[Jogadores e punicoes]", icone: ICONE_JOGADORES, abrir: abrirMenuGerenciamento },
		{ chaves: ["rank", "ranks"], texto: "Rank\n§7[Criar e editar ranks]", icone: ICONE_RANK, abrir: abrirMenuRank },
		{ chaves: ["warp", "warps"], texto: "Warp\n§7[Criar e gerenciar warps]", icone: ICONE_WARP, abrir: abrirMenuWarpDono },
		{ chaves: ["clearlag", "lag", "limpeza"], texto: "Limpeza de Lag\n§7[Auto clear de itens]", icone: ICONE_LIXO, abrir: abrirMenuClearLag },
		{ chaves: ["otimizacao", "mobs"], texto: "Otimizacao\n§7[Reduz mob com lotacao]", icone: "textures/ui/icon_setting", abrir: abrirMenuOtimizacao },
		{ chaves: ["scoreboard", "sidebar"], texto: "Scoreboard\n§7[Sidebar personalizavel]", icone: "textures/ui/icon_book_writable", abrir: abrirMenuScoreboard },
		{ chaves: ["cps", "anticheat", "limitador"], texto: "Limitar CPS\n§7[Anti-cheat]", icone: ICONE_ANTICHEAT, abrir: abrirMenuAntiCheat },
		{ chaves: ["knockback", "kb", "launchpad", "impulso"], texto: "Knockback\n§7[Empurrão de PvP e Launch Pad]", icone: "textures/items/fishing_rod_uncast", abrir: (j) => abrirMenuKnockback(j, abrirPainelDono) },
		{ chaves: ["antidup", "dup", "duplicacao"], texto: "Anti-Dup\n§7[Detecta duplicação de itens]", icone: "textures/items/diamond", abrir: (j) => abrirMenuAntiDup(j, abrirPainelDono) },
		{ chaves: ["textovoador", "holograma", "hologramas"], texto: "Texto Voador\n§7[Hologramas no mundo]", icone: ICONE_TEXTO_VOADOR, abrir: abrirMenuTextoVoador },
		{ chaves: ["textoauto", "automatico", "mensagens"], texto: "Texto Automatico\n§7[Mensagens no chat]", icone: "textures/items/paper", abrir: abrirMenuTextoAutomatico },
		{ chaves: ["area", "protegida", "areaprotegida"], texto: "Area Protegida\n§7[Zonas seguras]", icone: ICONE_AREA, abrir: abrirMenuAreaProtegida },
		{ chaves: ["denuncias", "reports"], texto: "Denuncias\n§7[Ver e limpar denuncias]", icone: ICONE_LISTA, abrir: abrirMenuDenuncias },
		{ chaves: ["anunciar", "aviso"], texto: "Anunciar\n§7[Aviso pra todo mundo]", icone: ICONE_MENSAGENS, abrir: abrirAnunciar },
		{ chaves: ["logs", "discord"], texto: "Logs\n§7[Discord e histórico]", icone: ICONE_LISTA, abrir: (j) => abrirMenuLogs(j, abrirPainelDono) },
		{ chaves: ["config", "configuracao"], texto: "Configuracao\n§7[Ligar/desligar sistemas]", icone: ICONE_CONFIGURAR, abrir: abrirMenuConfiguracao }
	];
}

// Aviso pra todo mundo, pelo menu (equivale ao comando !anunciar).
function abrirAnunciar(player) {
	const modal = new ModalFormData()
		.title("Anunciar")
		.textField("Mensagem para todos os jogadores", "Ex: O servidor reinicia em 5 minutos");

	modal.show(player).then((res) => {
		if (res.canceled || !res.formValues) {
			abrirPainelDono(player);
			return;
		}
		const texto = String(res.formValues[0] ?? "").trim();
		if (!texto) {
			player.sendMessage("§cDigite uma mensagem.");
			abrirAnunciar(player);
			return;
		}
		world.sendMessage(`§5§l[Aviso] §r§f${texto}`);
		logar("moderacao", "Anúncio", `**${escapar(player.name)}** anunciou: ${escapar(texto, 500)}`);
		abrirPainelDono(player);
	});
}

// Usado pelo comando !adminpanel. Sem nome abre o painel principal; com nome
// abre direto a seção (ex: clearlag, cps, antidup, logs). Retorna false se o
// nome não existir.
export function abrirPainelPorNome(player, nome) {
	nome = (nome ?? "").trim().toLowerCase();
	if (!nome) {
		abrirPainelDono(player);
		return true;
	}
	const secao = secoesPainel().find((s) => s.chaves.includes(nome));
	if (!secao) return false;
	secao.abrir(player);
	return true;
}

export function listarAtalhosPainel() {
	return secoesPainel()
		.map((s) => s.chaves[0])
		.join(", ");
}

export function abrirPainelDono(player) {
	const onlineAgora = world.getAllPlayers().length;
	const banidos = Object.keys(getBans()).length;
	const tps = getTps();
	const corTps = tps >= 18 ? "§a" : tps >= 15 ? "§e" : "§c";
	const secoes = secoesPainel();

	const form = new ActionFormData()
		.title("Painel do Dono")
		.body(
			`§8§lAddon por vx0831§r\n\n` +
				`§7status: §aonline  §8|  §7online: §f${onlineAgora}  §8|  §7tps: ${corTps}${tps}  §8|  §7banidos: §f${banidos}\n\n` +
				"Escolha uma categoria:"
		);
	for (const secao of secoes) form.button(secao.texto, secao.icone);

	form.show(player).then((res) => {
		if (res.canceled) return;
		secoes[res.selection]?.abrir(player);
	});
}

// ===== ABA OTIMIZACAO =====

function abrirMenuOtimizacao(player) {
	const config = getConfigOtimizacao();

	const form = new ActionFormData()
		.title("Otimizacao")
		.body(
			`§7Reduz a quantidade de mobs por chunk sozinho quando o servidor enche de jogador, pra segurar o tps.\n\n` +
				`§fStatus: ${config.ativo ? "§aAtivado" : "§cDesativado"}\n` +
				`§fReduz a partir de: §e${config.limiarAlto}§f jogadores §7(maximo ${config.capPorChunkAlto} mobs/chunk)\n` +
				`§fFica mais forte a partir de: §e${config.limiarCritico}§f jogadores §7(maximo ${config.capPorChunkCritico} mob/chunk)\n` +
				`§fShulker por chunk: §e${config.capShulkerPorChunk} §7(sempre, independente da lotacao)`
		)
		.button(config.ativo ? "Desativar\n§7[Deixa os mobs soltos]" : "Ativar\n§7[Comeca a reduzir]", config.ativo ? ICONE_DESLIGAR : ICONE_LIGAR)
		.button("Ajustar Limites\n§7[Jogadores e mobs por chunk]", ICONE_CONFIGURAR)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			definirAtivoOtimizacao(!config.ativo);
			player.sendMessage(config.ativo ? "§eOtimizacao de mobs desativada." : "§aOtimizacao de mobs ativada!");
			abrirMenuOtimizacao(player);
			return;
		}
		if (res.selection === 1) {
			abrirAjusteOtimizacao(player);
			return;
		}
		abrirPainelDono(player);
	});
}

function abrirAjusteOtimizacao(player) {
	const config = getConfigOtimizacao();

	const modal = new ModalFormData()
		.title("Ajustar Limites")
		.textField("A partir de quantos jogadores comeca a reduzir", "Ex: 20", { defaultValue: String(config.limiarAlto) })
		.textField("Maximo de mobs por chunk nesse nivel", "Ex: 3", { defaultValue: String(config.capPorChunkAlto) })
		.textField("A partir de quantos jogadores fica mais forte", "Ex: 50", { defaultValue: String(config.limiarCritico) })
		.textField("Maximo de mobs por chunk nesse nivel mais forte", "Ex: 1", { defaultValue: String(config.capPorChunkCritico) })
		.textField("Maximo de shulker por chunk (sempre)", "Ex: 2", { defaultValue: String(config.capShulkerPorChunk) });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuOtimizacao(player);
				return;
			}
			definirLimitesOtimizacao(res.formValues[0], res.formValues[2], res.formValues[1], res.formValues[3], res.formValues[4]);
			player.sendMessage("§aLimites de otimizacao atualizados!");
			abrirMenuOtimizacao(player);
		})
		.catch((erro) => console.warn(`Erro ao ajustar limites de otimizacao: ${erro}`));
}

// ===== ABA SCOREBOARD =====

function abrirMenuScoreboard(player) {
	const config = getConfigScoreboard();

	const form = new ActionFormData()
		.title("Scoreboard")
		.body(
			`§7Sidebar personalizavel do lado direito da tela.\n` +
				`§cImportante: essa sidebar e igual pra todo mundo online ao mesmo tempo - o jogo nao deixa mostrar um rank ou saldo diferente pra cada jogador.\n\n` +
				`§fStatus: ${config.ativo ? "§aAtivado" : "§cDesativado"}\n` +
				`§fTitulo: ${config.titulo}\n` +
				`§fLinhas: §e${config.linhas.length}/20`
		)
		.button(config.ativo ? "Desativar\n§7[Some a sidebar]" : "Ativar\n§7[Mostra a sidebar]", config.ativo ? ICONE_DESLIGAR : ICONE_LIGAR)
		.button("Editar Titulo", "textures/items/book_writable")
		.button("Linhas\n§7[Ver, adicionar, editar]", ICONE_TEXTO_VOADOR)
		.button("Restaurar Padrao\n§7[Volta pro modelo pronto]", "textures/ui/refresh")
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			definirAtivoScoreboard(!config.ativo);
			player.sendMessage(config.ativo ? "§eScoreboard desativado." : "§aScoreboard ativado!");
			abrirMenuScoreboard(player);
			return;
		}
		if (res.selection === 1) {
			abrirEditarTituloScoreboard(player);
			return;
		}
		if (res.selection === 2) {
			abrirListaLinhasScoreboard(player);
			return;
		}
		if (res.selection === 3) {
			confirmarAcaoPainel(
				player,
				"Restaurar Padrao",
				"Isso apaga todas as suas linhas e volta pro modelo pronto do addon. Tem certeza?",
				() => {
					restaurarPadraoScoreboard();
					player.sendMessage("§aScoreboard restaurado pro modelo padrao!");
					abrirMenuScoreboard(player);
				},
				() => abrirMenuScoreboard(player)
			);
			return;
		}
		abrirPainelDono(player);
	});
}

function abrirEditarTituloScoreboard(player) {
	const config = getConfigScoreboard();
	const modal = new ModalFormData().title("Editar Titulo").textField("Titulo da sidebar", "Ex: §l§bServidor", { defaultValue: config.titulo });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuScoreboard(player);
				return;
			}
			definirTituloScoreboard(res.formValues[0]);
			player.sendMessage("§aTitulo atualizado! (pode levar 1s pra atualizar na tela)");
			abrirMenuScoreboard(player);
		})
		.catch((erro) => console.warn(`Erro ao editar titulo do scoreboard: ${erro}`));
}

function abrirListaLinhasScoreboard(player) {
	const config = getConfigScoreboard();

	const form = new ActionFormData()
		.title(`Linhas (${config.linhas.length}/20)`)
		.body("Toque numa linha pra editar, mover ou remover.")
		.button("Adicionar Linha", ICONE_CRIAR);

	config.linhas.forEach((linha) => {
		const tipo = getTiposLinha().find((t) => t.id === linha.tipo);
		form.button(`§e${tipo?.nome ?? linha.tipo}`, "textures/items/paper");
	});
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			abrirEscolherTipoLinhaScoreboard(player);
			return;
		}
		const indiceLinha = res.selection - 1;
		if (indiceLinha < config.linhas.length) {
			abrirEditarLinhaScoreboard(player, config.linhas[indiceLinha].id);
			return;
		}
		abrirMenuScoreboard(player);
	});
}

function abrirEscolherTipoLinhaScoreboard(player) {
	const tipos = getTiposLinha();
	const form = new ActionFormData().title("Tipo de Linha").body("O que essa linha vai mostrar?");
	tipos.forEach((t) => form.button(t.nome, "textures/items/paper"));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < tipos.length) {
			abrirConfigurarLinhaScoreboard(player, tipos[res.selection].id, null);
			return;
		}
		abrirListaLinhasScoreboard(player);
	});
}

const ROTULOS_PADRAO_SCOREBOARD = {
	online: "Online",
	tempoOnline: "Tempo Online",
	abates: "Abates",
	moedas: "Moedas",
	cps: "CPS",
	cpsAoVivo: "CPS",
	abateAoVivo: "Ultimo Abate",
	xp: "XP",
	clan: "Clã",
	tps: "TPS"
};

// tipo: id do tipo escolhido. linhaExistente: objeto da linha se for edicao, ou null se for criacao nova.
function abrirConfigurarLinhaScoreboard(player, tipo, linhaExistente) {
	const voltar = () => (linhaExistente ? abrirEditarLinhaScoreboard(player, linhaExistente.id) : abrirListaLinhasScoreboard(player));

	if (tipo === "data") {
		// Sem nada pra configurar - so mostra a data real, sem rotulo.
		if (!linhaExistente) adicionarLinhaScoreboard(tipo, {});
		player.sendMessage("§aEssa linha nao tem nada pra configurar, so mostra a data de hoje.");
		abrirListaLinhasScoreboard(player);
		return;
	}

	if (tipo === "texto") {
		const modal = new ModalFormData()
			.title("Texto Livre")
			.textField("Texto (use \\n pra quebrar linha)", "Ex: §e§lBem-vindo!", { defaultValue: linhaExistente?.texto ?? "" });

		modal
			.show(player)
			.then((res) => {
				if (res.canceled) {
					voltar();
					return;
				}
				const dados = { texto: res.formValues[0] };
				if (linhaExistente) editarLinhaScoreboard(linhaExistente.id, dados);
				else adicionarLinhaScoreboard(tipo, dados);
				abrirListaLinhasScoreboard(player);
			})
			.catch((erro) => console.warn(`Erro ao configurar linha de texto: ${erro}`));
		return;
	}

	if (tipo === "divisor") {
		const corAtual = linhaExistente?.cor ?? linhaExistente?.cores?.[0] ?? "§7";
		const indice = CORES_TEXTO_ANIMADO.findIndex((c) => c.codigo === corAtual);

		const modal = new ModalFormData()
			.title("Divisor Animado")
			.dropdown("Cor", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: indice >= 0 ? indice : 9 });

		modal
			.show(player)
			.then((res) => {
				if (res.canceled) {
					voltar();
					return;
				}
				const cor = CORES_TEXTO_ANIMADO[res.formValues[0] ?? 0]?.codigo ?? "§7";
				const dados = { cor };
				if (linhaExistente) editarLinhaScoreboard(linhaExistente.id, dados);
				else adicionarLinhaScoreboard(tipo, dados);
				abrirListaLinhasScoreboard(player);
			})
			.catch((erro) => console.warn(`Erro ao configurar divisor do scoreboard: ${erro}`));
		return;
	}

	if (tipo === "textoAnimado") {
		const coresAtuais = linhaExistente?.cores ?? ["§d", "§b", "§e"];
		const indiceAtual = (codigoAtual, padrao) => {
			const indice = CORES_TEXTO_ANIMADO.findIndex((c) => c.codigo === codigoAtual);
			return indice >= 0 ? indice : padrao;
		};

		const modal = new ModalFormData()
			.title("Texto Animado")
			.textField("Texto (sem codigo de cor)", "Ex: Loja Aberta!", { defaultValue: linhaExistente?.texto ?? "" })
			.dropdown("Cor 1", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: indiceAtual(coresAtuais[0], 5) })
			.dropdown("Cor 2", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: indiceAtual(coresAtuais[1], 6) })
			.dropdown("Cor 3", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: indiceAtual(coresAtuais[2], 3) });

		modal
			.show(player)
			.then((res) => {
				if (res.canceled) {
					voltar();
					return;
				}
				const cores = [
					CORES_TEXTO_ANIMADO[res.formValues[1] ?? 0]?.codigo ?? "§d",
					CORES_TEXTO_ANIMADO[res.formValues[2] ?? 0]?.codigo ?? "§b",
					CORES_TEXTO_ANIMADO[res.formValues[3] ?? 0]?.codigo ?? "§e"
				];
				const dados = { texto: res.formValues[0], cores };
				if (linhaExistente) editarLinhaScoreboard(linhaExistente.id, dados);
				else adicionarLinhaScoreboard(tipo, dados);
				abrirListaLinhasScoreboard(player);
			})
			.catch((erro) => console.warn(`Erro ao configurar texto animado do scoreboard: ${erro}`));
		return;
	}

	if (tipo === "duasColunas") {
		const tiposSimples = getTiposSimples();
		const nomesTiposSimples = tiposSimples.map((t) => t.nome);
		const indicePorTipo = (tipoId, padrao) => {
			const indice = tiposSimples.findIndex((t) => t.id === tipoId);
			return indice >= 0 ? indice : padrao;
		};

		const modal = new ModalFormData()
			.title("Duas Colunas")
			.dropdown("Primeiro status", nomesTiposSimples, { defaultValueIndex: indicePorTipo(linhaExistente?.tipo1, 0) })
			.textField("Rotulo do primeiro", "Ex: CPS", { defaultValue: linhaExistente?.rotulo1 ?? "CPS" })
			.dropdown("Segundo status", nomesTiposSimples, { defaultValueIndex: indicePorTipo(linhaExistente?.tipo2, 1) })
			.textField("Rotulo do segundo", "Ex: TPS", { defaultValue: linhaExistente?.rotulo2 ?? "TPS" });

		modal
			.show(player)
			.then((res) => {
				if (res.canceled) {
					voltar();
					return;
				}
				const dados = {
					tipo1: tiposSimples[res.formValues[0] ?? 0].id,
					rotulo1: res.formValues[1] || "A",
					tipo2: tiposSimples[res.formValues[2] ?? 0].id,
					rotulo2: res.formValues[3] || "B"
				};
				if (linhaExistente) editarLinhaScoreboard(linhaExistente.id, dados);
				else adicionarLinhaScoreboard(tipo, dados);
				abrirListaLinhasScoreboard(player);
			})
			.catch((erro) => console.warn(`Erro ao configurar linha de duas colunas: ${erro}`));
		return;
	}

	// data, online, tempoOnline, abates, moedas, cps, xp, clan, tps: so o rotulo muda.
	const rotuloPadrao = ROTULOS_PADRAO_SCOREBOARD[tipo] ?? tipo.toUpperCase();
	const modal = new ModalFormData()
		.title("Editar Rotulo")
		.textField("Rotulo (o nome que aparece antes dos dois pontos)", `Ex: ${rotuloPadrao}`, {
			defaultValue: linhaExistente?.rotulo ?? rotuloPadrao
		});

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				voltar();
				return;
			}
			const dados = { rotulo: res.formValues[0] || rotuloPadrao };
			if (linhaExistente) editarLinhaScoreboard(linhaExistente.id, dados);
			else adicionarLinhaScoreboard(tipo, dados);
			abrirListaLinhasScoreboard(player);
		})
		.catch((erro) => console.warn(`Erro ao configurar linha do scoreboard: ${erro}`));
}

function abrirEditarLinhaScoreboard(player, id) {
	const config = getConfigScoreboard();
	const linha = config.linhas.find((l) => l.id === id);
	if (!linha) {
		abrirListaLinhasScoreboard(player);
		return;
	}
	const tipo = getTiposLinha().find((t) => t.id === linha.tipo);

	const form = new ActionFormData()
		.title(tipo?.nome ?? linha.tipo)
		.button("Editar Conteudo", "textures/items/book_writable")
		.button("Mover pra Cima", "textures/ui/up_arrow")
		.button("Mover pra Baixo", "textures/ui/down_arrow")
		.button("Remover", ICONE_APAGAR)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			abrirConfigurarLinhaScoreboard(player, linha.tipo, linha);
			return;
		}
		if (res.selection === 1) {
			moverLinhaScoreboard(id, -1);
			abrirListaLinhasScoreboard(player);
			return;
		}
		if (res.selection === 2) {
			moverLinhaScoreboard(id, 1);
			abrirListaLinhasScoreboard(player);
			return;
		}
		if (res.selection === 3) {
			confirmarAcaoPainel(
				player,
				"Remover Linha",
				"Remover essa linha do scoreboard?",
				() => {
					removerLinhaScoreboard(id);
					player.sendMessage("§aLinha removida!");
					abrirListaLinhasScoreboard(player);
				},
				() => abrirEditarLinhaScoreboard(player, id)
			);
			return;
		}
		abrirListaLinhasScoreboard(player);
	});
}

// ===== ABA TEXTO VOADOR =====

function abrirMenuTextoVoador(player) {
	const form = new ActionFormData()
		.title("Texto Voador")
		.body("§7Crie hologramas de texto fixos no mundo (avisos, rankings, etc).")
		.button("Criar Texto\n§7[Escreva algo]", ICONE_CRIAR)
		.button("Texto Animado\n§7[Cores que mudam]", "textures/items/nautilus_shell")
		.button("Texto Rapido\n§7[Cor rapida + letreiro]", "textures/items/feather")
		.button("Prontos\n§7[Rankings e listas]", ICONE_TEXTO_VOADOR)
		.button("Editar\n§7[Mude um existente]", "textures/items/book_writable")
		.button("Apagar\n§7[Remove um existente]", ICONE_APAGAR)
		.button("Voltar", ICONE_VOLTAR);

	form
		.show(player)
		.then((res) => {
			if (res.canceled) return;
			if (res.selection === 0) {
				abrirCriarTextoVoador(player);
				return;
			}
			if (res.selection === 1) {
				abrirCriarTextoAnimado(player);
				return;
			}
			if (res.selection === 2) {
				abrirCriarTextoRapido(player);
				return;
			}
			if (res.selection === 3) {
				abrirTextosProntos(player);
				return;
			}
			if (res.selection === 4) {
				abrirListaTextosVoadores(player, "editar");
				return;
			}
			if (res.selection === 5) {
				abrirListaTextosVoadores(player, "apagar");
				return;
			}
			abrirPainelDono(player);
		})
		.catch((erro) => console.warn(`Erro ao abrir menu de texto voador: ${erro}`));
}

function abrirCriarTextoVoador(player) {
	const modal = new ModalFormData().title("Criar Texto").textField("Texto (use \\n pra quebrar linha)", "Ex: §e§lBem-vindo!");

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuTextoVoador(player);
				return;
			}
			criarTextoFixo(player, res.formValues[0]);
			abrirMenuTextoVoador(player);
		})
		.catch((erro) => console.warn(`Erro ao criar texto voador: ${erro}`));
}

const NOMES_CORES_TEXTO_ANIMADO = CORES_TEXTO_ANIMADO.map((c) => c.id);

function abrirCriarTextoAnimado(player) {
	const modal = new ModalFormData()
		.title("Texto Animado")
		.textField("Texto (use \\n pra quebrar linha, sem codigo de cor)", "Ex: Loja Aberta!")
		.dropdown("Cor 1", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: 5 })
		.dropdown("Cor 2", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: 6 })
		.dropdown("Cor 3", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: 3 });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuTextoVoador(player);
				return;
			}
			const cor1 = NOMES_CORES_TEXTO_ANIMADO[res.formValues[1] ?? 0];
			const cor2 = NOMES_CORES_TEXTO_ANIMADO[res.formValues[2] ?? 0];
			const cor3 = NOMES_CORES_TEXTO_ANIMADO[res.formValues[3] ?? 0];
			criarTextoAnimado(player, res.formValues[0], cor1, cor2, cor3);
			abrirMenuTextoVoador(player);
		})
		.catch((erro) => console.warn(`Erro ao criar texto animado: ${erro}`));
}

function abrirCriarTextoRapido(player) {
	const modal = new ModalFormData()
		.title("Texto Rapido")
		.textField("Texto (se for grande, desliza tipo letreiro)", "Ex: Loja aberta! Vem conferir as promocoes!")
		.dropdown("Cor 1", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: 8 })
		.dropdown("Cor 2", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: 6 })
		.dropdown("Cor 3", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: 3 })
		.dropdown("Quantas letras aparecem por vez", ["5 letras", "10 letras"], { defaultValueIndex: 0 });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuTextoVoador(player);
				return;
			}
			const cor1 = NOMES_CORES_TEXTO_ANIMADO[res.formValues[1] ?? 0];
			const cor2 = NOMES_CORES_TEXTO_ANIMADO[res.formValues[2] ?? 0];
			const cor3 = NOMES_CORES_TEXTO_ANIMADO[res.formValues[3] ?? 0];
			const janela = (res.formValues[4] ?? 0) === 1 ? 10 : 5;
			criarTextoRapido(player, res.formValues[0], cor1, cor2, cor3, janela);
			abrirMenuTextoVoador(player);
		})
		.catch((erro) => console.warn(`Erro ao criar texto rapido: ${erro}`));
}

function abrirTextosProntos(player) {
	const form = new ActionFormData()
		.title("Prontos")
		.body("Escolha um modelo pronto pra criar:")
		.button("Top Abates\n§7[Ranking de PvP]", "textures/items/diamond_sword")
		.button("Top Saldo\n§7[Ranking de dinheiro]", "textures/items/emerald")
		.button("Top Clan\n§7[Ranking de clans]", ICONE_JOGADORES)
		.button("Top CPS\n§7[Quem clica mais rapido]", "textures/items/stick")
		.button("Jogadores Online\n§7[Lista ao vivo]", ICONE_JOGADORES)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			abrirCriarRankingPronto(player, "Top Abates", criarTopAbates);
			return;
		}
		if (res.selection === 1) {
			abrirCriarRankingPronto(player, "Top Saldo", criarTopSaldo);
			return;
		}
		if (res.selection === 2) {
			abrirCriarRankingPronto(player, "Top Clan", criarTopClan);
			return;
		}
		if (res.selection === 3) {
			abrirCriarRankingPronto(player, "Top CPS", criarTopCps);
			return;
		}
		if (res.selection === 4) {
			const modal = new ModalFormData()
				.title("Jogadores Online")
				.textField("Titulo", "Ex: Jogadores Online", { defaultValue: "Jogadores Online" });
			modal
				.show(player)
				.then((r) => {
					if (r.canceled) {
						abrirTextosProntos(player);
						return;
					}
					criarListaJogadores(player, r.formValues[0]);
					abrirMenuTextoVoador(player);
				})
				.catch((erro) => console.warn(`Erro ao criar lista de jogadores: ${erro}`));
			return;
		}
		abrirMenuTextoVoador(player);
	});
}

function abrirCriarRankingPronto(player, tituloPadrao, funcaoCriar) {
	const modal = new ModalFormData()
		.title(tituloPadrao)
		.textField("Titulo", `Ex: ${tituloPadrao}`, { defaultValue: tituloPadrao })
		.textField("Quantidade de jogadores (1 a 10)", "Ex: 10", { defaultValue: "10" });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirTextosProntos(player);
				return;
			}
			funcaoCriar(player, res.formValues[0], res.formValues[1]);
			abrirMenuTextoVoador(player);
		})
		.catch((erro) => console.warn(`Erro ao criar ranking pronto: ${erro}`));
}

// modo: "editar" ou "apagar"
function abrirListaTextosVoadores(player, modo) {
	const textos = getListaTextos();

	const form = new ActionFormData()
		.title(modo === "editar" ? "Editar Texto Voador" : "Apagar Texto Voador")
		.body(textos.length > 0 ? "Toque num texto voador:" : "Nenhum texto voador foi criado ainda.");

	textos.forEach((t) => form.button(getResumoTexto(t), ICONE_TEXTO_VOADOR));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < textos.length) {
			const alvo = textos[res.selection];
			if (modo === "editar") abrirEditarTextoVoador(player, alvo);
			else abrirConfirmarApagarTextoVoador(player, alvo);
			return;
		}
		abrirMenuTextoVoador(player);
	});
}

function abrirEditarTextoVoador(player, config) {
	if (config.tipo === "texto") {
		const modal = new ModalFormData()
			.title("Editar Texto")
			.textField("Novo texto (use \\n pra quebrar linha)", "Digite o texto", { defaultValue: config.texto });
		modal
			.show(player)
			.then((res) => {
				if (res.canceled) {
					abrirListaTextosVoadores(player, "editar");
					return;
				}
				editarTexto(player, config.id, { texto: res.formValues[0] });
				abrirMenuTextoVoador(player);
			})
			.catch((erro) => console.warn(`Erro ao editar texto voador: ${erro}`));
		return;
	}

	if (config.tipo === "listaJogadores") {
		const modal = new ModalFormData().title("Editar Lista").textField("Titulo", "Digite o titulo", { defaultValue: config.titulo });
		modal
			.show(player)
			.then((res) => {
				if (res.canceled) {
					abrirListaTextosVoadores(player, "editar");
					return;
				}
				editarTexto(player, config.id, { titulo: res.formValues[0] });
				abrirMenuTextoVoador(player);
			})
			.catch((erro) => console.warn(`Erro ao editar lista de jogadores: ${erro}`));
		return;
	}

	if (config.tipo === "textoAnimado") {
		const coresAtuais = config.cores ?? ["§d", "§b", "§e"];
		const indiceAtual = (codigo, padrao) => {
			const indice = CORES_TEXTO_ANIMADO.findIndex((c) => c.codigo === codigo);
			return indice >= 0 ? indice : padrao;
		};

		const modal = new ModalFormData()
			.title("Editar Texto Animado")
			.textField("Texto (sem codigo de cor)", "Digite o texto", { defaultValue: config.texto })
			.dropdown("Cor 1", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: indiceAtual(coresAtuais[0], 5) })
			.dropdown("Cor 2", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: indiceAtual(coresAtuais[1], 6) })
			.dropdown("Cor 3", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: indiceAtual(coresAtuais[2], 3) });

		modal
			.show(player)
			.then((res) => {
				if (res.canceled) {
					abrirListaTextosVoadores(player, "editar");
					return;
				}
				const cores = [
					CORES_TEXTO_ANIMADO[res.formValues[1] ?? 0]?.codigo ?? "§d",
					CORES_TEXTO_ANIMADO[res.formValues[2] ?? 0]?.codigo ?? "§b",
					CORES_TEXTO_ANIMADO[res.formValues[3] ?? 0]?.codigo ?? "§e"
				];
				editarTexto(player, config.id, { texto: res.formValues[0], cores });
				abrirMenuTextoVoador(player);
			})
			.catch((erro) => console.warn(`Erro ao editar texto animado: ${erro}`));
		return;
	}

	if (config.tipo === "textoRapido") {
		const coresAtuais = config.cores ?? ["§d", "§b", "§e"];
		const indiceAtual = (codigo, padrao) => {
			const indice = CORES_TEXTO_ANIMADO.findIndex((c) => c.codigo === codigo);
			return indice >= 0 ? indice : padrao;
		};

		const modal = new ModalFormData()
			.title("Editar Texto Rapido")
			.textField("Texto (se for grande, desliza tipo letreiro)", "Digite o texto", { defaultValue: config.texto })
			.dropdown("Cor 1", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: indiceAtual(coresAtuais[0], 8) })
			.dropdown("Cor 2", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: indiceAtual(coresAtuais[1], 6) })
			.dropdown("Cor 3", NOMES_CORES_TEXTO_ANIMADO, { defaultValueIndex: indiceAtual(coresAtuais[2], 3) })
			.dropdown("Quantas letras aparecem por vez", ["5 letras", "10 letras"], { defaultValueIndex: config.janela === 10 ? 1 : 0 });

		modal
			.show(player)
			.then((res) => {
				if (res.canceled) {
					abrirListaTextosVoadores(player, "editar");
					return;
				}
				const cores = [
					CORES_TEXTO_ANIMADO[res.formValues[1] ?? 0]?.codigo ?? "§d",
					CORES_TEXTO_ANIMADO[res.formValues[2] ?? 0]?.codigo ?? "§b",
					CORES_TEXTO_ANIMADO[res.formValues[3] ?? 0]?.codigo ?? "§e"
				];
				const janela = (res.formValues[4] ?? 0) === 1 ? 10 : 5;
				editarTexto(player, config.id, { texto: res.formValues[0], cores, janela });
				abrirMenuTextoVoador(player);
			})
			.catch((erro) => console.warn(`Erro ao editar texto rapido: ${erro}`));
		return;
	}

	// topAbates, topSaldo, topClan
	const modal = new ModalFormData()
		.title("Editar Ranking")
		.textField("Titulo", "Digite o titulo", { defaultValue: config.titulo })
		.textField("Quantidade de jogadores (1 a 10)", "Ex: 10", { defaultValue: String(config.quantidade) });
	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirListaTextosVoadores(player, "editar");
				return;
			}
			const quantidade = Math.max(1, Math.min(10, Number(res.formValues[1]) || config.quantidade));
			editarTexto(player, config.id, { titulo: res.formValues[0], quantidade });
			abrirMenuTextoVoador(player);
		})
		.catch((erro) => console.warn(`Erro ao editar ranking: ${erro}`));
}

function abrirConfirmarApagarTextoVoador(player, config) {
	confirmarAcaoPainel(
		player,
		"Apagar Texto Voador",
		`Tem certeza que quer apagar §e${getResumoTexto(config)}§r?`,
		() => {
			removerTexto(player, config.id);
			abrirMenuTextoVoador(player);
		},
		() => abrirListaTextosVoadores(player, "apagar")
	);
}

// ===== ABA TEXTO AUTOMATICO =====

function abrirMenuTextoAutomatico(player) {
	const config = getConfigAuto();
	const mensagens = getMensagens();

	const form = new ActionFormData()
		.title("Texto Automatico")
		.body(
			`§fStatus: ${config.ativo ? "§aAtivado" : "§cDesativado"}\n` +
				`§fMensagens: §e${mensagens.length}/50\n` +
				`§fIntervalo: §e${config.intervaloMinutos} min\n` +
				`§fSom: §e${config.som || "nenhum"}`
		)
		.button("Adicionar Mensagem\n§7[Escreva uma nova]", ICONE_CRIAR)
		.button("Ver Mensagens\n§7[Listar/apagar]", "textures/items/book_writable")
		.button(config.ativo ? "Desativar\n§7[Para de mandar]" : "Ativar\n§7[Comeca a mandar]", config.ativo ? ICONE_DESLIGAR : ICONE_LIGAR)
		.button("Intervalo e Som\n§7[Quando e como manda]", "textures/items/clock")
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			abrirAdicionarMensagemAuto(player);
			return;
		}
		if (res.selection === 1) {
			abrirListaMensagensAuto(player);
			return;
		}
		if (res.selection === 2) {
			definirAutoAtivo(!config.ativo);
			player.sendMessage(config.ativo ? "§eTexto automatico desativado." : "§aTexto automatico ativado!");
			abrirMenuTextoAutomatico(player);
			return;
		}
		if (res.selection === 3) {
			abrirConfigIntervaloAuto(player);
			return;
		}
		abrirPainelDono(player);
	});
}

function abrirAdicionarMensagemAuto(player) {
	const mensagens = getMensagens();
	if (mensagens.length >= 50) {
		player.sendMessage("§cVoce ja atingiu o limite de 50 mensagens. Apague alguma pra adicionar outra.");
		abrirMenuTextoAutomatico(player);
		return;
	}

	const modal = new ModalFormData().title("Adicionar Mensagem").textField("Texto que vai pro chat", "Ex: §aVisite nosso Discord!");

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuTextoAutomatico(player);
				return;
			}
			if (adicionarMensagem(res.formValues[0])) player.sendMessage("§aMensagem adicionada!");
			else player.sendMessage("§cDigite um texto valido.");
			abrirMenuTextoAutomatico(player);
		})
		.catch((erro) => console.warn(`Erro ao adicionar mensagem automatica: ${erro}`));
}

function abrirListaMensagensAuto(player) {
	const mensagens = getMensagens();

	const form = new ActionFormData()
		.title(`Mensagens (${mensagens.length}/50)`)
		.body(mensagens.length > 0 ? "Toque numa mensagem pra apagar ela." : "Nenhuma mensagem cadastrada ainda.");

	mensagens.forEach((m, i) => form.button(`§e${i + 1}. §f${m}`, "textures/items/book_writable"));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < mensagens.length) {
			confirmarAcaoPainel(
				player,
				"Apagar Mensagem",
				`Apagar a mensagem §e${mensagens[res.selection]}§r?`,
				() => {
					removerMensagem(res.selection);
					player.sendMessage("§aMensagem apagada!");
					abrirListaMensagensAuto(player);
				},
				() => abrirListaMensagensAuto(player)
			);
			return;
		}
		abrirMenuTextoAutomatico(player);
	});
}

function abrirConfigIntervaloAuto(player) {
	const config = getConfigAuto();

	const modal = new ModalFormData()
		.title("Intervalo e Som")
		.textField("Intervalo entre mensagens (minutos, max 1440 = 24h)", "Ex: 30", { defaultValue: String(config.intervaloMinutos) });

	const sons = ["nenhum", ...getSonsAuto()];
	const indiceAtual = config.som ? Math.max(0, sons.indexOf(config.som)) : 0;
	modal.dropdown("Som ao mandar", sons, { defaultValueIndex: indiceAtual });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuTextoAutomatico(player);
				return;
			}
			if (!definirIntervaloMinutos(res.formValues[0])) {
				player.sendMessage("§cIntervalo invalido (use um numero de 1 a 1440).");
			} else {
				const somEscolhido = sons[res.formValues[1] ?? 0];
				definirSomAuto(somEscolhido === "nenhum" ? "" : somEscolhido);
				player.sendMessage("§aConfiguracao atualizada!");
			}
			abrirMenuTextoAutomatico(player);
		})
		.catch((erro) => console.warn(`Erro ao configurar intervalo/som: ${erro}`));
}

const FLAGS_LISTA = [
	{ id: "warp", nome: "Sistema de Warp" },
	{ id: "home", nome: "Sistema de Home" },
	{ id: "teleportar", nome: "Pedido de Teleporte (TPA)" },
	{ id: "voltar", nome: "Comando !voltar (volta pro local de morte)" },
	{ id: "reportar", nome: "Comando !reportar" },
	{ id: "loja", nome: "Loja" },
	{ id: "clan", nome: "Sistema de Clan" },
	{ id: "mostrarCps", nome: "Mostrar CPS na Cabeca" },
	{ id: "mostrarAbates", nome: "Mostrar Abates na Cabeca" },
	{ id: "mostrarVida", nome: "Mostrar Vida na Cabeca" },
	{ id: "mostrarCombo", nome: "Mostrar Combo na Cabeca" },
	{ id: "mostrarPlataforma", nome: "Mostrar Plataforma (PC/Celular) na Cabeca" },
	{ id: "combateLog", nome: "Combat Log" },
	{ id: "raioMorte", nome: "Raio de Morte" },
	{ id: "autoColeta", nome: "Auto-Coleta (quebrar/matar vai pro inventario)" }
];

function abrirMenuConfiguracao(player) {
	const form = new ActionFormData()
		.title("Configuracao")
		.body("Escolha o que quer configurar:")
		.button("Funcionalidades\n§7[Ligar/desligar sistemas]", ICONE_CONFIGURAR)
		.button("Clan\n§7[Limite, custo e permissao]", ICONE_CLAN)
		.button("Servidor\n§7[IP, Discord, rtp, saldo...]", "textures/items/emerald")
		.button("Textos e Mensagens\n§7[Regras, boas-vindas, menu]", ICONE_MENSAGENS)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) abrirMenuFuncionalidades(player);
		if (res.selection === 1) abrirMenuConfigClan(player);
		if (res.selection === 2) abrirMenuConfigServidor(player);
		if (res.selection === 3) abrirMenuConfigMensagens(player);
		if (res.selection === 4) abrirPainelDono(player);
	});
}

function abrirMenuConfigMensagens(player) {
	const regras = getRegras();
	const boasVindas = getTextoBoasVindas();
	const nomeMenu = getNomeMenu();
	const mensagemReentrada = getMensagemReentrada();
	const boasVindasAtivo = getBoasVindasAtivo();

	const modal = new ModalFormData()
		.title("Textos e Mensagens")
		.textField("Regras do Servidor (comando !regras)", "Ex: 1. Respeite todos...", { defaultValue: regras })
		.textField("Nome do Menu Principal", "Ex: Realm Essentials", { defaultValue: nomeMenu })
		.toggle("Mostrar formulario de boas-vindas na 1a entrada", { defaultValue: boasVindasAtivo })
		.textField("Mensagem de Boas-Vindas (formulario da 1a entrada)", "Ex: Seja bem-vindo...", { defaultValue: boasVindas })
		.textField("Mensagem de Re-entrada (demais entradas)", "Ex: Use !ajudar...", { defaultValue: mensagemReentrada });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuConfiguracao(player);
				return;
			}
			definirRegras(res.formValues[0]);
			definirNomeMenu(res.formValues[1]);
			definirBoasVindasAtivo(res.formValues[2]);
			definirTextoBoasVindas(res.formValues[3]);
			definirMensagemReentrada(res.formValues[4]);
			player.sendMessage("§aTextos e mensagens atualizados!");
			abrirMenuConfiguracao(player);
		})
		.catch((erro) => console.warn(`Erro ao configurar textos/mensagens: ${erro}`));
}

function abrirMenuFuncionalidades(player) {
	const flags = getFeatureFlags();

	const modal = new ModalFormData().title("Funcionalidades");
	FLAGS_LISTA.forEach((f) => modal.toggle(f.nome, { defaultValue: flags[f.id] }));

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuConfiguracao(player);
				return;
			}
			FLAGS_LISTA.forEach((f, i) => definirFeatureFlag(player, f.id, res.formValues[i]));
			player.sendMessage("§aConfiguracao atualizada!");
			abrirMenuConfiguracao(player);
		})
		.catch((erro) => console.warn(`Erro ao abrir configuracao: ${erro}`));
}

function abrirMenuConfigServidor(player) {
	const rtp = getConfigRtp();
	const combate = getConfigCombatLog();
	const money = getConfigMoney();
	const servidor = getConfigServidor();

	const modal = new ModalFormData()
		.title("Configuracao do Servidor")
		.textField("Nome do servidor", "Ex: Meu Servidor", { defaultValue: servidor.nome })
		.textField("IP do servidor", "Ex: play.meuservidor.com", { defaultValue: servidor.ip })
		.textField("Porta do servidor", "Ex: 19132", { defaultValue: servidor.porta })
		.textField("Link do Discord", "Ex: https://discord.gg/...", { defaultValue: servidor.discord })
		.textField("Distancia do !rtp (blocos, max 10000)", "Ex: 2000", { defaultValue: String(rtp.distancia) })
		.textField("Duracao do Combat Log (segundos)", "Ex: 15", { defaultValue: String(combate.duracaoSegundos) })
		.textField("Saldo Inicial (jogador novo)", "Ex: 0", { defaultValue: String(money.saldoInicial) })
		.textField("Saldo Maximo (geral)", "Ex: 1000000", { defaultValue: String(money.saldoMaximo) });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuConfiguracao(player);
				return;
			}

			const erros = [];
			if (!definirNomeServidor(res.formValues[0])) erros.push("nome do servidor");
			if (!definirIpServidor(res.formValues[1])) erros.push("ip do servidor");
			if (!definirPortaServidor(res.formValues[2])) erros.push("porta do servidor");
			if (!definirDiscordServidor(res.formValues[3])) erros.push("discord");
			if (!definirDistanciaRtp(res.formValues[4])) erros.push("distancia do rtp");
			if (!definirDuracaoCombatLog(res.formValues[5])) erros.push("duracao do combat log");
			if (!definirSaldoInicial(res.formValues[6])) erros.push("saldo inicial");
			if (!definirSaldoMaximo(res.formValues[7])) erros.push("saldo maximo");

			if (erros.length > 0) player.sendMessage(`§cValor invalido em: §e${erros.join(", ")}§c. O resto foi salvo.`);
			else player.sendMessage("§aConfiguracao do servidor atualizada!");

			abrirMenuConfiguracao(player);
		})
		.catch((erro) => console.warn(`Erro ao configurar servidor: ${erro}`));
}

function abrirMenuConfigClan(player) {
	const config = getConfigClan();

	const form = new ActionFormData()
		.title("Configuracao de Clan")
		.body(
			`§fLimite de membros: §e${config.limiteMembros}\n` +
				`§fQuem pode criar: §e${config.modoCriacao === "restrito" ? "So quem tem permissao" : "Todo mundo"}\n` +
				`§fCusto pra criar: §e${config.custoCriar} moedas`
		)
		.button("Limite de Membros\n§7[Max por clan]", ICONE_CONFIGURAR)
		.button("Quem Pode Criar\n§7[Liberar/restringir]", ICONE_JOGADORES)
		.button("Custo pra Criar\n§7[Preco em moedas]", ICONE_DINHEIRO)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			abrirDefinirLimiteMembrosClan(player);
			return;
		}
		if (res.selection === 1) {
			abrirMenuQuemPodeCriarClan(player);
			return;
		}
		if (res.selection === 2) {
			abrirDefinirCustoClan(player);
			return;
		}
		abrirMenuConfiguracao(player);
	});
}

function abrirDefinirLimiteMembrosClan(player) {
	const config = getConfigClan();
	const modal = new ModalFormData()
		.title("Limite de Membros")
		.textField("Maximo de membros por clan (1 a 100)", "Ex: 10", { defaultValue: String(config.limiteMembros) });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuConfigClan(player);
				return;
			}
			if (definirLimiteMembrosClan(res.formValues[0])) {
				player.sendMessage("§aLimite de membros atualizado!");
			} else {
				player.sendMessage("§cDigite um numero valido (1 a 100).");
			}
			abrirMenuConfigClan(player);
		})
		.catch((erro) => console.warn(`Erro ao definir limite de membros do clan: ${erro}`));
}

function abrirDefinirCustoClan(player) {
	const config = getConfigClan();
	const modal = new ModalFormData()
		.title("Custo pra Criar Clan")
		.textField("Custo em moedas (0 = gratis)", "Ex: 0", { defaultValue: String(config.custoCriar) });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuConfigClan(player);
				return;
			}
			if (definirCustoCriarClan(res.formValues[0])) {
				player.sendMessage("§aCusto pra criar clan atualizado!");
			} else {
				player.sendMessage("§cDigite um numero valido (0 ou mais).");
			}
			abrirMenuConfigClan(player);
		})
		.catch((erro) => console.warn(`Erro ao definir custo do clan: ${erro}`));
}

function abrirMenuQuemPodeCriarClan(player) {
	const config = getConfigClan();
	const restrito = config.modoCriacao === "restrito";

	const form = new ActionFormData()
		.title("Quem Pode Criar Clan")
		.body(
			restrito
				? "§eModo atual: apenas jogadores liberados podem criar um clan."
				: "§aModo atual: todo mundo pode criar um clan."
		)
		.button(restrito ? "Liberar pra Todo Mundo" : "Restringir a Jogadores Liberados", ICONE_CONFIGURAR);

	if (restrito) {
		form.button("Liberar um Jogador\n§7[Da permissao]", ICONE_LIGAR);
		form.button("Remover Permissao\n§7[Tira de alguem]", ICONE_DESLIGAR);
	}
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (res.selection === 0) {
			definirModoCriacaoClan(!restrito);
			player.sendMessage(restrito ? "§aAgora todo mundo pode criar um clan." : "§aAgora so quem tiver permissao pode criar um clan.");
			abrirMenuQuemPodeCriarClan(player);
			return;
		}

		if (restrito && res.selection === 1) {
			pedirNomeJogadorPainel(player, "Liberar Jogador", (nomeJogador, alvo) => {
				permitirCriarClan(alvo.id);
				player.sendMessage(`§a${alvo.name}§a agora pode criar um clan!`);
				abrirMenuQuemPodeCriarClan(player);
			});
			return;
		}

		if (restrito && res.selection === 2) {
			pedirNomeJogadorPainel(player, "Remover Permissao", (nomeJogador, alvo) => {
				proibirCriarClan(alvo.id);
				player.sendMessage(`§e${alvo.name}§e nao pode mais criar um clan.`);
				abrirMenuQuemPodeCriarClan(player);
			});
			return;
		}

		abrirMenuConfigClan(player);
	});
}

// Pede o nome de um jogador online e ja resolve pro objeto Player, avisando
// se nao encontrar. Usado nas telas de permissao de clan.
function pedirNomeJogadorPainel(player, titulo, aoConfirmar) {
	const modal = new ModalFormData().title(titulo).textField("Nome do jogador (precisa estar online)", "Ex: Steve");

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuQuemPodeCriarClan(player);
				return;
			}
			const nomeJogador = (res.formValues[0] ?? "").trim();
			const alvo = world.getAllPlayers().find((p) => p.name.toLowerCase() === nomeJogador.toLowerCase());
			if (!alvo) {
				player.sendMessage(`§cJogador §e${nomeJogador}§c nao encontrado online.`);
				abrirMenuQuemPodeCriarClan(player);
				return;
			}
			aoConfirmar(nomeJogador, alvo);
		})
		.catch((erro) => console.warn(`Erro ao pedir nome do jogador: ${erro}`));
}

// ===== ABA GERENCIAMENTO (jogadores + punicoes) =====

function abrirMenuGerenciamento(player) {
	const form = new ActionFormData()
		.title("Gerenciamento")
		.body("Escolha uma categoria:")
		.button("Jogadores", ICONE_JOGADORES)
		.button("Punicao Logs", ICONE_BANS)
		.button("Denuncias", ICONE_LISTA)
		.button("Banir por nome\n§7[Funciona com jogador offline]", ICONE_BANS)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) abrirListaJogadores(player);
		if (res.selection === 1) abrirMenuBanimentos(player);
		if (res.selection === 2) abrirMenuDenuncias(player);
		if (res.selection === 3) abrirBanirPorNome(player);
		if (res.selection === 4) abrirPainelDono(player);
	});
}

// Bane pelo nome, mesmo com o jogador offline (equivale ao !banir).
function abrirBanirPorNome(dono) {
	const modal = new ModalFormData()
		.title("Banir por nome")
		.textField("Nome do jogador (pode estar offline)", "Ex: Fulano123")
		.textField("Motivo do banimento", "Descreva o motivo");

	modal.show(dono).then((res) => {
		if (res.canceled || !res.formValues) {
			abrirMenuGerenciamento(dono);
			return;
		}
		const nome = String(res.formValues[0] ?? "").trim();
		const motivo = String(res.formValues[1] ?? "").trim();
		if (!nome) {
			dono.sendMessage("§cDigite o nome do jogador.");
			abrirBanirPorNome(dono);
			return;
		}
		if (nome.toLowerCase() === dono.name.toLowerCase()) {
			dono.sendMessage("§cVocê não pode banir a si mesmo.");
			abrirMenuGerenciamento(dono);
			return;
		}
		const online = world.getPlayers({ name: nome })[0];
		banirJogador(online ?? { name: nome }, motivo, dono);
		dono.sendMessage(`§a${nome} foi banido${online ? "" : " §7(estava offline)§a"}. §7Motivo: ${motivo || "Não informado"}`);
		abrirMenuGerenciamento(dono);
	});
}

function abrirMenuDenuncias(player) {
	const reports = getReports();

	const linhas =
		reports.length > 0
			? reports
					.slice(-20)
					.reverse()
					.map((r) =>
						r.tipo === "jogador"
							? `§c[Jogador] §e${r.denunciante}§r denunciou §e${r.alvo}§r\n§7${r.motivo}`
							: `§6[Servidor] §e${r.denunciante}§r\n§7${r.motivo}`
					)
					.join("\n\n")
			: "Nenhuma denuncia registrada ainda.";

	const form = new ActionFormData()
		.title(`Denuncias (${reports.length})`)
		.body(linhas)
		.button("Limpar Denuncias", ICONE_APAGAR)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			confirmarAcaoPainel(
				player,
				"Limpar Denuncias",
				"Tem certeza que deseja apagar todas as denuncias registradas?",
				() => {
					limparDenuncias(player);
					abrirMenuGerenciamento(player);
				},
				() => abrirMenuDenuncias(player)
			);
			return;
		}
		abrirMenuGerenciamento(player);
	});
}

// ===== ABA JOGADORES =====

function abrirListaJogadores(player) {
	const jogadores = world.getAllPlayers().filter((p) => p.id !== player.id);

	const form = new ActionFormData()
		.title("Jogadores Online")
		.body(jogadores.length > 0 ? "Toque num jogador pra gerenciar." : "Nenhum outro jogador esta online.");

	jogadores.forEach((p) => form.button(p.name, ICONE_JOGADORES));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < jogadores.length) {
			abrirMenuGerenciarJogador(player, jogadores[res.selection]);
			return;
		}
		abrirMenuGerenciamento(player);
	});
}

function abrirMenuGerenciarJogador(dono, alvo) {
	const alvoMutado = isMutado(alvo.name);
	const alvoCongelado = isCongelado(alvo);
	const alvoCastigado = estaCastigado(alvo);

	const form = new ActionFormData()
		.title(alvo.name)
		.button("Banir", ICONE_BAN)
		.button("Kick", ICONE_KICK)
		.button(alvoMutado ? "Desmutar" : "Mutar", alvoMutado ? ICONE_UNMUTE : ICONE_MUTE)
		.button(alvoCongelado ? "Descongelar" : "Congelar", alvoCongelado ? ICONE_UNFREEZE : ICONE_FREEZE)
		.button(alvoCastigado ? "Retirar Castigo" : "Castigar", "textures/blocks/glass")
		.button("Ver Inventario", ICONE_INVENTARIO)
		.button("Ver Home", ICONE_HOME)
		.button("Ver Bau do Ender", ICONE_ENDERCHEST)
		.button("Voltar", ICONE_VOLTAR);

	form.show(dono).then((res) => {
		if (res.canceled) return;

		switch (res.selection) {
			case 0:
				abrirMotivoBanimento(dono, alvo);
				return;
			case 1:
				abrirMotivoKick(dono, alvo);
				return;
			case 2:
				if (alvoMutado) {
					desmutarJogador(alvo.name);
					dono.sendMessage(`§a${alvo.name} foi desmutado.`);
					abrirMenuGerenciarJogador(dono, alvo);
				} else {
					abrirMotivoMute(dono, alvo);
				}
				return;
			case 3:
				if (alvoCongelado) {
					descongelarJogador(alvo);
					dono.sendMessage(`§a${alvo.name} foi descongelado.`);
					alvo.sendMessage("§aVoce foi descongelado.");
				} else {
					congelarJogador(alvo);
					dono.sendMessage(`§a${alvo.name} foi congelado.`);
				}
				abrirMenuGerenciarJogador(dono, alvo);
				return;
			case 4:
				if (alvoCastigado) retirarCastigo(dono, alvo);
				else castigarJogador(dono, alvo);
				abrirMenuGerenciarJogador(dono, alvo);
				return;
			case 5:
				abrirInventarioJogador(dono, alvo);
				return;
			case 6:
				abrirHomesJogador(dono, alvo);
				return;
			case 7:
				verBauDoEnder(dono, alvo);
				return;
			case 8:
				abrirListaJogadores(dono);
				return;
		}
	});
}

function abrirMotivoBanimento(dono, alvo) {
	const modal = new ModalFormData().title(`Banir ${alvo.name}`).textField("Motivo do banimento", "Descreva o motivo");

	modal.show(dono).then((res) => {
		if (res.canceled) {
			abrirMenuGerenciarJogador(dono, alvo);
			return;
		}
		const motivo = (res.formValues[0] ?? "").trim();
		banirJogador(alvo, motivo, dono);
		dono.sendMessage(`§a${alvo.name} foi banido. §7Motivo: ${motivo || "Nao informado"}`);
		abrirListaJogadores(dono);
	});
}

function abrirMotivoKick(dono, alvo) {
	const modal = new ModalFormData().title(`Kick em ${alvo.name}`).textField("Motivo do kick", "Descreva o motivo");

	modal.show(dono).then((res) => {
		if (res.canceled) {
			abrirMenuGerenciarJogador(dono, alvo);
			return;
		}
		const motivo = (res.formValues[0] ?? "").trim();
		kickJogador(alvo, motivo, dono);
		dono.sendMessage(`§a${alvo.name} foi expulso. §7Motivo: ${motivo || "Nao informado"}`);
		abrirListaJogadores(dono);
	});
}

function abrirMotivoMute(dono, alvo) {
	const modal = new ModalFormData().title(`Mutar ${alvo.name}`).textField("Motivo do mute", "Descreva o motivo");

	modal.show(dono).then((res) => {
		if (res.canceled) {
			abrirMenuGerenciarJogador(dono, alvo);
			return;
		}
		const motivo = (res.formValues[0] ?? "").trim();
		mutarJogador(alvo, motivo, dono);
		dono.sendMessage(`§a${alvo.name} foi mutado. §7Motivo: ${motivo || "Nao informado"}`);
		abrirMenuGerenciarJogador(dono, alvo);
	});
}

// ===== ABA BANIMENTOS =====

function abrirMenuBanimentos(player) {
	const form = new ActionFormData()
		.title("Punicao Logs")
		.body("Escolha o que quer ver:")
		.button("Jogadores Banidos", ICONE_BAN)
		.button("Jogadores Mutados", ICONE_MUTE)
		.button("Jogadores Congelados", ICONE_FREEZE)
		.button("Jogadores de Castigo", "textures/blocks/glass")
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) abrirListaBanidos(player);
		if (res.selection === 1) abrirListaMutados(player);
		if (res.selection === 2) abrirListaCongelados(player);
		if (res.selection === 3) abrirListaCastigados(player);
		if (res.selection === 4) abrirMenuGerenciamento(player);
	});
}

function abrirListaCastigados(player) {
	const castigados = getListaCastigados();

	const form = new ActionFormData()
		.title("Jogadores de Castigo")
		.body(castigados.length > 0 ? "Toque num jogador pra liberar." : "Ninguem esta de castigo agora.");
	castigados.forEach((c) => form.button(`${c.nome} §7(por ${c.castigadoPor})`, "textures/blocks/glass"));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < castigados.length) {
			retirarCastigo(player, castigados[res.selection].nome);
			abrirListaCastigados(player);
			return;
		}
		abrirMenuBanimentos(player);
	});
}

function abrirListaBanidos(player) {
	const bans = getBans();
	const nomes = Object.keys(bans);

	const form = new ActionFormData()
		.title("Jogadores Banidos")
		.body(nomes.length > 0 ? "Toque num jogador pra dar unban." : "Nenhum jogador banido no momento.");

	nomes.forEach((chave) => form.button(bans[chave].nome, ICONE_BAN));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < nomes.length) {
			abrirConfirmarUnban(player, bans[nomes[res.selection]]);
			return;
		}
		abrirMenuBanimentos(player);
	});
}

function abrirConfirmarUnban(player, info) {
	const form = new MessageFormData()
		.title(`Unban - ${info.nome}`)
		.body(`§fMotivo do ban: §e${info.motivo}\n§fBanido por: §e${info.por}\n\nTem certeza que quer remover o ban?`)
		.button1("Sim, remover ban")
		.button2("Cancelar");

	form.show(player).then((res) => {
		if (res.canceled || res.selection === 1) {
			abrirListaBanidos(player);
			return;
		}
		desbanirJogador(info.nome);
		player.sendMessage(`§a${info.nome} foi desbanido.`);
		abrirListaBanidos(player);
	});
}

function abrirListaMutados(player) {
	const mutes = getMutes();
	const nomes = Object.keys(mutes);

	const form = new ActionFormData()
		.title("Jogadores Mutados")
		.body(nomes.length > 0 ? "Toque num jogador pra dar unmute." : "Nenhum jogador mutado no momento.");

	nomes.forEach((chave) => form.button(mutes[chave].nome, ICONE_MUTE));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < nomes.length) {
			abrirConfirmarUnmute(player, mutes[nomes[res.selection]]);
			return;
		}
		abrirMenuBanimentos(player);
	});
}

function abrirConfirmarUnmute(player, info) {
	const form = new MessageFormData()
		.title(`Unmute - ${info.nome}`)
		.body(`§fMotivo do mute: §e${info.motivo}\n§fMutado por: §e${info.por}\n\nTem certeza que quer remover o mute?`)
		.button1("Sim, remover mute")
		.button2("Cancelar");

	form.show(player).then((res) => {
		if (res.canceled || res.selection === 1) {
			abrirListaMutados(player);
			return;
		}
		desmutarJogador(info.nome);
		player.sendMessage(`§a${info.nome} foi desmutado.`);
		abrirListaMutados(player);
	});
}

function abrirListaCongelados(player) {
	const congelados = getCongeladosOnline().filter((p) => p.id !== player.id);

	const form = new ActionFormData()
		.title("Jogadores Congelados")
		.body(congelados.length > 0 ? "Toque num jogador pra descongelar." : "Ninguem esta congelado no momento.");

	congelados.forEach((p) => form.button(p.name, ICONE_FREEZE));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < congelados.length) {
			const alvo = congelados[res.selection];
			descongelarJogador(alvo);
			player.sendMessage(`§a${alvo.name} foi descongelado.`);
			try {
				alvo.sendMessage("§aVoce foi descongelado.");
			} catch (erro) {
				console.warn(`Erro ao avisar jogador descongelado: ${erro}`);
			}
			abrirListaCongelados(player);
			return;
		}
		abrirMenuBanimentos(player);
	});
}

// ===== ABA WARP =====
// Aqui todo mundo pode usar as warps (menu normal), mas so quem tem a tag
// "dono" consegue criar, renomear ou apagar (checado dentro de warp.js).

function abrirMenuWarpDono(player) {
	const warps = getWarps();
	const nomes = Object.keys(warps);

	const form = new ActionFormData()
		.title("Warp")
		.body(nomes.length > 0 ? "Toque numa warp pra gerenciar." : "Nenhuma warp criada ainda.");

	nomes.forEach((nome) => {
		const w = warps[nome];
		const linhaComando = w.comando ? `\n§7!${w.comando}` : "";
		form.button(`${nome}${linhaComando}`, w.icone ?? ICONE_WARP);
	});
	form.button("Criar Warp", ICONE_CRIAR);
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (res.selection < nomes.length) {
			abrirGerenciarWarp(player, nomes[res.selection]);
			return;
		}

		if (res.selection === nomes.length) {
			abrirCriarWarpDono(player);
			return;
		}

		abrirPainelDono(player);
	});
}

function abrirCriarWarpDono(player) {
	const nomesIcones = ICONES_WARP.map((i) => i.nome);

	const modal = new ModalFormData()
		.title("Criar Warp")
		.textField("Nome da warp", "Vai criar aqui onde voce esta")
		.textField("Comando (opcional, sem o !)", "Ex: spawn - deixe vazio se nao quiser")
		.dropdown("Icone da warp", nomesIcones, { defaultValueIndex: 0 });

	modal.show(player).then((res) => {
		if (res.canceled) {
			abrirMenuWarpDono(player);
			return;
		}
		const nome = (res.formValues[0] ?? "").trim();
		const comando = (res.formValues[1] ?? "").trim();
		const icone = ICONES_WARP[res.formValues[2] ?? 0].icone;
		criarWarp(player, nome, comando, icone);
		abrirMenuWarpDono(player);
	});
}

function abrirGerenciarWarp(player, nome) {
	const form = new ActionFormData()
		.title(nome)
		.button("Renomear", ICONE_RENOMEAR)
		.button("Apagar", ICONE_APAGAR)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (res.selection === 0) {
			abrirRenomearWarp(player, nome);
			return;
		}

		if (res.selection === 1) {
			confirmarAcaoPainel(
				player,
				"Apagar Warp",
				`Tem certeza que quer apagar a warp §e${nome}§r?`,
				() => {
					removerWarp(player, nome);
					abrirMenuWarpDono(player);
				},
				() => abrirMenuWarpDono(player)
			);
			return;
		}

		abrirMenuWarpDono(player);
	});
}

export function abrirRenomearWarp(player, nome) {
	const warps = getWarps();
	if (!warps[nome]) {
		player.sendMessage(`§cNao existe uma warp chamada §e${nome}§c.`);
		return;
	}

	const modal = new ModalFormData().title(`Renomear - ${nome}`).textField("Novo nome", "Digite o novo nome", { defaultValue: nome });

	modal.show(player).then((res) => {
		if (res.canceled) {
			abrirMenuWarpDono(player);
			return;
		}
		const novoNome = (res.formValues[0] ?? "").trim();
		renomearWarp(player, nome, novoNome);
		abrirMenuWarpDono(player);
	});
}

// ===== ABA AREA PROTEGIDA =====

function abrirMenuAreaProtegida(player) {
	const areas = listarAreas();
	const nomes = Object.keys(areas);

	const form = new ActionFormData()
		.title("Area Protegida")
		.body(
			nomes.length > 0
				? "§7Toque numa area pra gerenciar as permissoes e os efeitos.\n§7Por padrao quem entra ganha regeneracao, weakness, resistencia a fogo e resistencia."
				: "§7Nenhuma area protegida criada ainda.\n§7Fique no local desejado e toque em Criar Area."
		);

	nomes.forEach((nome) => form.button(`${nome}\n§7[Raio: ${areas[nome].raio}]`, ICONE_AREA));
	form.button("Criar Area\n§7[Aqui onde eu estou]", ICONE_CRIAR);
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (res.selection < nomes.length) {
			abrirGerenciarAreaProtegida(player, nomes[res.selection]);
			return;
		}

		if (res.selection === nomes.length) {
			abrirCriarAreaProtegida(player);
			return;
		}

		abrirPainelDono(player);
	});
}

function abrirCriarAreaProtegida(player) {
	const modal = new ModalFormData()
		.title("Criar Area Protegida")
		.textField("Nome da area", "Vai criar aqui onde voce esta")
		.textField("Raio (em blocos)", "Ex: 15", { defaultValue: "15" });

	modal.show(player).then((res) => {
		if (res.canceled) {
			abrirMenuAreaProtegida(player);
			return;
		}
		const nome = (res.formValues[0] ?? "").trim();
		const raio = Number(res.formValues[1]);
		const resultado = criarArea(player, nome, raio);
		if (!resultado.ok) player.sendMessage(`§c${resultado.motivo}`);
		abrirMenuAreaProtegida(player);
	});
}

function abrirGerenciarAreaProtegida(player, nome) {
	const areas = listarAreas();
	const area = areas[nome];
	if (!area) {
		abrirMenuAreaProtegida(player);
		return;
	}

	const rotulo = (ligado) => (ligado ? "§aPermitido" : "§cBloqueado");

	const form = new ActionFormData()
		.title(nome)
		.body(`§7Raio: §f${area.raio} blocos§r\n§7Toque numa permissao pra alternar.`)
		.button(`Abrir Bau\n${rotulo(area.permissoes.abrirBau)}`, ICONE_AREA)
		.button(`Interagir\n${rotulo(area.permissoes.interagir)}`, ICONE_AREA)
		.button(`PVP\n${rotulo(area.permissoes.pvp)}`, "textures/items/diamond_sword")
		.button(`Quebrar Bloco\n${rotulo(area.permissoes.quebrarBloco)}`, "textures/items/diamond_pickaxe")
		.button("Efeitos\n§7[Escolha o que da pra quem entrar]", "textures/mob_effect/resistance")
		.button("Apagar Area", ICONE_APAGAR)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		const chaves = ["abrirBau", "interagir", "pvp", "quebrarBloco"];
		if (res.selection < chaves.length) {
			const chave = chaves[res.selection];
			definirPermissaoArea(nome, chave, !area.permissoes[chave]);
			abrirGerenciarAreaProtegida(player, nome);
			return;
		}

		if (res.selection === chaves.length) {
			abrirEfeitosAreaProtegida(player, nome);
			return;
		}

		if (res.selection === chaves.length + 1) {
			confirmarAcaoPainel(
				player,
				"Apagar Area Protegida",
				`Tem certeza que quer apagar a area §e${nome}§r?`,
				() => {
					deletarArea(nome);
					abrirMenuAreaProtegida(player);
				},
				() => abrirGerenciarAreaProtegida(player, nome)
			);
			return;
		}

		abrirMenuAreaProtegida(player);
	});
}

function abrirEfeitosAreaProtegida(player, nome) {
	const areas = listarAreas();
	const area = areas[nome];
	if (!area) {
		abrirMenuAreaProtegida(player);
		return;
	}

	const efeitosAtivos = getEfeitosArea(area);

	const form = new ActionFormData()
		.title(`Efeitos - ${nome}`)
		.body(
			area.permissoes.pvp
				? "§ePVP esta liberado nessa area, entao nenhum efeito e aplicado agora - mesmo os marcados como ativados aqui.\n\n§7Toque num efeito pra ligar/desligar:"
				: "§7Toque num efeito pra ligar/desligar. Sao aplicados no nivel maximo enquanto o jogador estiver na area:"
		);

	EFEITOS_DISPONIVEIS.forEach((efeito) => {
		const ligado = efeitosAtivos.includes(efeito.id);
		form.button(`${efeito.nome}\n${ligado ? "§aAtivado" : "§cDesativado"}`, `textures/mob_effect/${efeito.id}`);
	});
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < EFEITOS_DISPONIVEIS.length) {
			alternarEfeitoArea(nome, EFEITOS_DISPONIVEIS[res.selection].id);
			abrirEfeitosAreaProtegida(player, nome);
			return;
		}
		abrirGerenciarAreaProtegida(player, nome);
	});
}

// ===== UTIL =====

function confirmarAcaoPainel(player, titulo, mensagem, onConfirmar, onCancelar) {
	const form = new MessageFormData().title(titulo).body(mensagem).button1("Sim, tenho certeza").button2("Cancelar");

	form.show(player).then((res) => {
		if (res.canceled || res.selection === 1) {
			if (onCancelar) onCancelar();
			return;
		}
		onConfirmar();
	});
}

// ===== ABA LIMPEZA DE LAG =====

function abrirMenuClearLag(player) {
	const config = getConfigClearLag();

	const form = new ActionFormData()
		.title("Limpeza de Lag")
		.body(
			"§7Sistema de Limpeza Automatica (Mobs + Itens + XP)\n\n" +
				`§fSistema Ativo: ${config.ativo ? "§aSim" : "§cNao"}\n` +
				`§fIntervalo: §e${config.intervaloSegundos}s\n` +
				`§fLimpezas ja feitas: §e${config.totalLimpezas} §7(${config.totalEntidades} entidades no total)\n` +
				`§fSom: §e${config.somAtivo ? config.som : "desligado"}\n\n` +
				`§fMonstros Hostis: ${config.limparMobsHostis ? "§a✔" : "§c✘"}  ` +
				`§fItens do Chao: ${config.limparItensChao ? "§a✔" : "§c✘"}  ` +
				`§fOrbes de XP: ${config.limparOrbesXp ? "§a✔" : "§c✘"}`
		)
		.button(config.ativo ? "Desativar Sistema\n§7[Para a limpeza automatica]" : "Ativar Sistema\n§7[Volta a limpar sozinho]", config.ativo ? ICONE_DESLIGAR : ICONE_LIGAR)
		.button("Limpar Agora", ICONE_CLEARLAG)
		.button("Configurar Sistema", ICONE_CONFIGURAR)
		.button("Categorias e Itens Protegidos", ICONE_APAGAR)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (res.selection === 0) {
			if (config.ativo) desativarClearLag(player);
			else ativarClearLag(player);
			abrirMenuClearLag(player);
			return;
		}
		if (res.selection === 1) {
			limparAgoraClearLag(player);
			abrirMenuClearLag(player);
			return;
		}
		if (res.selection === 2) {
			abrirConfigurarClearLag(player);
			return;
		}
		if (res.selection === 3) {
			abrirItensProtegidosClearLag(player);
			return;
		}
		abrirPainelDono(player);
	});
}

function abrirConfigurarClearLag(player) {
	const config = getConfigClearLag();

	const form = new ActionFormData()
		.title("Configurar Sistema")
		.body(`§fIntervalo atual: §e${config.intervaloSegundos}s §7(min 10, max 3000)\n§fSom atual: §e${config.som}`)
		.button("Mudar Tempo", "textures/items/clock")
		.button("Mudar Som", "textures/blocks/noteblock")
		.button("Editar Letra (cores)", "textures/items/name_tag")
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (res.selection === 0) {
			const modal = new ModalFormData()
				.title("Tempo")
				.textField("Tempo em segundos (padrao 120, max 3000)", "Ex: 120", { defaultValue: String(config.intervaloSegundos) })
				.toggle("Som Ativado", { defaultValue: config.somAtivo })
				.textField("Texto do Aviso", "Ex: O chao sera limpo em:", { defaultValue: config.textoAviso });
			modal
				.show(player)
				.then((r) => {
					if (r.canceled) {
						abrirConfigurarClearLag(player);
						return;
					}
					if (r.formValues[0]) definirIntervaloClearLag(r.formValues[0]);
					definirSomAtivoClearLag(r.formValues[1]);
					if (r.formValues[2]) definirTextoAvisoClearLag(r.formValues[2]);
					player.sendMessage("§aConfiguracao salva com sucesso!");
					abrirConfigurarClearLag(player);
				})
				.catch((erro) => console.warn(`Erro ao configurar tempo do clearlag: ${erro}`));
			return;
		}

		if (res.selection === 1) {
			const sons = getSonsClearLag();
			const modal = new ModalFormData()
				.title("Som")
				.dropdown("Som do Aviso", sons, { defaultValueIndex: Math.max(0, sons.indexOf(config.som)) });
			modal
				.show(player)
				.then((r) => {
					if (r.canceled) {
						abrirConfigurarClearLag(player);
						return;
					}
					definirSomClearLag(sons[r.formValues[0] ?? 0]);
					player.sendMessage("§aSom atualizado!");
					abrirConfigurarClearLag(player);
				})
				.catch((erro) => console.warn(`Erro ao mudar som do clearlag: ${erro}`));
			return;
		}

		if (res.selection === 2) {
			abrirEditarLetraClearLag(player);
			return;
		}

		abrirMenuClearLag(player);
	}).catch((erro) => {
		console.warn(`Erro ao abrir configuracao do clearlag: ${erro}`);
		player.sendMessage("§cDeu erro ao abrir a configuracao. Tente de novo.");
	});
}

function abrirEditarLetraClearLag(player) {
	const config = getConfigClearLag();

	const modal = new ModalFormData().title("Editar Letra");
	config.coresContagem.forEach((cor, i) => {
		modal.textField(`Numero ${10 - i}`, "Ex: §l§b", { defaultValue: cor });
	});
	modal.textField("Mensagem final (Chao foi limpo)", "Ex: §f", { defaultValue: config.corMensagemFinal });
	modal.textField("Aviso (⚠ Aviso do servidor)", "Ex: §c", { defaultValue: config.corAviso });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirConfigurarClearLag(player);
				return;
			}
			const novasCores = config.coresContagem.map((_, i) => res.formValues[i]);
			definirCoresContagemClearLag(novasCores, res.formValues[10], res.formValues[11]);
			player.sendMessage("§aCores atualizadas!");
			abrirConfigurarClearLag(player);
		})
		.catch((erro) => console.warn(`Erro ao editar cores do clearlag: ${erro}`));
}

const CATEGORIAS_ITENS_PROTEGIDOS = [
	{ id: "nomeados", nome: "Animais com tag (nomeados)" },
	{ id: "aldeao", nome: "Aldeao" },
	{ id: "netherite", nome: "Qualquer coisa de Netherite" },
	{ id: "diamante", nome: "Qualquer coisa de Diamante" },
	{ id: "pocoes", nome: "Qualquer Pocao" },
	{ id: "macas", nome: "Maca Dourada e Maca Encantada" },
	{ id: "mace", nome: "Clava (Mace)" },
	{ id: "shulker", nome: "Shulker Box (todas as cores)" },
	{ id: "elytra", nome: "Elitra e Foguetes" },
	{ id: "blocosFerroEsmeralda", nome: "Blocos de Ferro e de Esmeralda" }
];

function abrirItensProtegidosClearLag(player) {
	const config = getConfigClearLag();

	const modal = new ModalFormData()
		.title("Categorias e Itens Protegidos")
		.toggle("Limpar Monstros Hostis", { defaultValue: config.limparMobsHostis })
		.toggle("Limpar Itens do Chao", { defaultValue: config.limparItensChao })
		.toggle("Limpar Orbes de XP", { defaultValue: config.limparOrbesXp })
		.textField("Forcar limpar (IDs separados por virgula)", "Ex: totem,shulker", {
			defaultValue: config.itensExtras.join(", ")
		});
	CATEGORIAS_ITENS_PROTEGIDOS.forEach((c) => modal.toggle(c.nome, { defaultValue: config.itensProtegidos[c.id] }));

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuClearLag(player);
				return;
			}
			definirLimparMobsHostisClearLag(res.formValues[0]);
			definirLimparItensChaoClearLag(res.formValues[1]);
			definirLimparOrbesXpClearLag(res.formValues[2]);
			if (res.formValues[3]) definirItensExtrasClearLag(res.formValues[3]);
			CATEGORIAS_ITENS_PROTEGIDOS.forEach((c, i) => definirItemProtegidoToggleClearLag(c.id, res.formValues[i + 4]));
			player.sendMessage("§aCategorias e itens protegidos atualizados!");
			abrirMenuClearLag(player);
		})
		.catch((erro) => console.warn(`Erro ao configurar categorias e itens protegidos: ${erro}`));
}

// ===== ABA LIMITAR CPS =====

const ACOES_DETECCAO = [
	{ id: "avisar", nome: "Avisar" },
	{ id: "congelar", nome: "Congelar" },
	{ id: "expulsar", nome: "Expulsar" }
];

function abrirMenuAntiCheat(player) {
	const config = getConfigAntiCheat();

	const form = new ActionFormData()
		.title("Limitar CPS")
		.body(
			`§fStatus: ${config.ativo ? "§aAtivado" : "§cDesativado"}\n` +
				`§fLimite atual: §e${config.limiteCps} CPS §7(max 1000)\n` +
				`§fAcao: §e${config.acao}\n` +
				`§fDeteccoes: §e${config.deteccoes}`
		)
		.button(config.ativo ? "Desativar Sistema\n§7[Para de detectar]" : "Ativar Sistema\n§7[Volta a detectar]", config.ativo ? ICONE_DESLIGAR : ICONE_LIGAR)
		.button("Definir Limite de CPS", ICONE_CONFIGURAR)
		.button("Acao ao Detectar", "textures/items/diamond_sword")
		.button("Ver Detectados", ICONE_LISTA)
		.button("Limpar Logs", ICONE_APAGAR)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (res.selection === 0) {
			if (config.ativo) desativarAntiCheat(player);
			else ativarAntiCheat(player);
			abrirMenuAntiCheat(player);
			return;
		}
		if (res.selection === 1) {
			const modal = new ModalFormData()
				.title("Definir Limite de CPS")
				.textField("Limite (1 a 1000 cliques por segundo)", "Ex: 20", { defaultValue: String(config.limiteCps) });
			modal
				.show(player)
				.then((r) => {
					if (r.canceled) {
						abrirMenuAntiCheat(player);
						return;
					}
					definirLimiteAntiCheat(player, r.formValues[0]);
					abrirMenuAntiCheat(player);
				})
				.catch((erro) => console.warn(`Erro ao definir limite de cps: ${erro}`));
			return;
		}
		if (res.selection === 2) {
			const form2 = new ActionFormData().title("Acao ao Detectar").body(`Acao atual: §e${config.acao}`);
			ACOES_DETECCAO.forEach((a) => form2.button(a.nome, ICONE_CONFIGURAR));
			form2.button("Voltar", ICONE_VOLTAR);
			form2.show(player).then((r) => {
				if (r.canceled) return;
				if (r.selection < ACOES_DETECCAO.length) {
					definirAcaoAntiCheat(player, ACOES_DETECCAO[r.selection].id);
				}
				abrirMenuAntiCheat(player);
			});
			return;
		}
		if (res.selection === 3) {
			const form2 = new ActionFormData()
				.title("Jogadores Detectados")
				.body(
					config.log.length > 0
						? config.log.map((l) => `§e${l.nome} §7- §c${l.cps} cps §7- X:${l.x} Y:${l.y} Z:${l.z}`).join("\n")
						: "Nenhuma deteccao registrada ainda."
				)
				.button("Voltar", ICONE_VOLTAR);
			form2.show(player).then(() => abrirMenuAntiCheat(player));
			return;
		}
		if (res.selection === 4) {
			confirmarAcaoPainel(
				player,
				"Limpar Logs",
				"Tem certeza que deseja limpar todos os logs de deteccao?",
				() => {
					limparLogsAntiCheat(player);
					abrirMenuAntiCheat(player);
				},
				() => abrirMenuAntiCheat(player)
			);
			return;
		}
		abrirPainelDono(player);
	});
}

// ===== ABA RANK =====

function abrirMenuRank(player) {
	const totalRanks = Object.keys(getRanks()).length;

	const form = new ActionFormData()
		.title("Rank")
		.body(`§7${totalRanks} rank(s) criado(s).\nEscolha uma opcao:`)
		.button("Criar Rank\n§7[Novo rank do zero]", ICONE_CRIAR)
		.button("Dar Rank\n§7[Atribua a um jogador]", ICONE_LIGAR)
		.button("Editar Aparencia de Rank\n§7[Nome e tag]", ICONE_EDITAR)
		.button("Editar Permissao de Rank\n§7[Limites e cooldowns]", ICONE_EDITAR)
		.button("Remover Rank de Jogador\n§7[Tira de alguem]", "textures/items/paper")
		.button("Apagar Rank\n§7[Remove pra sempre]", ICONE_APAGAR)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) abrirCriarRank(player);
		if (res.selection === 1) abrirDarRankListaJogadores(player);
		if (res.selection === 2) abrirEditarAparenciaListaRanks(player);
		if (res.selection === 3) abrirEditarPermissoesListaRanks(player);
		if (res.selection === 4) abrirRemoverRankListaJogadores(player);
		if (res.selection === 5) abrirApagarRankLista(player);
		if (res.selection === 6) abrirPainelDono(player);
	});
}

// --- Criar Rank ---

function abrirCriarRank(player) {
	const modal = new ModalFormData()
		.title("Criar Rank")
		.textField("Nome do rank (fica salvo)", "Ex: VIP")
		.textField("Aparencia (fica em cima da cabeca)", "Ex: §l§6VIP§r");

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirMenuRank(player);
				return;
			}
			criarRank(player, res.formValues[0], res.formValues[1]);
			abrirMenuRank(player);
		})
		.catch((erro) => console.warn(`Erro ao criar rank: ${erro}`));
}

// --- Dar Rank ---

function abrirDarRankListaJogadores(player) {
	const jogadores = world.getAllPlayers();

	const form = new ActionFormData()
		.title("Dar Rank")
		.body(jogadores.length > 0 ? "Escolha um jogador." : "Nenhum jogador online.");
	jogadores.forEach((p) => form.button(p.name, ICONE_JOGADORES));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < jogadores.length) {
			abrirDarRankListaRanks(player, jogadores[res.selection]);
			return;
		}
		abrirMenuRank(player);
	});
}

function abrirDarRankListaRanks(player, alvo) {
	const ranks = getRanks();
	const ids = Object.keys(ranks).filter((id) => id !== "membro");

	const form = new ActionFormData()
		.title(`Dar Rank - ${alvo.name}`)
		.body(ids.length > 0 ? "Escolha o rank." : "Nenhum rank customizado criado ainda. Crie um primeiro.");
	ids.forEach((id) => form.button(ranks[id].tag, ICONE_RANK));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < ids.length) {
			darRank(player, alvo, ids[res.selection]);
			abrirMenuRank(player);
			return;
		}
		abrirDarRankListaJogadores(player);
	});
}

// --- Editar Aparencia de Rank ---

function abrirEditarAparenciaListaRanks(player) {
	const ranks = getRanks();
	const ids = Object.keys(ranks);

	const form = new ActionFormData().title("Editar Aparencia de Rank").body("Escolha um rank.");
	ids.forEach((id) => form.button(ranks[id].tag, ICONE_RANK));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < ids.length) {
			abrirEditarAparenciaRank(player, ids[res.selection]);
			return;
		}
		abrirMenuRank(player);
	});
}

function abrirEditarAparenciaRank(player, id) {
	const ranks = getRanks();
	const rank = ranks[id];
	if (!rank) {
		abrirMenuRank(player);
		return;
	}

	const modal = new ModalFormData()
		.title(`Editar: ${rank.tag}`)
		.textField("Nova aparencia (fica em cima da cabeca)", "Ex: §l§6VIP§r", { defaultValue: rank.tag })
		.toggle("Ocultar rank no chat/nametag?", { defaultValue: rank.oculto });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirEditarAparenciaListaRanks(player);
				return;
			}
			const novaAparencia = (res.formValues[0] ?? "").trim() || rank.tag;
			editarAparenciaRank(player, id, null, novaAparencia, !!res.formValues[1]);
			abrirEditarAparenciaListaRanks(player);
		})
		.catch((erro) => console.warn(`Erro ao editar aparencia do rank: ${erro}`));
}

// --- Editar Permissao de Rank ---

function abrirEditarPermissoesListaRanks(player) {
	const ranks = getRanks();
	const ids = Object.keys(ranks);

	const form = new ActionFormData().title("Editar Permissao de Rank").body("Escolha um rank.");
	ids.forEach((id) => form.button(ranks[id].tag, ICONE_RANK));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < ids.length) {
			abrirEditarPermissoesRank(player, ids[res.selection]);
			return;
		}
		abrirMenuRank(player);
	});
}

function abrirEditarPermissoesRank(player, id) {
	const ranks = getRanks();
	const rank = ranks[id];
	if (!rank) {
		abrirMenuRank(player);
		return;
	}
	const p = rank.permissoes;

	const modal = new ModalFormData()
		.title(`Permissoes: ${rank.nome}`)
		.textField("Limite de Homes", "Ex: 25", { defaultValue: String(p.limiteHomes) })
		.textField("Custo Home (moedas)", "Ex: 0", { defaultValue: String(p.custoHome) })
		.textField("Custo Warp (moedas)", "Ex: 0", { defaultValue: String(p.custoWarp) })
		.textField("Custo Back (moedas)", "Ex: 0", { defaultValue: String(p.custoBack) })
		.textField("Cooldown Chat (seg)", "Ex: 0", { defaultValue: String(p.cooldownChat) })
		.textField("Cooldown Home (seg)", "Ex: 3", { defaultValue: String(p.cooldownHome) })
		.textField("Cooldown Warp (seg)", "Ex: 3", { defaultValue: String(p.cooldownWarp) })
		.textField("Cooldown Warp Clan (seg)", "Ex: 3", { defaultValue: String(p.cooldownWarpClan) })
		.textField("Cooldown Back (seg)", "Ex: 0", { defaultValue: String(p.cooldownBack) })
		.textField("Cooldown TPA ate ele (seg)", "Ex: 3", { defaultValue: String(p.cooldownTpaAteEle) })
		.textField("Cooldown TPA ate mim (seg)", "Ex: 3", { defaultValue: String(p.cooldownTpaAteMim) })
		.textField("Limite de Saldo", "Ex: 1000000", { defaultValue: String(p.limiteSaldo) })
		.textField("Limite de Abates", "Ex: 1000", { defaultValue: String(p.limiteAbates) })
		.toggle("Teleporte Instantaneo\n§7[Pula a contagem de 3s]", { defaultValue: !!p.teleporteInstantaneo });

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) {
				abrirEditarPermissoesListaRanks(player);
				return;
			}

			const numero = (valor, atual) => {
				if (valor === undefined || valor === null || valor === "") return atual;
				const n = Number(valor);
				return Number.isFinite(n) && n >= 0 ? Math.floor(n) : atual;
			};

			editarPermissoes(player, id, {
				limiteHomes: numero(res.formValues[0], p.limiteHomes),
				custoHome: numero(res.formValues[1], p.custoHome),
				custoWarp: numero(res.formValues[2], p.custoWarp),
				custoBack: numero(res.formValues[3], p.custoBack),
				cooldownChat: numero(res.formValues[4], p.cooldownChat),
				cooldownHome: numero(res.formValues[5], p.cooldownHome),
				cooldownWarp: numero(res.formValues[6], p.cooldownWarp),
				cooldownWarpClan: numero(res.formValues[7], p.cooldownWarpClan),
				cooldownBack: numero(res.formValues[8], p.cooldownBack),
				cooldownTpaAteEle: numero(res.formValues[9], p.cooldownTpaAteEle),
				cooldownTpaAteMim: numero(res.formValues[10], p.cooldownTpaAteMim),
				limiteSaldo: numero(res.formValues[11], p.limiteSaldo),
				limiteAbates: numero(res.formValues[12], p.limiteAbates),
				teleporteInstantaneo: !!res.formValues[13]
			});
			abrirEditarPermissoesListaRanks(player);
		})
		.catch((erro) => console.warn(`Erro ao editar permissoes: ${erro}`));
}

// --- Remover Rank de Jogador ---

function abrirRemoverRankListaJogadores(player) {
	const jogadores = world.getAllPlayers();

	const form = new ActionFormData()
		.title("Remover Rank de Jogador")
		.body(jogadores.length > 0 ? "Escolha um jogador." : "Nenhum jogador online.");
	jogadores.forEach((p) => form.button(p.name, ICONE_JOGADORES));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < jogadores.length) {
			abrirRemoverRankListaRanksDoJogador(player, jogadores[res.selection]);
			return;
		}
		abrirMenuRank(player);
	});
}

function abrirRemoverRankListaRanksDoJogador(player, alvo) {
	const ranksDoJogador = getRanksDoJogadorComNome(alvo);

	const form = new ActionFormData()
		.title(`Remover Rank - ${alvo.name}`)
		.body(ranksDoJogador.length > 0 ? "Escolha o rank pra remover." : `${alvo.name} nao tem nenhum rank customizado.`);
	ranksDoJogador.forEach((r) => form.button(r.tag, ICONE_RANK));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < ranksDoJogador.length) {
			removerRankDoJogador(player, alvo, ranksDoJogador[res.selection].id);
			abrirMenuRank(player);
			return;
		}
		abrirRemoverRankListaJogadores(player);
	});
}

// --- Apagar Rank ---

function abrirApagarRankLista(player) {
	const ranks = getRanks();
	const ids = Object.keys(ranks).filter((id) => id !== "membro");

	const form = new ActionFormData()
		.title("Apagar Rank")
		.body(ids.length > 0 ? "Escolha o rank pra apagar." : "Nenhum rank customizado criado ainda.");
	ids.forEach((id) => form.button(ranks[id].tag, ICONE_RANK));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < ids.length) {
			const id = ids[res.selection];
			confirmarAcaoPainel(
				player,
				"Apagar Rank",
				`Tem certeza que quer apagar o rank ${ranks[id].nome}? Isso remove ele de quem tiver.`,
				() => {
					apagarRank(player, id);
					abrirMenuRank(player);
				},
				() => abrirApagarRankLista(player)
			);
			return;
		}
		abrirMenuRank(player);
	});
}
