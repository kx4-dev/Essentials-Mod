import { ActionFormData } from "@minecraft/server-ui";
import { getData, setData } from "./database.js";

// ===== REGRAS (comando !regras) =====
const KEY_REGRAS = "re:regras";

function regrasPadrao() {
	return "§eO dono do servidor ainda nao definiu as regras. Use o Painel do Dono para configurar.";
}

export function getRegras() {
	return getData(KEY_REGRAS, regrasPadrao());
}

export function definirRegras(texto) {
	const textoLimpo = (texto ?? "").trim();
	setData(KEY_REGRAS, textoLimpo !== "" ? textoLimpo : regrasPadrao());
	return true;
}

// ===== NOME DO MENU PRINCIPAL =====
const KEY_NOME_MENU = "re:nome_menu";

function nomeMenuPadrao() {
	return "Realm Essentials";
}

export function getNomeMenu() {
	return getData(KEY_NOME_MENU, nomeMenuPadrao());
}

export function definirNomeMenu(texto) {
	const textoLimpo = (texto ?? "").trim();
	setData(KEY_NOME_MENU, textoLimpo !== "" ? textoLimpo : nomeMenuPadrao());
	return true;
}

// ===== MENSAGEM DE RE-ENTRADA (2a vez em diante) =====
const KEY_MENSAGEM_REENTRADA = "re:mensagem_reentrada";

function mensagemReentradaPadrao() {
	return "§eUse §a!ajudar §epara saber os comandos do Realm Essentials.";
}

export function getMensagemReentrada() {
	return getData(KEY_MENSAGEM_REENTRADA, mensagemReentradaPadrao());
}

export function definirMensagemReentrada(texto) {
	const textoLimpo = (texto ?? "").trim();
	setData(KEY_MENSAGEM_REENTRADA, textoLimpo !== "" ? textoLimpo : mensagemReentradaPadrao());
	return true;
}

// ===== LIGAR/DESLIGAR O FORMULARIO DE BOAS-VINDAS =====
const KEY_BOASVINDAS_ATIVO = "re:boasvindas_ativo";

export function getBoasVindasAtivo() {
	return getData(KEY_BOASVINDAS_ATIVO, true);
}

export function definirBoasVindasAtivo(valor) {
	setData(KEY_BOASVINDAS_ATIVO, !!valor);
	return true;
}

// ===== FORMULARIO DE BOAS-VINDAS (1a entrada) =====
const KEY_TEXTO_BOASVINDAS = "re:boasvindas_texto";

function textoBoasVindasPadrao() {
	return "Seja bem-vindo (a) antes de comecar veja os comandos do addon Realm Essentials";
}

export function getTextoBoasVindas() {
	return getData(KEY_TEXTO_BOASVINDAS, textoBoasVindasPadrao());
}

export function definirTextoBoasVindas(texto) {
	const textoLimpo = (texto ?? "").trim();
	setData(KEY_TEXTO_BOASVINDAS, textoLimpo !== "" ? textoLimpo : textoBoasVindasPadrao());
	return true;
}

// Numero de entrada (1o, 2o, 3o...) - guardado por jogador pra sempre ser o
// mesmo numero, mesmo se ele sair e voltar depois. So retorna um numero na
// PRIMEIRA vez que o jogador entra no servidor; nas proximas vezes retorna
// null (main.js usa isso pra saber se mostra o formulario ou so o texto).
const KEY_NUMEROS_ENTRADA = "re:numeros_entrada";

export function registrarEntradaEObterNumero(player) {
	const numeros = getData(KEY_NUMEROS_ENTRADA, {});
	if (numeros[player.id]) return null;

	const proximo = Object.keys(numeros).length + 1;
	numeros[player.id] = proximo;
	setData(KEY_NUMEROS_ENTRADA, numeros);
	return proximo;
}

// Formulario mostrado so na primeira entrada do jogador no servidor. O
// texto de saudacao e editavel pelo dono (Painel > Configuracao > Regras e
// Boas-Vindas); a lista de comandos e o numero de entrada sao montados na
// hora, sempre atualizados.
export function abrirFormularioBoasVindas(player, numero, textoComandos) {
	const form = new ActionFormData()
		.title("Bem-vindo!")
		.body(
			`§f${getTextoBoasVindas()}\n\n` +
				`§eVoce foi o §f${numero}º§e jogador a entrar no servidor!\n\n` +
				`${textoComandos}`
		)
		.button("Fechar");

	form.show(player).catch((erro) => console.warn(`Erro ao mostrar formulario de boas-vindas: ${erro}`));
}
