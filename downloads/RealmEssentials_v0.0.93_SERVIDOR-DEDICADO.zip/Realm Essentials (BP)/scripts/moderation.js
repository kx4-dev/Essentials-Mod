import { world, system } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { logar, escapar } from "./discordLogs.js";

const CHAVE_BANS = "re:bans";
const CHAVE_MUTES = "re:mutes";
const TAG_CONGELADO = "re_congelado";
const DURACAO_CONGELAMENTO_TICKS = 100; // 5 segundos - congelamento nao e mais permanente

// ===== BANIMENTOS =====
// Guardado por nome (em minusculo) pra funcionar mesmo com o jogador offline.

function getBansRaw() {
	return getData(CHAVE_BANS, {});
}

function saveBansRaw(bans) {
	setData(CHAVE_BANS, bans);
}

export function getBans() {
	return getBansRaw();
}

export function getBanInfo(nome) {
	const bans = getBansRaw();
	return bans[nome.toLowerCase()] ?? null;
}

export function banirJogador(alvo, motivo, responsavel) {
	motivo = (motivo ?? "").trim() || "Nao informado";

	const bans = getBansRaw();
	bans[alvo.name.toLowerCase()] = {
		nome: alvo.name,
		motivo,
		por: responsavel?.name ?? "Sistema",
		data: new Date().toISOString()
	};
	saveBansRaw(bans);

	logar("moderacao", "Jogador banido", `**${escapar(alvo.name)}** foi banido.`, [
		{ nome: "Por", valor: responsavel?.name ?? "Sistema" },
		{ nome: "Motivo", valor: motivo, inline: false }
	]);

	// Jogador offline (banido só pelo nome) não tem o que expulsar.
	if (typeof alvo.runCommandAsync !== "function") return;

	// runCommandAsync em vez de runCommand: o sincrono trava a thread do jogo
	// ate o comando terminar, o que da uma travadinha perceptivel no servidor
	// inteiro. O assincrono roda sem bloquear.
	alvo.runCommandAsync(`kick "${alvo.name}" §cVoce foi banido.\n§fMotivo: §e${motivo}`).catch((erro) => {
		console.warn(`Erro ao expulsar jogador banido: ${erro}`);
	});
}

export function desbanirJogador(nome) {
	const bans = getBansRaw();
	const chave = nome.toLowerCase();
	if (!bans[chave]) return false;
	delete bans[chave];
	saveBansRaw(bans);
	logar("moderacao", "Jogador desbanido", `**${escapar(nome)}** foi desbanido.`);
	return true;
}

// Chamado quando um jogador entra no mundo. Se estiver banido, deixa ele
// no servidor por 3 segundos e so entao expulsa - kickar bem na hora que
// ele spawna e cedo demais, o cliente ainda nao "assentou" direito e o
// comando pode nao pegar (ele fica preso, entrando e nunca sendo
// realmente kickado). Isso e um unico agendamento por entrada, nao um
// loop rodando toda hora, entao nao pesa no tps do servidor.
export function checarBanNaEntrada(player) {
	const infoInicial = getBanInfo(player.name);
	if (!infoInicial) return;

	system.runTimeout(() => {
		const info = getBanInfo(player.name);
		if (!info) return; // foi desbanido nesses 3 segundos

		player.runCommandAsync(`kick "${player.name}" §cVoce esta banido deste servidor.\n§fMotivo: §e${info.motivo}`).catch((erro) => {
			console.warn(`Erro ao expulsar jogador banido na entrada: ${erro}`);
		});
	}, 60);
}

// ===== KICK =====

export function kickJogador(alvo, motivo, responsavel) {
	motivo = (motivo ?? "").trim() || "Não informado";
	logar("moderacao", "Jogador expulso", `**${escapar(alvo.name)}** foi expulso.`, [
		{ nome: "Por", valor: responsavel?.name ?? "Sistema" },
		{ nome: "Motivo", valor: motivo, inline: false }
	]);
	alvo.runCommandAsync(`kick "${alvo.name}" §cVoce foi expulso do servidor.\n§fMotivo: §e${motivo}`).catch((erro) => {
		console.warn(`Erro ao expulsar jogador: ${erro}`);
	});
	return true;
}

// ===== MUTE =====

function getMutesRaw() {
	return getData(CHAVE_MUTES, {});
}

function saveMutesRaw(mutes) {
	setData(CHAVE_MUTES, mutes);
}

export function getMutes() {
	return getMutesRaw();
}

export function isMutado(nome) {
	const mutes = getMutesRaw();
	return Boolean(mutes[nome.toLowerCase()]);
}

export function mutarJogador(alvo, motivo, responsavel) {
	motivo = (motivo ?? "").trim() || "Nao informado";
	const mutes = getMutesRaw();
	mutes[alvo.name.toLowerCase()] = {
		nome: alvo.name,
		motivo,
		por: responsavel?.name ?? "Sistema",
		data: new Date().toISOString()
	};
	saveMutesRaw(mutes);

	logar("moderacao", "Jogador mutado", `**${escapar(alvo.name)}** foi mutado.`, [
		{ nome: "Por", valor: responsavel?.name ?? "Sistema" },
		{ nome: "Motivo", valor: motivo, inline: false }
	]);

	try {
		alvo.sendMessage(`§cVoce foi mutado. §fMotivo: §e${motivo}`);
	} catch (erro) {
		console.warn(`Erro ao avisar jogador mutado: ${erro}`);
	}
}

export function desmutarJogador(nome) {
	const mutes = getMutesRaw();
	const chave = nome.toLowerCase();
	if (!mutes[chave]) return false;
	delete mutes[chave];
	saveMutesRaw(mutes);
	logar("moderacao", "Jogador desmutado", `**${escapar(nome)}** foi desmutado.`);

	const online = world.getAllPlayers().find((p) => p.name.toLowerCase() === chave);
	if (online) {
		try {
			online.sendMessage("§aVoce foi desmutado e ja pode falar no chat novamente.");
		} catch (erro) {
			console.warn(`Erro ao avisar jogador desmutado: ${erro}`);
		}
	}
	return true;
}

// ===== CONGELAR =====

function chaveFreezePos(player) {
	return `re:freezepos:${player.id}`;
}

export function isCongelado(player) {
	return player.hasTag(TAG_CONGELADO);
}

// So da pra saber quem esta congelado entre quem esta online (o congelamento
// e por tag no jogador, nao tem como consultar offline).
export function getCongeladosOnline() {
	return world.getAllPlayers().filter((p) => p.hasTag(TAG_CONGELADO));
}

// Congela o jogador por 5 segundos (nao e mais permanente). Depois desse
// tempo ele e descongelado automaticamente sozinho.
export function congelarJogador(player) {
	if (player.hasTag(TAG_CONGELADO)) return;
	player.addTag(TAG_CONGELADO);
	setData(chaveFreezePos(player), {
		x: player.location.x,
		y: player.location.y,
		z: player.location.z,
		dimension: player.dimension.id
	});
	player.addEffect("blindness", DURACAO_CONGELAMENTO_TICKS, { amplifier: 0, showParticles: false });

	system.runTimeout(() => {
		try {
			descongelarJogador(player);
		} catch (erro) {
			console.warn(`Erro ao descongelar automaticamente: ${erro}`);
		}
	}, DURACAO_CONGELAMENTO_TICKS);
}

export function descongelarJogador(player) {
	if (!player.hasTag(TAG_CONGELADO)) return;
	player.removeTag(TAG_CONGELADO);
	try {
		player.removeEffect("blindness");
	} catch (erro) {
		console.warn(`Erro ao remover efeito de congelamento: ${erro}`);
	}
}

// Roda a cada tick (chamado pelo main.js): mantem os jogadores congelados
// travados no lugar, cegos e com o aviso na tela.
export function aplicarCongelamentoTick() {
	for (const player of world.getAllPlayers()) {
		if (!player.hasTag(TAG_CONGELADO)) continue;

		const pos = getData(chaveFreezePos(player), null);
		if (pos) {
			const dimensionAtual = player.dimension.id;
			if (dimensionAtual === pos.dimension) {
				const dx = player.location.x - pos.x;
				const dy = player.location.y - pos.y;
				const dz = player.location.z - pos.z;
				if (Math.abs(dx) > 0.05 || Math.abs(dy) > 0.05 || Math.abs(dz) > 0.05) {
					try {
						player.teleport({ x: pos.x, y: pos.y, z: pos.z }, { dimension: player.dimension });
					} catch (erro) {
						console.warn(`Erro ao travar jogador congelado: ${erro}`);
					}
				}
			}
		}

		try {
			player.addEffect("blindness", 200, { amplifier: 0, showParticles: false });
			player.onScreenDisplay.setActionBar("§b§lVOCE ESTA CONGELADO");
		} catch (erro) {
			console.warn(`Erro ao aplicar efeitos de congelamento: ${erro}`);
		}
	}
}

// Bloqueia o chat de quem esta mutado. Retorna true se a mensagem foi
// bloqueada (chamado pelo main.js dentro do beforeEvents.chatSend).
export function bloquearSeMutado(player) {
	if (!isMutado(player.name)) return false;
	const dados = getMutesRaw()[player.name.toLowerCase()];
	player.sendMessage(`§cVoce esta mutado e nao pode falar no chat. §fMotivo: §e${dados?.motivo ?? "Nao informado"}`);
	return true;
}
