import { getData, setData } from "./database.js";

const KEY = "re:ranks";
const KEY_JOGADOR = "re:rank_jogador"; // playerId -> array de rank ids
const RANK_PADRAO_ID = "membro";
const LIMITE_RANKS_POR_JOGADOR = 15;

function permissoesPadrao() {
	return {
		limiteHomes: 25,
		custoHome: 0,
		custoWarp: 0,
		custoBack: 0,
		cooldownChat: 0,
		cooldownHome: 3,
		cooldownWarp: 3,
		cooldownWarpClan: 3,
		cooldownBack: 0,
		cooldownTpaAteEle: 3,
		cooldownTpaAteMim: 3,
		limiteSaldo: 1000000,
		limiteAbates: 1000,
		teleporteInstantaneo: false
	};
}

function ranksIniciais() {
	return {
		[RANK_PADRAO_ID]: { nome: "Membro", tag: "§l§5MEM§dBRO§r", ordem: 999, oculto: false, permissoes: permissoesPadrao() }
	};
}

export function getRanks() {
	const ranks = getData(KEY, null);
	if (!ranks || Object.keys(ranks).length === 0) {
		const iniciais = ranksIniciais();
		setData(KEY, iniciais);
		return iniciais;
	}
	for (const id of Object.keys(ranks)) {
		if (!ranks[id].permissoes) ranks[id].permissoes = permissoesPadrao();
		if (ranks[id].oculto === undefined) ranks[id].oculto = false;
	}
	return ranks;
}

function saveRanks(ranks) {
	setData(KEY, ranks);
}

function idUnico(nome, ranks) {
	let base = nome.toLowerCase().replace(/[^a-z0-9]/g, "");
	if (!base) base = "rank";
	let id = base;
	let contador = 1;
	while (ranks[id]) {
		id = `${base}${contador}`;
		contador++;
	}
	return id;
}

// ===== CRIAR / DELETAR / EDITAR RANK =====

export function criarRank(player, nome, aparencia) {
	nome = (nome ?? "").trim();
	aparencia = (aparencia ?? "").trim();
	if (!nome) {
		player.sendMessage("§cDigite um nome valido para o rank.");
		return;
	}
	if (nome.length > 25) {
		player.sendMessage("§cO nome do rank deve ter no maximo 25 letras.");
		return;
	}
	if (!aparencia) aparencia = `§l§7${nome.toUpperCase()}§r`;

	const ranks = getRanks();
	if (Object.values(ranks).some((r) => r.nome.toLowerCase() === nome.toLowerCase())) {
		player.sendMessage(`§cJa existe um rank chamado ${nome}.`);
		return;
	}

	const id = idUnico(nome, ranks);
	// Todo rank novo comeca com as mesmas permissoes/cooldowns configurados
	// no rank Membro (e nao com o padrao fixo), pra ficar igual ao que o
	// dono ja definiu como base do servidor.
	const permissoesBase = { ...(ranks[RANK_PADRAO_ID]?.permissoes ?? permissoesPadrao()) };
	ranks[id] = { nome, tag: aparencia, ordem: Object.keys(ranks).length, oculto: false, permissoes: permissoesBase };
	saveRanks(ranks);
	player.sendMessage(`§aRank §e${nome}§a criado! Va em "Dar Rank" pra atribuir ele a um jogador.`);
}

export function apagarRank(player, id) {
	if (id === RANK_PADRAO_ID) {
		player.sendMessage("§cO rank Membro nao pode ser apagado.");
		return;
	}

	const ranks = getRanks();
	if (!ranks[id]) {
		player.sendMessage("§cEsse rank nao existe mais.");
		return;
	}
	const nomeApagado = ranks[id].nome;
	delete ranks[id];
	saveRanks(ranks);

	// Remove esse rank de todo mundo que tinha ele.
	const mapa = getData(KEY_JOGADOR, {});
	for (const jogadorId of Object.keys(mapa)) {
		mapa[jogadorId] = (mapa[jogadorId] ?? []).filter((rid) => rid !== id);
	}
	setData(KEY_JOGADOR, mapa);

	player.sendMessage(`§aRank §e${nomeApagado}§a apagado.`);
}

export function editarAparenciaRank(player, id, novoNome, novaAparencia, oculto) {
	const ranks = getRanks();
	const rank = ranks[id];
	if (!rank) {
		player.sendMessage("§cEsse rank nao existe mais.");
		return;
	}
	if (novoNome) rank.nome = novoNome;
	if (novaAparencia) rank.tag = novaAparencia;
	if (oculto !== undefined) rank.oculto = oculto;
	saveRanks(ranks);
	player.sendMessage(`§aAparencia de §e${rank.nome}§a atualizada! Ja vale pra todo mundo que tem esse rank.`);
}

export function editarPermissoes(player, id, novasPermissoes) {
	const ranks = getRanks();
	const rank = ranks[id];
	if (!rank) {
		player.sendMessage("§cEsse rank nao existe mais.");
		return;
	}
	rank.permissoes = { ...rank.permissoes, ...novasPermissoes };
	saveRanks(ranks);
	player.sendMessage(`§aPermissoes de §e${rank.nome}§a atualizadas!`);
}

export function encontrarIdPorNome(nome) {
	const ranks = getRanks();
	const nomeMinusculo = (nome ?? "").trim().toLowerCase();
	return Object.keys(ranks).find((id) => ranks[id].nome.toLowerCase() === nomeMinusculo) ?? null;
}

// ===== DAR / REMOVER RANK DE JOGADOR =====

function getRanksIdsDoJogador(player) {
	const mapa = getData(KEY_JOGADOR, {});
	return mapa[player.id] ?? [];
}

export function darRank(player, alvo, id) {
	const ranks = getRanks();
	if (!ranks[id]) {
		player.sendMessage("§cEsse rank nao existe.");
		return;
	}

	const mapa = getData(KEY_JOGADOR, {});
	const atuais = mapa[alvo.id] ?? [];

	if (atuais.includes(id)) {
		player.sendMessage(`§e${alvo.name}§c ja tem esse rank.`);
		return;
	}
	if (atuais.length >= LIMITE_RANKS_POR_JOGADOR) {
		player.sendMessage(`§c${alvo.name} ja atingiu o limite de §e${LIMITE_RANKS_POR_JOGADOR}§c ranks.`);
		return;
	}

	mapa[alvo.id] = [...atuais, id];
	setData(KEY_JOGADOR, mapa);

	player.sendMessage(`§a${alvo.name} agora tem o rank §e${ranks[id].nome}§a.`);
	try {
		alvo.sendMessage(`§aVoce recebeu o rank §e${ranks[id].nome}§a!`);
	} catch (erro) {
		console.warn(`Erro ao avisar jogador sobre novo rank: ${erro}`);
	}
}

export function removerRankDoJogador(player, alvo, id) {
	const mapa = getData(KEY_JOGADOR, {});
	const atuais = mapa[alvo.id] ?? [];

	if (!atuais.includes(id)) {
		player.sendMessage(`§e${alvo.name}§c nao tem esse rank.`);
		return;
	}

	mapa[alvo.id] = atuais.filter((rid) => rid !== id);
	setData(KEY_JOGADOR, mapa);
	player.sendMessage(`§aRank removido de §e${alvo.name}§a.`);
}

export function getRanksDoJogadorComNome(player) {
	const ranks = getRanks();
	return getRanksIdsDoJogador(player)
		.filter((id) => ranks[id])
		.map((id) => ({ id, ...ranks[id] }));
}

// ===== EXIBICAO =====

// Envolve a tag do rank com colchetes num cinza escuro suave (nao preto
// puro, fica com uma cara mais leve/transparente), tipo uma "borda":
// [Membro]. A cor do texto de dentro continua sendo a definida no rank.
function comBorda(tag) {
	if (!tag) return tag;
	return `§8[§r§l${tag}§r§8]§r`;
}

export function getRankDisplay(player) {
	const ranks = getRanks();
	const idsDoJogador = getRanksIdsDoJogador(player).filter((id) => ranks[id] && !ranks[id].oculto);

	if (idsDoJogador.length === 0) {
		return ranks[RANK_PADRAO_ID].oculto ? "" : comBorda(ranks[RANK_PADRAO_ID].tag);
	}

	// Tags encostadas uma na outra, sem espaco entre elas: [Rank1][Rank2].
	return idsDoJogador
		.sort((a, b) => ranks[a].ordem - ranks[b].ordem)
		.map((id) => comBorda(ranks[id].tag))
		.join("");
}

// Ainda no rank inicial (nenhum rank customizado atribuido)?
export function ehRankPadrao(player) {
	return getRanksIdsDoJogador(player).length === 0;
}

// Combina as permissoes de todos os ranks do jogador: pega sempre o valor
// mais vantajoso (menor custo/cooldown, maior limite).
export function getPermissoes(player) {
	const ranks = getRanks();
	const idsDoJogador = getRanksIdsDoJogador(player).filter((id) => ranks[id]);

	if (idsDoJogador.length === 0) return ranks[RANK_PADRAO_ID].permissoes;

	const MAIOR_MELHOR = ["limiteHomes", "limiteSaldo", "limiteAbates", "teleporteInstantaneo"];
	const resultado = { ...ranks[idsDoJogador[0]].permissoes };

	for (const id of idsDoJogador.slice(1)) {
		const p = ranks[id].permissoes;
		for (const chave of Object.keys(resultado)) {
			if (MAIOR_MELHOR.includes(chave)) {
				resultado[chave] = Math.max(resultado[chave], p[chave]);
			} else {
				resultado[chave] = Math.min(resultado[chave], p[chave]);
			}
		}
	}

	return resultado;
}
