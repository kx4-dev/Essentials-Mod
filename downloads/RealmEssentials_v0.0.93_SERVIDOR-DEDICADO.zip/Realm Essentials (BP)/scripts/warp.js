import { world } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { teleportarComContagem } from "./teleportCountdown.js";
import { getPermissoes } from "./rank.js";
import { emCooldown } from "./cooldown.js";
import { cobrarCusto } from "./money.js";

import { ehDono } from "./permissoes.js";
const KEY = "re:warps";
const ICONE_PADRAO = "textures/icons/warps";

// Comandos que ja sao usados pelo addon - o dono nao pode registrar uma
// warp com um desses nomes, senao ia bagunçar tudo.
const COMANDOS_RESERVADOS = new Set([
	"ajudar", "banir", "castigar", "congelar", "credito", "creditos", "criar", "deletar",
	"descongelar", "desmutar", "editar", "expulsar", "home", "loja", "menu", "mutar",
	"rank", "reportar", "rtp", "sair", "servidor", "soltar", "teleportar", "teleporte",
	"voltar", "warp",
	"adminpanel", "painel", "admin", "saldo", "pagar", "desbanir", "anunciar", "logs"
]);

// Icones disponiveis na hora de criar uma warp. Os "textures/icons/..."
// sao icones proprios do addon; os "textures/items/..." sao icones
// vanilla do Minecraft (sempre disponiveis, sem precisar adicionar nada
// no resource pack).
export const ICONES_WARP = [
	{ nome: "Bandeira (padrao)", icone: "textures/icons/warps" },
	{ nome: "Casa", icone: "textures/icons/home" },
	{ nome: "Loja", icone: "textures/icons/shop" },
	{ nome: "Bau", icone: "textures/icons/enderchest" },
	{ nome: "Bussola", icone: "textures/items/compass" },
	{ nome: "Relogio", icone: "textures/items/clock" },
	{ nome: "Diamante", icone: "textures/items/diamond" },
	{ nome: "Esmeralda", icone: "textures/items/emerald" },
	{ nome: "Lingote de Ouro", icone: "textures/items/gold_ingot" },
	{ nome: "Lingote de Ferro", icone: "textures/items/iron_ingot" },
	{ nome: "Estrela do Nether", icone: "textures/items/nether_star" },
	{ nome: "Perola do Ender", icone: "textures/items/ender_pearl" },
	{ nome: "Olho do Ender", icone: "textures/items/ender_eye" },
	{ nome: "Redstone", icone: "textures/items/redstone_dust" },
	{ nome: "Lapis", icone: "textures/items/lapis_lazuli" },
	{ nome: "Maca", icone: "textures/items/apple" },
	{ nome: "Arco", icone: "textures/items/bow" },
	{ nome: "Escudo", icone: "textures/items/shield" },
	{ nome: "Placa com nome", icone: "textures/items/name_tag" },
	{ nome: "Mapa", icone: "textures/items/map" }
];

export function getWarps() {
	return getData(KEY, {});
}

function saveWarps(warps) {
	setData(KEY, warps);
}

// Só o dono (ver permissoes.js) pode criar, renomear ou apagar warps.
// Todo mundo pode usar (teleportarWarp).
function normalizarComando(comando) {
	return (comando ?? "")
		.trim()
		.toLowerCase()
		.replace(/^!/, "")
		.replace(/\s+/g, "");
}

// Acha o nome da warp que tem esse comando registrado (ex: "spawn" ->
// nome da warp que tiver comando "spawn"). Usado quando o jogador digita
// "!spawn" no chat.
export function encontrarWarpPorComando(comando) {
	const warps = getWarps();
	const entrada = Object.entries(warps).find(([, w]) => w.comando === comando);
	return entrada ? entrada[0] : null;
}

export function criarWarp(player, nome, comando, icone) {
	if (!ehDono(player)) {
		player.sendMessage("§cApenas o dono pode criar warps.");
		return;
	}

	nome = (nome ?? "").trim();
	if (!nome) {
		player.sendMessage("§cDigite um nome valido para o warp.");
		return;
	}

	const warps = getWarps();
	const comandoNormalizado = normalizarComando(comando);

	if (comandoNormalizado) {
		if (COMANDOS_RESERVADOS.has(comandoNormalizado)) {
			player.sendMessage(`§cO comando §e!${comandoNormalizado}§c ja e usado pelo addon, escolha outro.`);
			return;
		}
		const donoDoComando = encontrarWarpPorComando(comandoNormalizado);
		if (donoDoComando && donoDoComando !== nome) {
			player.sendMessage(`§cO comando §e!${comandoNormalizado}§c ja esta sendo usado pela warp §e${donoDoComando}§c.`);
			return;
		}
	}

	warps[nome] = {
		x: Math.floor(player.location.x),
		y: Math.floor(player.location.y),
		z: Math.floor(player.location.z),
		dimension: player.dimension.id,
		comando: comandoNormalizado || null,
		icone: icone || ICONE_PADRAO
	};
	saveWarps(warps);

	const avisoComando = comandoNormalizado ? ` Use §e!${comandoNormalizado}§a pra teleportar direto.` : "";
	player.sendMessage(`§aWarp §e${nome}§a criado com sucesso!${avisoComando}`);
}

export function removerWarp(player, nome) {
	if (!ehDono(player)) {
		player.sendMessage("§cApenas o dono pode remover warps.");
		return;
	}

	const warps = getWarps();
	if (!warps[nome]) {
		player.sendMessage(`§cNao existe um warp chamado §e${nome}§c.`);
		return;
	}

	delete warps[nome];
	saveWarps(warps);
	player.sendMessage(`§aWarp §e${nome}§a removido com sucesso!`);
}

export function renomearWarp(player, nomeAntigo, nomeNovo) {
	if (!ehDono(player)) {
		player.sendMessage("§cApenas o dono pode renomear warps.");
		return;
	}

	const warps = getWarps();
	if (!warps[nomeAntigo]) {
		player.sendMessage(`§cNao existe um warp chamado §e${nomeAntigo}§c.`);
		return;
	}

	nomeNovo = (nomeNovo ?? "").trim();
	if (!nomeNovo) {
		player.sendMessage("§cDigite um nome valido.");
		return;
	}

	if (nomeNovo !== nomeAntigo && warps[nomeNovo]) {
		player.sendMessage(`§cJa existe uma warp chamada §e${nomeNovo}§c.`);
		return;
	}

	warps[nomeNovo] = warps[nomeAntigo];
	if (nomeNovo !== nomeAntigo) delete warps[nomeAntigo];
	saveWarps(warps);
	player.sendMessage(`§aWarp renomeada para §e${nomeNovo}§a.`);
}

export function teleportarWarp(player, nome) {
	const warps = getWarps();
	const warp = warps[nome];
	if (!warp) {
		player.sendMessage(`§cNao existe um warp chamado §e${nome}§c.`);
		return;
	}

	const permissoes = getPermissoes(player);
	if (emCooldown(player, "warp", permissoes.cooldownWarp)) return;
	if (!cobrarCusto(player, permissoes.custoWarp)) return;

	teleportarComContagem(player, () => {
		const dimension = world.getDimension(warp.dimension.replace("minecraft:", ""));
		player.teleport({ x: warp.x, y: warp.y, z: warp.z }, { dimension });
		player.sendMessage(`§aVoce foi teleportado para o warp §e${nome}§a.`);
	});
}

// Mostra a lista de warps existentes e o comando de cada uma (quando tiver).
export function listarWarpsTexto(player) {
	const warps = getWarps();
	const nomes = Object.keys(warps);

	if (nomes.length === 0) {
		player.sendMessage("§cAinda nao existe nenhum warp no servidor.");
		return;
	}

	const linhas = nomes.map((nome) => {
		const w = warps[nome];
		return w.comando ? `§f${nome} §7- §a!${w.comando}` : `§f${nome} §7- §8(sem comando, use pelo menu)`;
	});

	player.sendMessage(`§e=== Warps do servidor ===§r\n${linhas.join("\n")}`);
}
