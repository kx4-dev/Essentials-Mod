import { world } from "@minecraft/server";
import { ActionFormData, MessageFormData } from "@minecraft/server-ui";
import { formatarNomeItem } from "./itemNomes.js";
import { getHomes, removerHome } from "./home.js";

const ICONE_VOLTAR = "textures/icons/left_arrow";

function getContainer(entidade) {
	const inventario = entidade.getComponent("minecraft:inventory");
	return inventario?.container ?? null;
}

// Move o item inteiro do slot do alvo pro inventario do dono. Se o
// inventario do dono estiver cheio, guarda de volta o que sobrar no
// mesmo slot do alvo.
function transferirItem(origem, destino, slot) {
	const item = origem.getItem(slot);
	if (!item) return false;
	const sobra = destino.addItem(item);
	origem.setItem(slot, sobra);
	return true;
}

// ===== INVENTARIO =====

export function abrirInventarioJogador(dono, alvo) {
	const container = getContainer(alvo);
	if (!container) {
		dono.sendMessage(`§cNao foi possivel acessar o inventario de §e${alvo.name}§c.`);
		return;
	}

	const form = new ActionFormData()
		.title(`Inventario de ${alvo.name}`)
		.body("Toque num item pra pegar ele (vai pro seu inventario).");

	const slotsComItem = [];
	for (let i = 0; i < container.size; i++) {
		const item = container.getItem(i);
		if (item) {
			slotsComItem.push(i);
			form.button(`${item.amount}x ${formatarNomeItem(item.typeId)}`, "textures/icons/inventory");
		}
	}

	if (slotsComItem.length === 0) {
		form.body("Esse jogador nao tem nenhum item no inventario.");
	}

	form.button("Voltar", ICONE_VOLTAR);

	form.show(dono).then((res) => {
		if (res.canceled) return;

		if (res.selection < slotsComItem.length) {
			const slot = slotsComItem[res.selection];
			const containerDono = getContainer(dono);
			if (!containerDono) {
				dono.sendMessage("§cNao foi possivel acessar o seu inventario.");
				return;
			}
			transferirItem(container, containerDono, slot);
			abrirInventarioJogador(dono, alvo);
			return;
		}
	});
}

// ===== BAU DO ENDER =====
// A API de script do Minecraft Bedrock (ate a versao usada nesse addon) nao
// da acesso direto ao conteudo do bau do ender de outro jogador enquanto ele
// esta offline/longe. O addon tenta acessar o componente; se o Minecraft nao
// suportar isso na versao do jogo instalada, avisa o dono ao inves de travar.
export function verBauDoEnder(dono, alvo) {
	let enderContainer = null;

	try {
		const componente = alvo.getComponent("minecraft:ender_chest_inventory") ?? alvo.getComponent("minecraft:enderchest");
		enderContainer = componente?.container ?? null;
	} catch (erro) {
		console.warn(`Erro ao acessar bau do ender: ${erro}`);
	}

	if (!enderContainer) {
		dono.sendMessage(
			`§cNao foi possivel ler o bau do ender de §e${alvo.name}§c a distancia. §7(O Minecraft ainda nao libera esse acesso via addon nessa versao. Para ver, va ate o jogador e abra o bau do ender dele fisicamente.)`
		);
		return;
	}

	const linhas = [];
	for (let i = 0; i < enderContainer.size; i++) {
		const item = enderContainer.getItem(i);
		if (item) linhas.push(`§7- §f${item.amount}x ${formatarNomeItem(item.typeId)}`);
	}

	if (linhas.length === 0) {
		dono.sendMessage(`§e${alvo.name}§r nao tem nenhum item no bau do ender.`);
		return;
	}

	dono.sendMessage(`§l§bBau do Ender de ${alvo.name}:§r\n${linhas.join("\n")}`);
}

// ===== HOME DO JOGADOR =====

export function abrirHomesJogador(dono, alvo) {
	const homes = getHomes(alvo);
	const nomes = Object.keys(homes);

	const form = new ActionFormData()
		.title(`Homes de ${alvo.name}`)
		.body(nomes.length > 0 ? "Toque numa home pra ver as opcoes." : "Esse jogador nao tem nenhuma home.");

	nomes.forEach((nome) => form.button(nome, "textures/icons/home"));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(dono).then((res) => {
		if (res.canceled) return;
		if (res.selection < nomes.length) {
			abrirOpcoesHomeJogador(dono, alvo, nomes[res.selection]);
			return;
		}
	});
}

function abrirOpcoesHomeJogador(dono, alvo, nomeHome) {
	const homes = getHomes(alvo);
	const home = homes[nomeHome];
	if (!home) {
		dono.sendMessage("§cEssa home nao existe mais.");
		abrirHomesJogador(dono, alvo);
		return;
	}

	const form = new ActionFormData()
		.title(nomeHome)
		.body(`X: ${home.x}  Y: ${home.y}  Z: ${home.z}`)
		.button("Teleportar ate a home", "textures/icons/home")
		.button("Apagar Home", "textures/icons/remove")
		.button("Voltar", ICONE_VOLTAR);

	form.show(dono).then((res) => {
		if (res.canceled) return;

		if (res.selection === 0) {
			const dimension = world.getDimension(home.dimension.replace("minecraft:", ""));
			dono.teleport({ x: home.x, y: home.y, z: home.z }, { dimension });
			dono.sendMessage(`§aVoce foi teleportado para a home §e${nomeHome}§a de §e${alvo.name}§a.`);
			return;
		}

		if (res.selection === 1) {
			const confirmar = new MessageFormData()
				.title("Apagar Home")
				.body(`Tem certeza que quer apagar a home §e${nomeHome}§r de §e${alvo.name}§r?`)
				.button1("Sim, apagar")
				.button2("Cancelar");

			confirmar.show(dono).then((res2) => {
				if (res2.canceled || res2.selection === 1) {
					abrirHomesJogador(dono, alvo);
					return;
				}
				removerHome(alvo, nomeHome);
				dono.sendMessage(`§aHome §e${nomeHome}§a de §e${alvo.name}§a apagada.`);
				abrirHomesJogador(dono, alvo);
			});
			return;
		}

		abrirHomesJogador(dono, alvo);
	});
}
