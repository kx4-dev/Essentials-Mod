import { system } from "@minecraft/server";
import { getPermissoes } from "./rank.js";
import { estaEmCombate } from "./combatLog.js";

// Conta regressiva de 3 segundos antes de teleportar. Toca som de xp (so o
// jogador ouve) a cada segundo e cancela se o jogador se mover.
// "outroJogador" e opcional: quando o teleporte envolve duas pessoas (pedido
// de teleporte aceito), ele tambem e avisado se o teleporte for cancelado.
export function iniciarContagemTeleporte(player, executarTeleporte, outroJogador) {
	const inicio = { x: player.location.x, y: player.location.y, z: player.location.z };
	let restante = 3;

	function avisarCancelado() {
		player.sendMessage("§cSeu tp foi cancelado: voce se moveu.");
		if (!outroJogador) return;
		try {
			outroJogador.sendMessage(`§cSeu tp foi cancelado: §e${player.name}§c se moveu.`);
		} catch (erro) {
			console.warn(`Erro ao avisar cancelamento de tp para o outro jogador: ${erro}`);
		}
	}

	function passo() {
		try {
			const atual = player.location;
			const moveu =
				Math.abs(atual.x - inicio.x) > 0.1 ||
				Math.abs(atual.y - inicio.y) > 0.1 ||
				Math.abs(atual.z - inicio.z) > 0.1;

			if (moveu) {
				avisarCancelado();
				return;
			}

			if (restante <= 0) {
				executarTeleporte();
				return;
			}

			player.playSound("random.orb");
			player.onScreenDisplay.setActionBar(`§eTeleportando em §a${restante}§e... §7(nao se mova)`);
			restante--;
			system.runTimeout(passo, 20);
		} catch (erro) {
			player.sendMessage("§cAlgo deu errado ao teleportar. Tente novamente.");
			console.warn(`Erro na contagem de teleporte: ${erro}`);
		}
	}

	passo();
}

// So pula a contagem regressiva se o rank do jogador tiver a permissao
// "Teleporte Instantaneo" ligada (por padrao nenhum rank tem, nem o Membro).
// Antes de qualquer coisa, bloqueia teleporte se o jogador levou ou deu
// golpe de PVP a pouco tempo (rtp, home, warp, voltar, clan e aceitar
// pedido de teleporte passam todos por aqui).
export function teleportarComContagem(player, executarTeleporte, outroJogador) {
	if (estaEmCombate(player)) {
		player.sendMessage("§cVoce nao pode usar teleporte enquanto estiver em combate!");
		return;
	}
	if (getPermissoes(player).teleporteInstantaneo) {
		executarTeleporte();
		return;
	}
	iniciarContagemTeleporte(player, executarTeleporte, outroJogador);
}
