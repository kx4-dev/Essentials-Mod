import { world, system } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { SONS } from "./sounds.js";

const KEY = "re:clearlag";
const DIMENSOES = ["overworld", "nether", "the_end"];

const SUFIXOS_ARMADURA_ARMA = ["sword", "pickaxe", "axe", "shovel", "hoe", "helmet", "chestplate", "leggings", "boots"];

function configPadrao() {
	return {
		ativo: false,
		intervaloSegundos: 120,
		som: "xp",
		somAtivo: true,
		textoAviso: "O chao vai ser limpo em",
		coresContagem: ["§l§b", "§l§b", "§l§b", "§l§b", "§l§b", "§l§b", "§l§b", "§l§b", "§l§b", "§l§b"],
		corMensagemFinal: "§f",
		corAviso: "§c",
		limparMobsHostis: true,
		limparItensChao: true,
		limparOrbesXp: true,
		itensProtegidos: {
			nomeados: true,
			aldeao: true,
			netherite: true,
			diamante: true,
			pocoes: true,
			macas: true,
			mace: true,
			shulker: true,
			elytra: true,
			blocosFerroEsmeralda: false
		},
		itensExtras: [],
		totalLimpezas: 0,
		totalEntidades: 0
	};
}

// Se a paleta salva ainda for uma das paletas antigas (nunca customizada em
// "Editar Letra"), troca automaticamente pela nova paleta padrao.
const CORES_ANTIGAS = ["§e", "§e", "§e", "§e", "§6", "§6", "§6", "§c", "§c", "§4"];
const CORES_ANTIGAS_2 = ["§l§b", "§l§b", "§l§b", "§l§e", "§l§e", "§l§e", "§l§6", "§l§6", "§l§c", "§l§c"];

export function getConfig() {
	const salvo = getData(KEY, {});
	const config = { ...configPadrao(), ...salvo };
	config.itensProtegidos = { ...configPadrao().itensProtegidos, ...(salvo.itensProtegidos ?? {}) };
	if (
		salvo.coresContagem &&
		(JSON.stringify(salvo.coresContagem) === JSON.stringify(CORES_ANTIGAS) ||
			JSON.stringify(salvo.coresContagem) === JSON.stringify(CORES_ANTIGAS_2))
	) {
		config.coresContagem = configPadrao().coresContagem;
	}
	if (salvo.corMensagemFinal === "§a") config.corMensagemFinal = configPadrao().corMensagemFinal;
	return config;
}

function saveConfig(config) {
	setData(KEY, config);
}

export function getSonsDisponiveis() {
	return Object.keys(SONS);
}

export function definirIntervalo(segundos) {
	const numero = Number(segundos);
	if (!Number.isFinite(numero)) return;
	const config = getConfig();
	config.intervaloSegundos = Math.max(10, Math.min(3000, Math.floor(numero)));
	saveConfig(config);
}

export function definirSom(somId) {
	if (!SONS[somId]) return;
	const config = getConfig();
	config.som = somId;
	saveConfig(config);
}

export function definirSomAtivo(ativo) {
	const config = getConfig();
	config.somAtivo = !!ativo;
	saveConfig(config);
}

export function definirTextoAviso(texto) {
	texto = (texto ?? "").trim();
	if (!texto) return;
	const config = getConfig();
	config.textoAviso = texto;
	saveConfig(config);
}

export function definirCoresContagem(novasCores, novaCorFinal, novaCorAviso) {
	const config = getConfig();
	config.coresContagem = config.coresContagem.map((cor, i) => (novasCores[i] && novasCores[i].trim() ? novasCores[i].trim() : cor));
	if (novaCorFinal && novaCorFinal.trim()) config.corMensagemFinal = novaCorFinal.trim();
	if (novaCorAviso && novaCorAviso.trim()) config.corAviso = novaCorAviso.trim();
	saveConfig(config);
}

export function definirLimparMobsHostis(ativo) {
	const config = getConfig();
	config.limparMobsHostis = !!ativo;
	saveConfig(config);
}

export function definirLimparItensChao(ativo) {
	const config = getConfig();
	config.limparItensChao = !!ativo;
	saveConfig(config);
}

export function definirLimparOrbesXp(ativo) {
	const config = getConfig();
	config.limparOrbesXp = !!ativo;
	saveConfig(config);
}

export function definirItemProtegidoToggle(categoria, ativo) {
	const config = getConfig();
	if (!(categoria in config.itensProtegidos)) return;
	config.itensProtegidos[categoria] = !!ativo;
	saveConfig(config);
}

export function definirItensExtras(textoSeparadoPorVirgula) {
	const lista = (textoSeparadoPorVirgula ?? "")
		.split(",")
		.map((s) => s.trim().toLowerCase())
		.filter((s) => s.length > 0);
	const config = getConfig();
	config.itensExtras = lista;
	saveConfig(config);
}

// Os itens da lista extra SEMPRE sao limpos, mesmo que baterem com uma
// categoria protegida (ex: admin quer limpar "totem" mesmo com itens
// nomeados protegidos). E o oposto do que a lista de categorias faz.
function itemProtegido(typeId, config) {
	const id = typeId.toLowerCase();
	const p = config.itensProtegidos;

	if (config.itensExtras.some((palavra) => id.includes(palavra))) return false;

	if (p.netherite && id.includes("netherite")) return true;
	if (p.diamante && id.includes("diamond") && !id.includes("diamond_block")) return true;
	if (p.pocoes && (id.includes("potion") || id === "minecraft:phantom_membrane")) return true;
	if (p.macas && (id === "minecraft:golden_apple" || id === "minecraft:enchanted_golden_apple")) return true;
	if (p.mace && id === "minecraft:mace") return true;
	if (p.shulker && id.includes("shulker_box")) return true;
	if (p.elytra && (id === "minecraft:elytra" || id === "minecraft:firework_rocket")) return true;
	if (p.blocosFerroEsmeralda && (id === "minecraft:iron_block" || id === "minecraft:emerald_block")) return true;

	return false;
}

function tocarSomTodos(config) {
	if (!config.somAtivo) return;
	const som = SONS[config.som] ?? SONS.xp;
	world.getAllPlayers().forEach((p) => {
		try {
			p.playSound(som);
		} catch (erro) {
			console.warn(`Erro ao tocar som do clearlag: ${erro}`);
		}
	});
}

function avisarTodos(texto) {
	world.getAllPlayers().forEach((p) => {
		try {
			p.sendMessage(texto);
		} catch (erro) {
			console.warn(`Erro ao avisar clearlag: ${erro}`);
		}
	});
}

function executarLimpeza() {
	const config = getConfig();
	let mobsRemovidos = 0;
	let xpRemovidos = 0;
	let itensRemovidos = 0;

	for (const nomeDim of DIMENSOES) {
		let dimension;
		try {
			dimension = world.getDimension(nomeDim);
		} catch {
			continue;
		}

		if (config.limparItensChao) {
			try {
				dimension.getEntities({ type: "minecraft:item" }).forEach((entidade) => {
					try {
						const item = entidade.getComponent("minecraft:item")?.itemStack;
						if (item && itemProtegido(item.typeId, config)) return;
						entidade.remove();
						itensRemovidos++;
					} catch (erro) {
						console.warn(`Erro ao remover item no clearlag: ${erro}`);
					}
				});
			} catch (erro) {
				console.warn(`Erro ao buscar itens no clearlag: ${erro}`);
			}
		}

		if (config.limparOrbesXp) {
			try {
				dimension.getEntities({ type: "minecraft:xp_orb" }).forEach((entidade) => {
					try {
						entidade.remove();
						xpRemovidos++;
					} catch (erro) {
						console.warn(`Erro ao remover xp no clearlag: ${erro}`);
					}
				});
			} catch (erro) {
				console.warn(`Erro ao buscar xp no clearlag: ${erro}`);
			}
		}

		if (config.limparMobsHostis) {
			try {
				dimension.getEntities().forEach((entidade) => {
					try {
						if (entidade.typeId === "minecraft:player") return;
						if (entidade.typeId === "minecraft:item" || entidade.typeId === "minecraft:xp_orb") return;

						if (config.itensProtegidos.aldeao && entidade.typeId === "minecraft:villager") return;
						if (entidade.typeId === "minecraft:wolf" || entidade.typeId === "minecraft:cat") return;
						if (config.itensProtegidos.nomeados && entidade.nameTag && entidade.nameTag.trim() !== "") return;

						entidade.remove();
						mobsRemovidos++;
					} catch (erro) {
						console.warn(`Erro ao remover mob no clearlag: ${erro}`);
					}
				});
			} catch (erro) {
				console.warn(`Erro ao buscar mobs no clearlag: ${erro}`);
			}
		}
	}

	const configAtualizado = getConfig();
	configAtualizado.totalLimpezas = (configAtualizado.totalLimpezas ?? 0) + 1;
	configAtualizado.totalEntidades = (configAtualizado.totalEntidades ?? 0) + mobsRemovidos + xpRemovidos + itensRemovidos;
	saveConfig(configAtualizado);

	avisarTodos(
		`§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬§r\n` +
			`${configAtualizado.corMensagemFinal}§l✔ Chao foi limpo com sucesso§r\n` +
			`§7Mobs: ${configAtualizado.corMensagemFinal}${mobsRemovidos}  §8•  §7Xp: ${configAtualizado.corMensagemFinal}${xpRemovidos}  §8•  §7Itens: ${configAtualizado.corMensagemFinal}${itensRemovidos}\n` +
			`§7Proxima limpeza sera em: ${configAtualizado.corMensagemFinal}${configAtualizado.intervaloSegundos}s§r\n` +
			`§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬§r`
	);
}

export function limparAgora(player) {
	executarLimpeza();
	player.sendMessage("§aLimpeza executada manualmente com sucesso!");
}

// Guarda o "handle" dos timers pra poder cancelar de verdade antes de
// criar outro, evitando dois ciclos rodando ao mesmo tempo.
let handleEspera = null;
let handleContagem = null;

function cancelarTimersPendentes() {
	if (handleEspera !== null) {
		system.clearRun(handleEspera);
		handleEspera = null;
	}
	if (handleContagem !== null) {
		system.clearRun(handleContagem);
		handleContagem = null;
	}
}

function textoSubavisoContagem(config) {
	if (config.limparItensChao) return "§7Pegue seus itens do chao antes que eles sumam.";
	if (config.limparMobsHostis) return "§7Os mobs hostis do chao serao removidos.";
	if (config.limparOrbesXp) return "§7As orbes de XP do chao serao removidas.";
	return "§7A limpeza automatica vai rodar.";
}

function iniciarContagemLimpeza() {
	const config = getConfig();
	avisarTodos(
		`§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬§r\n` +
			`${config.corAviso}§l⚠ [Aviso do servidor]§r §f${config.textoAviso} §b§l10§r§f segundos!§r\n` +
			`${textoSubavisoContagem(config)}\n` +
			`§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬§r`
	);

	let restante = 10;

	function passo() {
		const configAtual = getConfig();
		if (!configAtual.ativo) return;

		if (restante <= 0) {
			executarLimpeza();
			agendarProxima();
			return;
		}

		const cor = configAtual.coresContagem[10 - restante] ?? "§l§b";
		avisarTodos(`${cor}${restante}`);
		tocarSomTodos(configAtual);
		restante--;
		handleContagem = system.runTimeout(passo, 20);
	}

	passo();
}

function agendarProxima() {
	cancelarTimersPendentes();

	const config = getConfig();
	if (!config.ativo) return;

	const esperaAntesDoAviso = Math.max(0, config.intervaloSegundos - 10);
	handleEspera = system.runTimeout(() => {
		handleEspera = null;
		const configAtual = getConfig();
		if (!configAtual.ativo) return;
		iniciarContagemLimpeza();
	}, esperaAntesDoAviso * 20);
}

export function ativar(player) {
	const config = getConfig();
	config.ativo = true;
	saveConfig(config);
	agendarProxima();
	player.sendMessage("§aLimpeza automatica ativada.");
}

export function desativar(player) {
	const config = getConfig();
	config.ativo = false;
	saveConfig(config);
	cancelarTimersPendentes();
	player.sendMessage("§cLimpeza automatica desativada.");
}

export function retomarSeAtivo() {
	const config = getConfig();
	if (config.ativo) {
		agendarProxima();
	}
}
