import { system } from "@minecraft/server";
import { teleportarComContagem } from "./teleportCountdown.js";
import { getData, setData } from "./database.js";

const KEY_CONFIG = "re:rtp:config";
const AJUSTE = 10;
const TENTATIVAS_MAX = 8;
const DURACAO_EFEITOS = 100; // 5 segundos em ticks
const RAIO_JAULA = 2; // 5x5

function configPadrao() {
	return { distancia: 2000 };
}

export function getConfigRtp() {
	return { ...configPadrao(), ...getData(KEY_CONFIG, {}) };
}

export function definirDistanciaRtp(valor) {
	const numero = Math.floor(Number(valor));
	if (!Number.isFinite(numero) || numero < 10) return false;
	setData(KEY_CONFIG, { distancia: Math.min(10000, numero) });
	return true;
}

const BLOCOS_AGUA = new Set(["minecraft:water", "minecraft:flowing_water"]);
const BLOCOS_INSEGUROS = new Set(["minecraft:water", "minecraft:flowing_water", "minecraft:lava", "minecraft:flowing_lava"]);
const ALTURA_ESPERA = 318; // acima de quase tudo, usado so pra forcar o chunk a carregar
const TENTATIVAS_CHAO = 10; // quantas vezes espera o chunk carregar antes de desistir

// Escaneia de cima pra baixo ate achar o primeiro bloco solido/liquido.
// So funciona direito se o chunk (x,z) ja estiver carregado - por isso a
// gente so chama isso DEPOIS de teleportar o jogador pra perto (ver embaixo).
function encontrarChao(dimension, x, z) {
	for (let y = 319; y >= -60; y--) {
		let bloco;
		try {
			bloco = dimension.getBlock({ x, y, z });
		} catch {
			return null; // chunk ainda nao carregado - avisa quem chamou pra tentar de novo
		}
		if (!bloco || bloco.typeId === "minecraft:air") continue;
		return bloco;
	}
	return null;
}

// Manda o jogador pra cima do destino primeiro (isso forca o chunk a
// carregar) e so DEPOIS escaneia o chao de verdade, ja com o chunk carregado.
function tentarEncontrarChaoCarregado(dimension, x, z, tentativasRestantes, callback) {
	const chao = encontrarChao(dimension, x, z);
	if (chao || tentativasRestantes <= 0) {
		callback(chao);
		return;
	}
	system.runTimeout(() => tentarEncontrarChaoCarregado(dimension, x, z, tentativasRestantes - 1, callback), 4);
}

export function executarRtp(player) {
	const dimension = player.dimension;
	const distancia = getConfigRtp().distancia;
	const angulo = Math.random() * Math.PI * 2;
	const x = Math.floor(player.location.x + Math.cos(angulo) * distancia);
	const z = Math.floor(player.location.z + Math.sin(angulo) * distancia);

	teleportarComContagem(player, () => {
		try {
			// Passo 1: manda o jogador pra bem alto, em cima do destino. Nesse
			// meio tempo ele fica protegido (resistencia + sem queda) e o chunk
			// comeca a carregar porque o jogador esta perto dele agora.
			player.teleport({ x, y: ALTURA_ESPERA, z }, { dimension });
			player.addEffect("blindness", DURACAO_EFEITOS, { amplifier: 0, showParticles: false });
			player.addEffect("resistance", DURACAO_EFEITOS, { amplifier: 3, showParticles: false });
			player.addEffect("slow_falling", DURACAO_EFEITOS, { amplifier: 0, showParticles: false });

			finalizarRtp(player, dimension, x, z);
		} catch (erro) {
			player.sendMessage("§cNao foi possivel fazer o rtp. Tente novamente.");
			console.warn(`Erro no rtp: ${erro}`);
		}
	});
}

function finalizarRtp(player, dimension, x, z) {
	tentarEncontrarChaoCarregado(dimension, x, z, TENTATIVAS_CHAO, (chao) => {
		reposicionarComChao(player, dimension, x, z, chao, 0);
	});
}

// Se cair em agua/lava, ajusta uns blocos pro lado e escaneia nesse novo
// ponto (que ja deve estar carregado, ta perto do primeiro).
function reposicionarComChao(player, dimension, x, z, chao, tentativa) {
	if (chao && BLOCOS_INSEGUROS.has(chao.typeId) && tentativa < TENTATIVAS_MAX) {
		const anguloAjuste = Math.random() * Math.PI * 2;
		const novoX = Math.floor(x + Math.cos(anguloAjuste) * AJUSTE);
		const novoZ = Math.floor(z + Math.sin(anguloAjuste) * AJUSTE);
		const novoChao = encontrarChao(dimension, novoX, novoZ);
		reposicionarComChao(player, dimension, novoX, novoZ, novoChao, tentativa + 1);
		return;
	}

	// Nao achou chao nenhum (void, chunk nao gerado etc.) - usa uma altura
	// segura generica em vez de arriscar teleportar dentro de bloco.
	const y = chao ? chao.location.y + 1 : 100;

	try {
		player.teleport({ x, y, z }, { dimension });

		try {
			player.onScreenDisplay.setTitle(`§fX: ${x}  Y: ${y}  Z: ${z}`, {
				subtitle: "§7Voce foi teleportado",
				stayDuration: DURACAO_EFEITOS,
				fadeInDuration: 10,
				fadeOutDuration: 20
			});
		} catch (erro) {
			console.warn(`Erro ao mostrar titulo de coordenadas no rtp: ${erro}`);
		}

		// Confere de novo depois de assentar, por garantia (ex: caiu numa
		// caverna por baixo de folhagem que nao contava como "chao").
		system.runTimeout(() => checarSegurancaPosRtp(player), 10);
	} catch (erro) {
		player.sendMessage("§cNao foi possivel fazer o rtp. Tente novamente.");
		console.warn(`Erro no rtp: ${erro}`);
	}
}

// Depois do rtp: se o jogador ficou preso dentro de um bloco, quebra um
// espaco 5x5 ao redor pra ele sair. Se caiu na agua, prende ele numa jaula
// de vidro 5x5 por 30 segundos (pra nao se afogar/nadar pra longe) e depois
// remove a jaula sozinha. Se caiu em chao normal, nao faz nada.
function checarSegurancaPosRtp(player) {
	let atual;
	try {
		atual = player.location;
	} catch (erro) {
		console.warn(`Erro ao checar seguranca pos rtp: ${erro}`);
		return;
	}

	const dimension = player.dimension;
	const centro = { x: Math.floor(atual.x), y: Math.floor(atual.y), z: Math.floor(atual.z) };

	let blocoNosPes;
	try {
		blocoNosPes = dimension.getBlock(centro);
	} catch (erro) {
		console.warn(`Erro ao ler bloco pos rtp: ${erro}`);
		return;
	}
	if (!blocoNosPes) return;

	if (blocoNosPes.typeId !== "minecraft:air" && !BLOCOS_AGUA.has(blocoNosPes.typeId)) {
		// Travado dentro de um bloco solido: abre um espaco 5x5 ao redor.
		for (let x = -RAIO_JAULA; x <= RAIO_JAULA; x++) {
			for (let z = -RAIO_JAULA; z <= RAIO_JAULA; z++) {
				for (let y = 0; y <= 3; y++) {
					try {
						dimension.getBlock({ x: centro.x + x, y: centro.y + y, z: centro.z + z })?.setType("minecraft:air");
					} catch (erro) {
						console.warn(`Erro ao abrir espaco pos rtp: ${erro}`);
					}
				}
			}
		}
		return;
	}

	if (BLOCOS_AGUA.has(blocoNosPes.typeId)) {
		// Caiu na agua: prende numa jaula de vidro temporaria.
		for (let x = -RAIO_JAULA; x <= RAIO_JAULA; x++) {
			for (let z = -RAIO_JAULA; z <= RAIO_JAULA; z++) {
				for (let y = 0; y <= 3; y++) {
					const ehParede = x === -RAIO_JAULA || x === RAIO_JAULA || z === -RAIO_JAULA || z === RAIO_JAULA || y === 0 || y === 3;
					if (!ehParede) continue;
					try {
						dimension.getBlock({ x: centro.x + x, y: centro.y + y, z: centro.z + z })?.setType("minecraft:glass");
					} catch (erro) {
						console.warn(`Erro ao montar jaula pos rtp: ${erro}`);
					}
				}
			}
		}

		system.runTimeout(() => {
			for (let x = -RAIO_JAULA; x <= RAIO_JAULA; x++) {
				for (let z = -RAIO_JAULA; z <= RAIO_JAULA; z++) {
					for (let y = 0; y <= 3; y++) {
						try {
							dimension.getBlock({ x: centro.x + x, y: centro.y + y, z: centro.z + z })?.setType("minecraft:air");
						} catch (erro) {
							console.warn(`Erro ao remover jaula pos rtp: ${erro}`);
						}
					}
				}
			}
		}, 30 * 20);
	}
}
