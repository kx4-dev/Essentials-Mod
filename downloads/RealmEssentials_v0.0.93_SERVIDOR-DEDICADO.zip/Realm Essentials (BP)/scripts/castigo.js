import { world } from "@minecraft/server";
import { getData, setData } from "./database.js";

const KEY = "re:castigos";
const TAG = "re_castigado";
const RAIO = 2; // jaula 5x5 (raio 2 a partir do centro)
const ALTURA = 4;

function getCastigos() {
	return getData(KEY, {});
}

function saveCastigos(castigos) {
	setData(KEY, castigos);
}

export function estaCastigado(player) {
	try {
		return player.hasTag(TAG);
	} catch {
		return false;
	}
}

function montarJaula(dimension, centro, tipo) {
	for (let x = -RAIO; x <= RAIO; x++) {
		for (let z = -RAIO; z <= RAIO; z++) {
			for (let y = 0; y <= ALTURA; y++) {
				const ehParede = x === -RAIO || x === RAIO || z === -RAIO || z === RAIO || y === 0 || y === ALTURA;
				if (!ehParede) continue;
				try {
					dimension.getBlock({ x: centro.x + x, y: centro.y + y, z: centro.z + z })?.setType(tipo);
				} catch (erro) {
					console.warn(`Erro ao montar jaula de castigo: ${erro}`);
				}
			}
		}
	}
}

export function castigarJogador(dono, alvo) {
	if (estaCastigado(alvo)) {
		dono.sendMessage(`§e${alvo.name}§c ja esta de castigo.`);
		return;
	}

	const centro = { x: Math.floor(alvo.location.x), y: Math.floor(alvo.location.y), z: Math.floor(alvo.location.z) };
	const dimension = alvo.dimension;

	montarJaula(dimension, centro, "minecraft:glass");
	try {
		alvo.teleport({ x: centro.x + 0.5, y: centro.y + 1, z: centro.z + 0.5 }, { dimension });
	} catch (erro) {
		console.warn(`Erro ao teleportar jogador pra jaula: ${erro}`);
	}
	alvo.addTag(TAG);

	const castigos = getCastigos();
	castigos[alvo.id] = {
		nome: alvo.name,
		castigadoPor: dono.name,
		x: centro.x,
		y: centro.y,
		z: centro.z,
		dimension: dimension.id
	};
	saveCastigos(castigos);

	dono.sendMessage(`§a${alvo.name}§a foi colocado de castigo.`);
	try {
		alvo.sendMessage(`§cVoce foi colocado de castigo por §e${dono.name}§c.`);
	} catch (erro) {
		console.warn(`Erro ao avisar jogador do castigo: ${erro}`);
	}
}

export function retirarCastigo(dono, alvoOuNome) {
	const castigos = getCastigos();
	const alvo = typeof alvoOuNome === "string" ? world.getAllPlayers().find((p) => p.name === alvoOuNome) : alvoOuNome;

	const id = alvo ? alvo.id : Object.keys(castigos).find((cid) => castigos[cid].nome === alvoOuNome);
	const info = castigos[id];

	if (!info) {
		dono.sendMessage("§cEsse jogador nao esta de castigo.");
		return;
	}

	try {
		const dimension = world.getDimension(info.dimension.replace("minecraft:", ""));
		montarJaula(dimension, info, "minecraft:air");
	} catch (erro) {
		console.warn(`Erro ao remover jaula de castigo: ${erro}`);
	}

	delete castigos[id];
	saveCastigos(castigos);

	if (alvo) {
		alvo.removeTag(TAG);
		try {
			alvo.sendMessage("§aVoce foi liberado do castigo!");
		} catch (erro) {
			console.warn(`Erro ao avisar liberacao do castigo: ${erro}`);
		}
	}

	dono.sendMessage(`§a${info.nome}§a foi liberado do castigo.`);
}

export function getListaCastigados() {
	const castigos = getCastigos();
	return Object.keys(castigos).map((id) => ({ id, ...castigos[id] }));
}

// Mostra o titulo pra quem ta de castigo. Chamado periodicamente pelo main.js.
export function aplicarCastigoTick() {
	world.getAllPlayers().forEach((player) => {
		if (!estaCastigado(player)) return;

		const castigos = getCastigos();
		const info = castigos[player.id];
		const castigadoPor = info?.castigadoPor ?? "admin";

		try {
			player.onScreenDisplay.setTitle("§l§0Voce estao de castigo!", {
				subtitle: `§7Por §f${castigadoPor}`,
				fadeInDuration: 0,
				stayDuration: 40,
				fadeOutDuration: 0
			});
		} catch (erro) {
			console.warn(`Erro ao mostrar titulo de castigo: ${erro}`);
		}
	});
}
