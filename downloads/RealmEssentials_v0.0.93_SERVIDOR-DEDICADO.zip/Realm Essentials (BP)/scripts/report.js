import { world } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { ehDono } from "./permissoes.js";
import { logar, escapar } from "./discordLogs.js";

const KEY = "re:reports";
const MAX_REPORTS = 50;

export function getReports() {
	return getData(KEY, []);
}

function saveReports(reports) {
	setData(KEY, reports.slice(-MAX_REPORTS));
}

export function limparDenuncias(player) {
	saveReports([]);
	player.sendMessage("§aDenuncias limpas.");
}

function notificarOps(mensagem) {
	// Usa a tag "dono" (mesma do resto do addon) em vez de isOp() - isOp()
	// so e true se o jogador for operador de verdade no mundo, o que a
	// grande maioria dos servidores nunca configura, entao a notificacao
	// nunca aparecia pra ninguem.
	world
		.getAllPlayers()
		.filter((p) => ehDono(p))
		.forEach((dono) => dono.sendMessage(mensagem));
}

export function denunciarJogador(player, nomeAlvo, motivo) {
	nomeAlvo = (nomeAlvo ?? "").trim();
	motivo = (motivo ?? "").trim();

	if (!nomeAlvo) {
		player.sendMessage("§cSelecione um jogador para denunciar.");
		return;
	}

	if (!motivo) {
		player.sendMessage("§cDescreva o motivo da denuncia.");
		return;
	}

	const alvo = world.getPlayers({ name: nomeAlvo })[0];
	if (!alvo) {
		player.sendMessage(`§cJogador §e${nomeAlvo}§c nao esta mais online.`);
		return;
	}

	if (alvo.id === player.id) {
		player.sendMessage("§cVoce nao pode denunciar a si mesmo.");
		return;
	}

	const reports = getReports();
	reports.push({
		tipo: "jogador",
		denunciante: player.name,
		alvo: alvo.name,
		motivo,
		data: new Date().toISOString()
	});
	saveReports(reports);

	logar("denuncia", "Denúncia de jogador", `**${escapar(player.name)}** denunciou **${escapar(alvo.name)}**.`, [
		{ nome: "Motivo", valor: escapar(motivo, 900), inline: false }
	]);

	player.sendMessage(`§aDenuncia contra §e${alvo.name}§a enviada com sucesso.`);
	notificarOps(`§c[Denuncia] §e${player.name}§r denunciou §e${alvo.name}§r. Motivo: §f${motivo}`);
}

export function denunciarServidor(player, motivo) {
	motivo = (motivo ?? "").trim();

	if (!motivo) {
		player.sendMessage("§cDescreva o motivo da denuncia.");
		return;
	}

	const reports = getReports();
	reports.push({
		tipo: "servidor",
		denunciante: player.name,
		motivo,
		data: new Date().toISOString()
	});
	saveReports(reports);

	logar("denuncia", "Denúncia sobre o servidor", `**${escapar(player.name)}** enviou uma denúncia.`, [
		{ nome: "Motivo", valor: escapar(motivo, 900), inline: false }
	]);

	player.sendMessage("§aDenuncia sobre o servidor enviada com sucesso.");
	notificarOps(`§c[Denuncia de Servidor] §e${player.name}§r. Motivo: §f${motivo}`);
}
