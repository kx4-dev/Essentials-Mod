import { world, system } from "@minecraft/server";
import { emCooldown } from "./cooldown.js";

const TAG_NA_JAULA = "re_na_jaula";
const RAIO = 2; // 5x5
const ALTURA = 3;
const DURACAO_TICKS = 15 * 20;
const COOLDOWN_SEGUNDOS = 35;

// vitimaId -> { criadorId, centro, dimension }
const jaulasAtivas = new Map();

function itemEhGatilhoDeJaula(item) {
	if (!item) return false;
	const nome = (item.nameTag ?? "").trim().toLowerCase();
	if (nome !== "jaula") return false;
	return item.typeId.includes("glass");
}

function montarOuRemoverJaula(dimension, centro, tipo) {
	for (let x = -RAIO; x <= RAIO; x++) {
		for (let z = -RAIO; z <= RAIO; z++) {
			for (let y = 0; y <= ALTURA; y++) {
				const ehParede = x === -RAIO || x === RAIO || z === -RAIO || z === RAIO || y === 0 || y === ALTURA;
				if (!ehParede) continue;
				try {
					dimension.getBlock({ x: centro.x + x, y: centro.y + y, z: centro.z + z })?.setType(tipo);
				} catch (erro) {
					console.warn(`Erro ao montar/remover jaula pvp: ${erro}`);
				}
			}
		}
	}
}

export function estaNaJaula(player) {
	try {
		return player.hasTag(TAG_NA_JAULA);
	} catch {
		return false;
	}
}

// Chamado a cada golpe. Se o atacante estiver segurando um vidro/painel de
// vidro renomeado pra "Jaula", tenta prender os dois num cubo de vidro.
export function tentarPrender(atacante, alvo) {
	let item;
	try {
		const inventory = atacante.getComponent("minecraft:inventory")?.container;
		item = inventory?.getItem(atacante.selectedSlotIndex ?? 0);
	} catch (erro) {
		return;
	}
	if (!itemEhGatilhoDeJaula(item)) return;

	// Se o dono da jaula bater em quem ta preso, libera na hora.
	const jaulaExistente = jaulasAtivas.get(alvo.id);
	if (jaulaExistente && jaulaExistente.criadorId === atacante.id) {
		liberarJaula(alvo.id);
		return;
	}

	if (estaNaJaula(alvo) || estaNaJaula(atacante)) return;
	if (emCooldown(atacante, "jaulapvp", COOLDOWN_SEGUNDOS)) return;

	const centro = { x: Math.floor(alvo.location.x), y: Math.floor(alvo.location.y), z: Math.floor(alvo.location.z) };
	const dimension = alvo.dimension;

	montarOuRemoverJaula(dimension, centro, "minecraft:glass");

	try {
		atacante.teleport({ x: centro.x + 1.5, y: centro.y + 1, z: centro.z + 0.5 }, { dimension });
	} catch (erro) {
		console.warn(`Erro ao teleportar atacante pra jaula pvp: ${erro}`);
	}

	atacante.addTag(TAG_NA_JAULA);
	alvo.addTag(TAG_NA_JAULA);
	jaulasAtivas.set(alvo.id, { criadorId: atacante.id, centro, dimension: dimension.id });

	atacante.sendMessage(`§aVoce prendeu §e${alvo.name}§a numa jaula por 15 segundos!`);
	try {
		alvo.sendMessage(`§cVoce foi preso numa jaula por §e${atacante.name}§c!`);
	} catch (erro) {
		console.warn(`Erro ao avisar jogador preso na jaula: ${erro}`);
	}

	system.runTimeout(() => liberarJaula(alvo.id), DURACAO_TICKS);
}

function liberarJaula(vitimaId) {
	const info = jaulasAtivas.get(vitimaId);
	if (!info) return;

	try {
		const dimension = world.getDimension(info.dimension.replace("minecraft:", ""));
		montarOuRemoverJaula(dimension, info.centro, "minecraft:air");
	} catch (erro) {
		console.warn(`Erro ao remover jaula pvp: ${erro}`);
	}

	const vitima = world.getAllPlayers().find((p) => p.id === vitimaId);
	const criador = world.getAllPlayers().find((p) => p.id === info.criadorId);
	if (vitima) vitima.removeTag(TAG_NA_JAULA);
	if (criador) criador.removeTag(TAG_NA_JAULA);

	jaulasAtivas.delete(vitimaId);
}
