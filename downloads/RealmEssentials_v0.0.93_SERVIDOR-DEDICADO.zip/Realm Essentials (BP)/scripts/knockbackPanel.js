import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import {
	LIMITES,
	PRESETS,
	getConfigKnockback,
	salvarConfigKnockback,
	restaurarPadraoKnockback,
	aplicarPreset,
	lerNumero,
	formatarNumero
} from "./knockback.js";
import { logar, escapar } from "./discordLogs.js";

const ICONE_LIGAR = "textures/items/emerald";
const ICONE_DESLIGAR = "textures/ui/icon_trash";
const ICONE_CONFIGURAR = "textures/ui/icon_setting";
const ICONE_LISTA = "textures/items/paper";
const ICONE_VARA = "textures/items/fishing_rod_uncast";
const ICONE_VOLTAR = "textures/icons/left_arrow";

function estado(ligado) {
	return ligado ? "§aligado" : "§cdesligado";
}

function registrar(player, descricao) {
	logar("moderacao", "Knockback alterado", `**${escapar(player.name)}** ${descricao}`);
}

function limite([min, max]) {
	return `${min} a ${max}`;
}

// aoVoltar: reabre o Painel Admin.
export function abrirMenuKnockback(player, aoVoltar) {
	const c = getConfigKnockback();
	const lp = c.launchPad;

	const corpo =
		`§fKnockback de PvP: ${estado(c.ativo)}\n` +
		`§7  Golpe: horizontal §f${formatarNumero(c.horizontal)}§7 | vertical §f${formatarNumero(c.vertical)}\n` +
		`§7  Projéteis (vara, bola de neve, ovo): ${estado(c.projeteis.ativo)} §7(força §f${formatarNumero(c.projeteis.forca)}§7)\n\n` +
		`§fLaunch Pad (placa de ouro): ${estado(lp.ativo)}\n` +
		`§7  Horizontal §f${formatarNumero(lp.horizontal)}§7 | vertical §f${formatarNumero(lp.vertical)}\n\n` +
		`§8Não vale em área protegida sem PvP nem em jogador congelado.`;

	new ActionFormData()
		.title("Knockback")
		.body(corpo)
		.button(c.ativo ? "Desligar Knockback\n§7[Volta ao empurrão normal]" : "Ligar Knockback\n§7[Ativa o empurrão customizado]", c.ativo ? ICONE_DESLIGAR : ICONE_LIGAR)
		.button("Ajustar Knockback\n§7[Golpe e projéteis]", ICONE_VARA)
		.button("Presets\n§7[Padrão, Alto ou Leve]", ICONE_LISTA)
		.button("Launch Pad\n§7[Placa de ouro que lança]", ICONE_CONFIGURAR)
		.button("Restaurar padrão\n§7[Volta os valores originais]", ICONE_DESLIGAR)
		.button("Voltar", ICONE_VOLTAR)
		.show(player)
		.then((res) => {
			if (res.canceled) return;
			switch (res.selection) {
				case 0: {
					const novo = getConfigKnockback();
					novo.ativo = !novo.ativo;
					salvarConfigKnockback(novo);
					player.sendMessage(novo.ativo ? "§aKnockback ligado!" : "§eKnockback desligado.");
					registrar(player, novo.ativo ? "ligou o knockback." : "desligou o knockback.");
					abrirMenuKnockback(player, aoVoltar);
					break;
				}
				case 1:
					abrirAjuste(player, aoVoltar);
					break;
				case 2:
					abrirPresets(player, aoVoltar);
					break;
				case 3:
					abrirLaunchPad(player, aoVoltar);
					break;
				case 4:
					confirmarRestaurar(player, aoVoltar);
					break;
				default:
					aoVoltar?.(player);
			}
		});
}

function abrirAjuste(player, aoVoltar) {
	const c = getConfigKnockback();

	new ModalFormData()
		.title("Ajustar Knockback")
		.textField(`Golpe - força horizontal (${limite(LIMITES.horizontal)})`, "Ex: 0.85", { defaultValue: formatarNumero(c.horizontal) })
		.textField(`Golpe - força vertical (${limite(LIMITES.vertical)})`, "Ex: 0.65", { defaultValue: formatarNumero(c.vertical) })
		.toggle("Empurrar também com projéteis (vara, bola de neve, ovo)", { defaultValue: c.projeteis.ativo })
		.textField(`Projéteis - força (${limite(LIMITES.projetil)})`, "Ex: 1.25", { defaultValue: formatarNumero(c.projeteis.forca) })
		.show(player)
		.then((res) => {
			if (res.canceled || !res.formValues) {
				abrirMenuKnockback(player, aoVoltar);
				return;
			}
			const [h, v, projAtivo, projForca] = res.formValues;
			const horizontal = lerNumero(h, LIMITES.horizontal);
			const vertical = lerNumero(v, LIMITES.vertical);
			const forca = lerNumero(projForca, LIMITES.projetil);

			const erros = [];
			if (horizontal === null) erros.push(`horizontal (${limite(LIMITES.horizontal)})`);
			if (vertical === null) erros.push(`vertical (${limite(LIMITES.vertical)})`);
			if (forca === null) erros.push(`força dos projéteis (${limite(LIMITES.projetil)})`);
			if (erros.length > 0) {
				player.sendMessage(`§cValor inválido em: §e${erros.join(", ")}§c. Use só números (pode ser com vírgula). Nada foi salvo.`);
				abrirAjuste(player, aoVoltar);
				return;
			}

			const novo = getConfigKnockback();
			novo.horizontal = horizontal;
			novo.vertical = vertical;
			novo.projeteis.ativo = !!projAtivo;
			novo.projeteis.forca = forca;
			salvarConfigKnockback(novo);

			player.sendMessage("§aKnockback atualizado!");
			registrar(player, `ajustou o knockback (golpe ${formatarNumero(horizontal)}/${formatarNumero(vertical)}, projéteis ${projAtivo ? "ligados" : "desligados"} ${formatarNumero(forca)}).`);
			abrirMenuKnockback(player, aoVoltar);
		});
}

function abrirPresets(player, aoVoltar) {
	const ids = Object.keys(PRESETS);

	const form = new ActionFormData()
		.title("Presets")
		.body("Aplica de uma vez os valores de golpe, projéteis e launch pad. Não liga nem desliga nada.");
	for (const id of ids) {
		const p = PRESETS[id];
		form.button(`${p.nome}\n§7[golpe ${formatarNumero(p.horizontal)}/${formatarNumero(p.vertical)} | launch ${formatarNumero(p.launchHorizontal)}/${formatarNumero(p.launchVertical)}]`, ICONE_LISTA);
	}
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		const id = ids[res.selection];
		if (id) {
			aplicarPreset(id);
			player.sendMessage(`§aPreset §e${PRESETS[id].nome}§a aplicado.`);
			registrar(player, `aplicou o preset ${PRESETS[id].nome}.`);
		}
		abrirMenuKnockback(player, aoVoltar);
	});
}

function abrirLaunchPad(player, aoVoltar) {
	const lp = getConfigKnockback().launchPad;

	new ActionFormData()
		.title("Launch Pad")
		.body(
			`§fStatus: ${estado(lp.ativo)}\n` +
				`§7Quem pisa numa placa de pressão de ouro (a "light weighted") é lançado na direção em que está olhando.\n\n` +
				`§fHorizontal: §e${formatarNumero(lp.horizontal)}  §fVertical: §e${formatarNumero(lp.vertical)}\n` +
				`§fPartícula: ${estado(lp.particula)}  §fSom: ${estado(lp.som)}\n` +
				`§fMensagem: §r${lp.mensagem || "§7(nenhuma)"}`
		)
		.button(lp.ativo ? "Desligar Launch Pad" : "Ligar Launch Pad", lp.ativo ? ICONE_DESLIGAR : ICONE_LIGAR)
		.button("Ajustar Launch Pad\n§7[Força, efeitos e mensagem]", ICONE_CONFIGURAR)
		.button("Voltar", ICONE_VOLTAR)
		.show(player)
		.then((res) => {
			if (res.canceled) return;
			if (res.selection === 0) {
				const novo = getConfigKnockback();
				novo.launchPad.ativo = !novo.launchPad.ativo;
				salvarConfigKnockback(novo);
				player.sendMessage(novo.launchPad.ativo ? "§aLaunch Pad ligado!" : "§eLaunch Pad desligado.");
				registrar(player, novo.launchPad.ativo ? "ligou o launch pad." : "desligou o launch pad.");
				abrirLaunchPad(player, aoVoltar);
				return;
			}
			if (res.selection === 1) {
				abrirAjusteLaunchPad(player, aoVoltar);
				return;
			}
			abrirMenuKnockback(player, aoVoltar);
		});
}

function abrirAjusteLaunchPad(player, aoVoltar) {
	const lp = getConfigKnockback().launchPad;

	new ModalFormData()
		.title("Ajustar Launch Pad")
		.textField(`Força horizontal (${limite(LIMITES.launchHorizontal)})`, "Ex: 5", { defaultValue: formatarNumero(lp.horizontal) })
		.textField(`Força vertical (${limite(LIMITES.launchVertical)})`, "Ex: 0.7", { defaultValue: formatarNumero(lp.vertical) })
		.toggle("Partícula ao lançar", { defaultValue: lp.particula })
		.toggle("Som ao lançar", { defaultValue: lp.som })
		.textField("Mensagem ao lançar (vazio = nenhuma)", "Ex: §e§lIMPULSO!", { defaultValue: lp.mensagem })
		.show(player)
		.then((res) => {
			if (res.canceled || !res.formValues) {
				abrirLaunchPad(player, aoVoltar);
				return;
			}
			const [h, v, particula, som, mensagem] = res.formValues;
			const horizontal = lerNumero(h, LIMITES.launchHorizontal);
			const vertical = lerNumero(v, LIMITES.launchVertical);

			const erros = [];
			if (horizontal === null) erros.push(`horizontal (${limite(LIMITES.launchHorizontal)})`);
			if (vertical === null) erros.push(`vertical (${limite(LIMITES.launchVertical)})`);
			if (erros.length > 0) {
				player.sendMessage(`§cValor inválido em: §e${erros.join(", ")}§c. Use só números (pode ser com vírgula). Nada foi salvo.`);
				abrirAjusteLaunchPad(player, aoVoltar);
				return;
			}

			const novo = getConfigKnockback();
			novo.launchPad.horizontal = horizontal;
			novo.launchPad.vertical = vertical;
			novo.launchPad.particula = !!particula;
			novo.launchPad.som = !!som;
			novo.launchPad.mensagem = String(mensagem ?? "").slice(0, 80);
			salvarConfigKnockback(novo);

			player.sendMessage("§aLaunch Pad atualizado!");
			registrar(player, `ajustou o launch pad (${formatarNumero(horizontal)}/${formatarNumero(vertical)}).`);
			abrirLaunchPad(player, aoVoltar);
		});
}

function confirmarRestaurar(player, aoVoltar) {
	new MessageFormData()
		.title("Restaurar padrão")
		.body("Volta golpe, projéteis e launch pad para os valores padrão.\n\nO que está ligado ou desligado não muda.")
		.button1("Sim, restaurar")
		.button2("Cancelar")
		.show(player)
		.then((res) => {
			if (!res.canceled && res.selection !== 1) {
				restaurarPadraoKnockback();
				player.sendMessage("§aValores do knockback restaurados.");
				registrar(player, "restaurou os valores padrão do knockback.");
			}
			abrirMenuKnockback(player, aoVoltar);
		});
}
