import { world } from "@minecraft/server";
import { getData, setData } from "./database.js";

const KEY = "re:areas_protegidas";
const RAIO_PADRAO = 15;
// Efeito aplicado a cada 3s (60 ticks) - por isso a duracao fica sempre
// nesse valor, so o amplificador (sempre 255, o maximo) e a lista de
// efeitos mudam de area pra area.
const DURACAO_EFEITO_TICKS = 60; // 3 segundos
const AMPLIFICADOR_EFEITO = 255;

// Lista de efeitos que o dono pode ligar/desligar por area no painel.
// Nao e a lista inteira do jogo, so os que fazem sentido usar numa area
// protegida (sem incluir dano/veneno etc, que seriam esquisitos aqui).
export const EFEITOS_DISPONIVEIS = [
	{ id: "resistance", nome: "Resistencia" },
	{ id: "regeneration", nome: "Regeneracao" },
	{ id: "fire_resistance", nome: "Resistencia a Fogo" },
	{ id: "weakness", nome: "Fraqueza" },
	{ id: "speed", nome: "Velocidade" },
	{ id: "slowness", nome: "Lentidao" },
	{ id: "jump_boost", nome: "Salto" },
	{ id: "haste", nome: "Pressa (Mineracao)" },
	{ id: "mining_fatigue", nome: "Fadiga de Mineracao" },
	{ id: "strength", nome: "Forca" },
	{ id: "night_vision", nome: "Visao Noturna" },
	{ id: "invisibility", nome: "Invisibilidade" },
	{ id: "water_breathing", nome: "Respiracao Aquatica" },
	{ id: "health_boost", nome: "Vida Extra" },
	{ id: "absorption", nome: "Absorcao" },
	{ id: "saturation", nome: "Saturacao" },
	{ id: "slow_falling", nome: "Queda Lenta" },
	{ id: "levitation", nome: "Levitacao" },
	{ id: "hunger", nome: "Fome" },
	{ id: "nausea", nome: "Nausea" },
	{ id: "blindness", nome: "Cegueira" }
];

// Toda area nova ja vem com esses 4 ligados (a mesma combinacao "safe zone"
// de antes, agora com resistencia junto).
const EFEITOS_PADRAO = ["weakness", "regeneration", "fire_resistance", "resistance"];
const CONTAINERS = [
	"chest",
	"barrel",
	"shulker_box",
	"trapped_chest",
	"ender_chest",
	"hopper",
	"furnace",
	"blast_furnace",
	"smoker",
	"dispenser",
	"dropper",
	"brewing_stand",
];

function getAreas() {
	return getData(KEY, {});
}

function saveAreas(areas) {
	setData(KEY, areas);
}

export function listarAreas() {
	return getAreas();
}

export function criarArea(player, nome, raio) {
	const nomeLimpo = (nome ?? "").trim();
	if (!nomeLimpo) return { ok: false, motivo: "Digite um nome pra area." };

	const areas = getAreas();
	if (areas[nomeLimpo]) return { ok: false, motivo: "Ja existe uma area protegida com esse nome." };

	areas[nomeLimpo] = {
		nome: nomeLimpo,
		x: player.location.x,
		y: player.location.y,
		z: player.location.z,
		dimension: player.dimension.id,
		raio: raio && raio > 0 ? raio : RAIO_PADRAO,
		permissoes: { abrirBau: false, interagir: false, pvp: false, quebrarBloco: false },
		efeitos: [...EFEITOS_PADRAO]
	};
	saveAreas(areas);
	return { ok: true };
}

export function deletarArea(nome) {
	const areas = getAreas();
	if (!areas[nome]) return false;
	delete areas[nome];
	saveAreas(areas);
	return true;
}

export function definirPermissaoArea(nome, chave, valor) {
	const areas = getAreas();
	if (!areas[nome]) return false;
	areas[nome].permissoes[chave] = valor;
	saveAreas(areas);
	return true;
}

// Areas criadas antes dessa atualizacao nao tem o campo "efeitos" salvo -
// nesse caso usa a combinacao padrao antiga (agora com resistencia junto).
export function getEfeitosArea(area) {
	return area.efeitos ?? EFEITOS_PADRAO;
}

// Liga ou desliga um efeito especifico numa area. Aceita qualquer id de
// EFEITOS_DISPONIVEIS.
export function alternarEfeitoArea(nome, efeitoId) {
	const areas = getAreas();
	const area = areas[nome];
	if (!area) return false;

	const atuais = getEfeitosArea(area);
	area.efeitos = atuais.includes(efeitoId) ? atuais.filter((e) => e !== efeitoId) : [...atuais, efeitoId];
	saveAreas(areas);
	return true;
}

function estaDentro(location, dimensionId, area) {
	if (dimensionId !== area.dimension) return false;
	const dx = location.x - area.x;
	const dy = location.y - area.y;
	const dz = location.z - area.z;
	return Math.sqrt(dx * dx + dy * dy + dz * dz) <= area.raio;
}

// Retorna a primeira area protegida que contem esse ponto (ou null).
export function getAreaNoPonto(location, dimensionId) {
	const areas = getAreas();
	for (const nome in areas) {
		if (estaDentro(location, dimensionId, areas[nome])) return areas[nome];
	}
	return null;
}

export function getAreaDoJogador(player) {
	return getAreaNoPonto(player.location, player.dimension.id);
}

// Verdadeiro se o jogador esta numa area protegida com pvp desligado (ou
// seja, um lugar "seguro" onde ele nao leva dano de outro jogador).
export function estaEmAreaSegura(player) {
	const area = getAreaDoJogador(player);
	return !!area && !area.permissoes.pvp;
}

// Verdadeiro se o pvp entre esses dois jogadores esta bloqueado (area
// protegida de qualquer um dos dois com pvp desligado). Usado tanto pra
// desfazer o dano quanto pra decidir se o combate log deve ser acionado.
export function pvpBloqueadoEntre(jogadorA, jogadorB) {
	const area = getAreaDoJogador(jogadorA) ?? (jogadorB ? getAreaDoJogador(jogadorB) : null);
	return !!area && !area.permissoes.pvp;
}

export function ehBlocoContainer(typeId) {
	const id = typeId.replace("minecraft:", "");
	return CONTAINERS.some((c) => id.includes(c));
}

// Roda a cada 3s: quem esta dentro de uma area protegida ve o nome dela na
// actionbar. Se a area nao tiver pvp liberado, tambem ganha os efeitos
// configurados pro dono naquela area (por padrao: weakness, regeneration,
// fire_resistance e resistance, todos no nivel maximo) - efeitos que duram
// os mesmos 3s, entao ficam sempre renovados enquanto o jogador ficar la
// dentro. Se o dono liberar pvp na area, esses efeitos somem, pra nao
// atrapalhar quem quer lutar.
export function tickAreasProtegidas() {
	world.getAllPlayers().forEach((player) => {
		const area = getAreaDoJogador(player);
		if (!area) return;

		try {
			if (!area.permissoes.pvp) {
				getEfeitosArea(area).forEach((efeitoId) => {
					try {
						player.addEffect(efeitoId, DURACAO_EFEITO_TICKS, { amplifier: AMPLIFICADOR_EFEITO, showParticles: false });
					} catch (erro) {
						console.warn(`Erro ao aplicar efeito ${efeitoId} na area protegida: ${erro}`);
					}
				});
			}
			player.onScreenDisplay.setActionBar(`§b§lArea Protegida §r§f- §e${area.nome}`);
		} catch (erro) {
			console.warn(`Erro ao aplicar area protegida em ${player.name}: ${erro}`);
		}
	});
}

// Chamado no beforeEvents.playerBreakBlock. Retorna true se bloqueou.
export function bloquearQuebraBlocoProtegido(player, block) {
	const area = getAreaDoJogador(player);
	if (!area || area.permissoes.quebrarBloco) return false;

	try {
		player.sendMessage(`§cVoce nao pode quebrar blocos na area protegida §e${area.nome}§c.`);
	} catch (erro) {
		console.warn(`Erro ao avisar bloqueio de bloco em area protegida: ${erro}`);
	}
	return true;
}

// Chamado no beforeEvents.playerPlaceBlock. Colocar bloco nunca e permitido
// dentro de uma area protegida, independente das outras permissoes.
export function bloquearColocarBlocoProtegido(player) {
	const area = getAreaDoJogador(player);
	if (!area) return false;

	try {
		player.sendMessage(`§cVoce nao pode colocar blocos na area protegida §e${area.nome}§c.`);
	} catch (erro) {
		console.warn(`Erro ao avisar bloqueio de colocar bloco em area protegida: ${erro}`);
	}
	return true;
}

// Chamado no beforeEvents.playerInteractWithBlock. Retorna true se bloqueou.
export function bloquearInteracaoProtegida(player, block) {
	const area = getAreaDoJogador(player);
	if (!area) return false;

	const ehContainer = ehBlocoContainer(block.typeId);
	const permitido = ehContainer ? area.permissoes.abrirBau : area.permissoes.interagir;
	if (permitido) return false;

	try {
		const texto = ehContainer ? "abrir bau" : "interagir";
		player.sendMessage(`§cVoce nao pode ${texto} na area protegida §e${area.nome}§c.`);
	} catch (erro) {
		console.warn(`Erro ao avisar bloqueio de interacao em area protegida: ${erro}`);
	}
	return true;
}

// Chamado no afterEvents.entityHurt. Desfaz o dano se o pvp estiver
// desligado na area onde a vitima (ou o atacante) esta.
export function restaurarVidaSePvpBloqueado(vitima, atacante, dano) {
	if (vitima?.typeId !== "minecraft:player" || atacante?.typeId !== "minecraft:player") return;
	if (vitima.id === atacante.id) return;

	if (!pvpBloqueadoEntre(vitima, atacante)) return;

	try {
		const health = vitima.getComponent("minecraft:health");
		if (health) health.setCurrentValue(Math.min(health.currentValue + dano, health.effectiveMax));
	} catch (erro) {
		console.warn(`Erro ao restaurar vida na area protegida: ${erro}`);
	}
}
