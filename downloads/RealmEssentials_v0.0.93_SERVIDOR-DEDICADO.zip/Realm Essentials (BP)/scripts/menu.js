import { world } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { getNomeMenu } from "./welcome.js";
import { getHomes, criarHome, removerHome, teleportarHome } from "./home.js";
import { getWarps, criarWarp, removerWarp, teleportarWarp, ICONES_WARP } from "./warp.js";
import {
	getMeuClan,
	criarClan,
	convidarClan,
	getConvites,
	aceitarConvite,
	recusarConvite,
	sairClan,
	deletarClan,
	expulsarClan,
	getInfoClanTexto,
	getWarpsClan,
	criarWarpClan,
	removerWarpClan,
	teleportarWarpClan,
	getTodosClans,
	getInfoPublicaClan,
	solicitarEntrada,
	cancelarSolicitacao,
	getSolicitacoesEnviadas,
	getSolicitacoesDoClan,
	aceitarSolicitacao,
	recusarSolicitacao,
	definirIconeClan,
	ICONES_CLAN,
	CORES_CLAN
} from "./clan.js";
import { enviarDinheiro, getSaldo } from "./money.js";
import { abrirPainelDono } from "./ownerPanel.js";
import { abrirLoja } from "./shop.js";
import { pedirTeleport } from "./teleportRequest.js";
import { denunciarJogador, denunciarServidor } from "./report.js";
import { ativo } from "./featureFlags.js";

import { ehDono } from "./permissoes.js";
const ICONE_VOLTAR = "textures/icons/left_arrow";
const ICONE_CRIAR = "textures/ui/color_plus";
const ICONE_REMOVER = "textures/ui/icon_trash";
const ICONE_TELEPORTE = "textures/items/ender_pearl";
const ICONE_DINHEIRO = "textures/items/emerald";
const ICONE_MENSAGEM = "textures/icons/comment";
const ICONE_JOGADOR = "textures/icons/players";
const ICONE_CLAN = "textures/icons/friends_clan";
const ICONE_SHOP = "textures/icons/shop";
const ICONE_WARP = "textures/icons/warps";
const ICONE_HOME = "textures/icons/home";
const ICONE_TRASH = "textures/ui/icon_trash";
const ICONE_CONVITE = "textures/ui/mail_icon";
const ICONE_CLANS_LISTA = "textures/ui/magnifyingGlass";

export function abrirMenuPrincipal(player) {
	const categorias = [
		{ nome: "Home", desc: "Seus pontos de teleporte", icone: ICONE_HOME, flag: "home", acao: abrirMenuHome },
		{ nome: "Warp", desc: "Pontos do servidor", icone: ICONE_WARP, flag: "warp", acao: abrirMenuWarp },
		{ nome: "Jogadores", desc: "TPA, dinheiro e mensagens", icone: ICONE_JOGADOR, flag: null, acao: abrirMenuJogadores },
		{ nome: "Clan", desc: "Crie ou entre num grupo", icone: ICONE_CLAN, flag: "clan", acao: abrirMenuClan },
		{ nome: "Loja", desc: "Compre itens", icone: ICONE_SHOP, flag: "loja", acao: abrirLoja },
		{ nome: "Reportar", desc: "Denuncie jogador ou bug", icone: "textures/icons/camera_yo", flag: "reportar", acao: abrirMenuReportar },
		// Só aparece pra admin/dono: atalho pro painel sem precisar de comando.
		{ nome: "Painel Admin", desc: "Clear lag, CPS, logs, punições...", icone: "textures/ui/icon_setting", flag: null, soAdmin: true, acao: abrirPainelDono }
	].filter((c) => (c.flag === null || ativo(c.flag)) && (!c.soAdmin || ehDono(player)));

	const form = new ActionFormData().title(getNomeMenu()).body("Escolha uma categoria:");
	categorias.forEach((c) => form.button(`${c.nome}\n§7[${c.desc}]`, c.icone));

	form.show(player).then((res) => {
		if (res.canceled) return;
		const categoria = categorias[res.selection];
		if (categoria) categoria.acao(player);
	});
}

// ===== HOME =====

function abrirMenuHome(player) {
	const homes = getHomes(player);
	const nomes = Object.keys(homes);

	const form = new ActionFormData()
		.title("Home")
		.body("Escolha uma opcao:")
		.button("Criar Home", ICONE_CRIAR)
		.button("Lista de Home", ICONE_HOME);
	if (nomes.length > 0) form.button("Remover Home", ICONE_TRASH);
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (res.selection === 0) {
			pedirTexto(player, "Criar Home", "Nome da home", (nome) => {
				criarHome(player, nome);
				abrirMenuHome(player);
			});
			return;
		}

		if (res.selection === 1) {
			abrirListaHome(player, nomes);
			return;
		}

		if (nomes.length > 0 && res.selection === 2) {
			abrirMenuRemoverHome(player, nomes);
			return;
		}

		abrirMenuPrincipal(player);
	});
}

function abrirListaHome(player, nomes) {
	const form = new ActionFormData()
		.title("Lista de Home")
		.body(nomes.length > 0 ? "Toque em uma home para teleportar (contagem de 3s)." : "Voce ainda nao possui homes.");

	nomes.forEach((nome) => form.button(nome, ICONE_HOME));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < nomes.length) {
			teleportarHome(player, nomes[res.selection]);
			return;
		}
		abrirMenuHome(player);
	});
}

function abrirMenuRemoverHome(player, nomes) {
	const form = new ActionFormData().title("Remover Home");
	nomes.forEach((nome) => form.button(nome, ICONE_TRASH));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < nomes.length) {
			confirmarAcao(
				player,
				"Remover Home",
				`Tem certeza que deseja remover a home §e${nomes[res.selection]}§r?`,
				() => {
					removerHome(player, nomes[res.selection]);
					abrirMenuHome(player);
				},
				() => abrirMenuHome(player)
			);
			return;
		}
		abrirMenuHome(player);
	});
}

// ===== WARP =====

function abrirMenuWarp(player) {
	const warps = getWarps();
	const nomes = Object.keys(warps);

	const form = new ActionFormData()
		.title("Warp")
		.body(nomes.length > 0 ? "Toque em um warp para teleportar." : "Ainda nao existe nenhum warp.");

	nomes.forEach((nome) => {
		const w = warps[nome];
		const linhaComando = w.comando ? `\n§7!${w.comando}` : "";
		form.button(`${nome}${linhaComando}`, w.icone ?? ICONE_WARP);
	});

	if (ehDono(player)) {
		form.button("Criar Warp", ICONE_CRIAR);
		if (nomes.length > 0) form.button("Remover Warp", ICONE_REMOVER);
	}
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (res.selection < nomes.length) {
			teleportarWarp(player, nomes[res.selection]);
			return;
		}

		let acao = res.selection - nomes.length;

		if (ehDono(player)) {
			if (acao === 0) {
				abrirCriarWarp(player);
				return;
			}
			acao -= 1;

			if (nomes.length > 0) {
				if (acao === 0) {
					abrirMenuRemoverWarp(player, nomes);
					return;
				}
				acao -= 1;
			}
		}

		abrirMenuPrincipal(player);
	});
}

// Formulario de criar warp: nome, comando opcional (tipo "spawn" pra virar
// "!spawn") e um dropdown com varios icones pra escolher.
function abrirCriarWarp(player) {
	const nomesIcones = ICONES_WARP.map((i) => i.nome);

	const form = new ModalFormData()
		.title("Criar Warp")
		.textField("Nome da warp", "Ex: Spawn")
		.textField("Comando (opcional, sem o !)", "Ex: spawn - deixe vazio se nao quiser")
		.dropdown("Icone da warp", nomesIcones, { defaultValueIndex: 0 });

	form.show(player).then((res) => {
		if (res.canceled) {
			abrirMenuWarp(player);
			return;
		}

		const nome = (res.formValues[0] ?? "").trim();
		const comando = (res.formValues[1] ?? "").trim();
		const icone = ICONES_WARP[res.formValues[2] ?? 0].icone;

		criarWarp(player, nome, comando, icone);
		abrirMenuWarp(player);
	});
}

function abrirMenuRemoverWarp(player, nomes) {
	const form = new ActionFormData().title("Remover Warp");
	nomes.forEach((nome) => form.button(nome, ICONE_REMOVER));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < nomes.length) {
			confirmarAcao(
				player,
				"Remover Warp",
				`Tem certeza que deseja remover o warp §e${nomes[res.selection]}§r?`,
				() => {
					removerWarp(player, nomes[res.selection]);
					abrirMenuWarp(player);
				},
				() => abrirMenuWarp(player)
			);
			return;
		}
		abrirMenuWarp(player);
	});
}

// ===== JOGADORES =====

function abrirMenuJogadores(player) {
	const jogadores = world.getAllPlayers();

	const form = new ActionFormData()
		.title("Jogadores")
		.body(`§fSeu saldo: §e${getSaldo(player)}§f moedas\n\n` + (jogadores.length > 0 ? "Toque em um jogador." : "Nenhum outro jogador online."));

	jogadores.forEach((p) => form.button(p.name, ICONE_JOGADOR));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < jogadores.length) {
			abrirMenuJogador(player, jogadores[res.selection]);
			return;
		}
		abrirMenuPrincipal(player);
	});
}

function abrirMenuJogador(player, alvo) {
	const opcoes = [
		...(ativo("teleportar")
			? [
					{ nome: "Teleportar ate ele", icone: ICONE_TELEPORTE, acao: () => pedirTeleport(player, alvo, "ate_ele") },
					{ nome: "Teleportar ele ate mim", icone: ICONE_TELEPORTE, acao: () => pedirTeleport(player, alvo, "ate_mim") }
				]
			: []),
		{
			nome: "Enviar Dinheiro",
			icone: ICONE_DINHEIRO,
			acao: () => pedirTexto(player, "Enviar Dinheiro", "Quantidade", (valor) => enviarDinheiro(player, alvo, valor))
		},
		{
			nome: "Mensagem Privada",
			icone: ICONE_MENSAGEM,
			acao: () =>
				pedirTexto(player, "Mensagem Privada", "Mensagem", (mensagem) => enviarMensagemPrivada(player, alvo, mensagem))
		}
	];

	const form = new ActionFormData().title(alvo.name);
	opcoes.forEach((o) => form.button(o.nome, o.icone));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < opcoes.length) {
			opcoes[res.selection].acao();
			return;
		}
		abrirMenuJogadores(player);
	});
}

function enviarMensagemPrivada(remetente, alvo, mensagem) {
	mensagem = (mensagem ?? "").trim();
	if (!mensagem) {
		remetente.sendMessage("§cDigite uma mensagem.");
		return;
	}

	try {
		alvo.sendMessage(`§7[§dPM§7] §e${remetente.name} §7» §f${mensagem}`);
		alvo.playSound("random.orb");
	} catch {
		remetente.sendMessage("§cEsse jogador nao esta mais online.");
		return;
	}

	remetente.sendMessage(`§7[§dPM§7] §fvoce §7» §e${alvo.name}§7: §f${mensagem}`);
	try {
		remetente.playSound("random.pop2");
	} catch (erro) {
		console.warn(`Erro ao tocar som de mensagem enviada: ${erro}`);
	}
}

// ===== CLAN =====

function abrirMenuClan(player) {
	const meuClan = getMeuClan(player);

	if (meuClan) {
		const form = new ActionFormData()
			.title("Clan")
			.body(`Voce faz parte do clan §e${meuClan.nome}§r.`)
			.button("Meu Clan\n§7[Ver e gerenciar]", meuClan.clan.icone ?? ICONE_CLAN)
			.button("Clans\n§7[Ver todos os clans]", ICONE_CLANS_LISTA)
			.button("Voltar", ICONE_VOLTAR);

		form.show(player).then((res) => {
			if (res.canceled) return;
			if (res.selection === 0) abrirMeuClan(player);
			if (res.selection === 1) abrirListaClans(player);
			if (res.selection === 2) abrirMenuPrincipal(player);
		});
		return;
	}

	const pendencias = getConvites(player).length + getSolicitacoesEnviadas(player).length;
	const form = new ActionFormData()
		.title("Clan")
		.body("§eUna forcas, suba no topo e deixe seu nome marcado no servidor!§r\n\nEscolha uma das opcoes abaixo:")
		.button("Criar Clan\n§7[Forme sua equipe]", ICONE_CRIAR)
		.button("Clans\n§7[Ver todos os clans]", ICONE_CLANS_LISTA)
		.button(`Convites${pendencias > 0 ? ` (${pendencias})` : ""}\n§7[Suas pendencias]`, ICONE_CONVITE)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			abrirCriarClan(player);
		}
		if (res.selection === 1) abrirListaClans(player);
		if (res.selection === 2) abrirMenuConvites(player);
		if (res.selection === 3) abrirMenuPrincipal(player);
	});
}

// Formulario completo de criar clan: nome, bio (max 100 caracteres) e a cor
// do nome do clan - o dropdown ja mostra cada opcao na propria cor, servindo
// de previa de como vai ficar.
function abrirCriarClan(player) {
	const nomesCores = CORES_CLAN.map((c) => c.nome);

	const modal = new ModalFormData()
		.title("Criar Clan")
		.textField("Nome do clan", "Ex: Guerreiros")
		.textField("Bio do clan (opcional, max 100 caracteres)", "Uma frase curta sobre o clan")
		.dropdown("Cor do nome do clan", nomesCores, { defaultValueIndex: 7 });

	modal.show(player).then((res) => {
		if (res.canceled) {
			abrirMenuClan(player);
			return;
		}

		const nome = (res.formValues[0] ?? "").trim();
		const bio = (res.formValues[1] ?? "").trim();
		const cor = CORES_CLAN[res.formValues[2] ?? 7].codigo;

		criarClan(player, nome, bio, cor);
		abrirMenuClan(player);
	});
}

// Lista todos os clans do servidor, com a tag de cada um. Toque num pra
// inspecionar as informacoes e, se quiser, pedir pra entrar.
function abrirListaClans(player) {
	const clans = getTodosClans();

	const form = new ActionFormData()
		.title("Lista de Clans")
		.body(clans.length > 0 ? "Selecione um clan para inspecionar:" : "Nenhum clan foi criado ainda.");

	clans.forEach((c) => {
		const tagTexto = c.tag ? `${c.cor}[${c.tag}]` : `${c.cor}[${c.nome}]`;
		form.button(`${c.cor}${c.nome} §7Tag: ${tagTexto}\n§7Membros: §f${c.membros}`, c.icone ?? ICONE_CLAN);
	});
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < clans.length) {
			abrirInfoClanPublico(player, clans[res.selection].nome);
			return;
		}
		abrirMenuClan(player);
	});
}

function abrirInfoClanPublico(player, nomeClan) {
	const info = getInfoPublicaClan(nomeClan);
	if (!info) {
		abrirListaClans(player);
		return;
	}

	const meuClan = getMeuClan(player);
	const jaTenhoClan = !!meuClan;
	const esseEOMeuClan = meuClan?.nome === nomeClan;
	const jaSolicitei = !jaTenhoClan && getSolicitacoesEnviadas(player).includes(nomeClan);

	const corpo =
		`§eNome do Clan: ${info.cor}${info.nome}\n` +
		(info.bio ? `§7${info.bio}\n` : "") +
		`\n§eTag: ${info.tag ? `${info.cor}[${info.tag}]` : `${info.cor}[${info.nome}]`}\n` +
		`§eCriado: §a${info.diasCriado !== null ? `${info.diasCriado} dias atras` : "desconhecido"}\n` +
		`§eDono do Clan: §f${info.dono}\n` +
		`§eQuantidade de Membros: §d${info.membros}/${info.limite}\n\n` +
		(!jaTenhoClan && !jaSolicitei ? "Gostaria de solicitar entrada neste clan?" : "");

	const form = new ActionFormData().title(info.nome).body(corpo);

	let acaoPrincipal = null;
	if (esseEOMeuClan) {
		// Ja e o proprio clan do jogador, nao faz sentido pedir entrada.
	} else if (jaSolicitei) {
		form.button("Cancelar Pedido\n§7[Ja solicitado]", ICONE_TRASH);
		acaoPrincipal = "cancelar";
	} else if (!jaTenhoClan) {
		form.button("Solicitar Entrada\n§7[Enviar Pedido]", ICONE_CRIAR);
		acaoPrincipal = "solicitar";
	}
	form.button("Voltar\n§7[Voltar ao Inicio]", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (acaoPrincipal && res.selection === 0) {
			if (acaoPrincipal === "solicitar") solicitarEntrada(player, nomeClan);
			if (acaoPrincipal === "cancelar") cancelarSolicitacao(player, nomeClan);
			abrirListaClans(player);
			return;
		}
		abrirListaClans(player);
	});
}

// Convites recebidos (de lideres que te chamaram) + pedidos que voce mesmo
// enviou e ainda estao esperando resposta.
function abrirMenuConvites(player) {
	const convites = getConvites(player);
	const solicitacoesEnviadas = getSolicitacoesEnviadas(player);

	const form = new ActionFormData()
		.title("Convites e Pedidos")
		.body(
			convites.length + solicitacoesEnviadas.length > 0
				? "Toque em um item para gerenciar."
				: "Voce nao tem nenhuma pendencia no momento."
		);

	convites.forEach((nome) => form.button(`§a${nome}\n§7[Voce foi convidado]`, ICONE_CONVITE));
	solicitacoesEnviadas.forEach((nome) => form.button(`§e${nome}\n§7[Aguardando o lider]`, ICONE_CONVITE));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < convites.length) {
			abrirRespostaConvite(player, convites[res.selection]);
			return;
		}
		const indice = res.selection - convites.length;
		if (indice < solicitacoesEnviadas.length) {
			const nomeClan = solicitacoesEnviadas[indice];
			confirmarAcao(
				player,
				"Cancelar Pedido",
				`Cancelar seu pedido de entrada no clan §e${nomeClan}§r?`,
				() => {
					cancelarSolicitacao(player, nomeClan);
					abrirMenuConvites(player);
				},
				() => abrirMenuConvites(player)
			);
			return;
		}
		abrirMenuClan(player);
	});
}

// Pedidos de entrada recebidos no proprio clan (so o lider ve essa tela).
function abrirGerenciarSolicitacoes(player) {
	const pedidos = getSolicitacoesDoClan(player);

	const form = new ActionFormData()
		.title("Pedidos de Entrada")
		.body(pedidos.length > 0 ? "Toque num jogador para aceitar ou recusar." : "Nenhum pedido pendente.");

	pedidos.forEach((p) => form.button(p.nome, ICONE_JOGADOR));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < pedidos.length) {
			const alvo = pedidos[res.selection];
			const resposta = new MessageFormData()
				.title(alvo.nome)
				.body(`O que deseja fazer com o pedido de §e${alvo.nome}§r?`)
				.button1("Aceitar")
				.button2("Recusar");

			resposta.show(player).then((res2) => {
				if (!res2.canceled) {
					if (res2.selection === 0) aceitarSolicitacao(player, alvo.id);
					if (res2.selection === 1) recusarSolicitacao(player, alvo.id);
				}
				abrirGerenciarSolicitacoes(player);
			});
			return;
		}
		abrirMeuClan(player);
	});
}

function abrirRespostaConvite(player, nomeClan) {
	const form = new MessageFormData()
		.title(nomeClan)
		.body(`Voce foi convidado para o clan §e${nomeClan}§r. O que deseja fazer?`)
		.button1("Aceitar")
		.button2("Recusar");

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) aceitarConvite(player, nomeClan);
		if (res.selection === 1) recusarConvite(player, nomeClan);
		abrirMenuClan(player);
	});
}

function abrirIconeClan(player) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		abrirMenuClan(player);
		return;
	}

	const nomesIcones = ICONES_CLAN.map((i) => i.nome);
	const indiceAtual = Math.max(
		0,
		ICONES_CLAN.findIndex((i) => i.icone === meuClan.clan.icone)
	);

	const modal = new ModalFormData()
		.title("Icone do Clan")
		.dropdown("Escolha o icone", nomesIcones, { defaultValueIndex: indiceAtual });

	modal.show(player).then((res) => {
		if (res.canceled) {
			abrirMeuClan(player);
			return;
		}
		const icone = ICONES_CLAN[res.formValues[0] ?? 0].icone;
		definirIconeClan(player, icone);
		abrirMeuClan(player);
	});
}

function abrirMeuClan(player) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		abrirMenuClan(player);
		return;
	}

	const souLider = meuClan.clan.lider === player.id;
	const form = new ActionFormData().title(meuClan.nome).body(getInfoClanTexto(player));

	if (souLider) {
		const pedidos = getSolicitacoesDoClan(player).length;
		form.button("Convidar Jogador\n§7[Chame um jogador]", ICONE_CONVITE);
		form.button(`Pedidos de Entrada${pedidos > 0 ? ` (${pedidos})` : ""}\n§7[Quem quer entrar]`, "textures/items/paper");
		form.button("Expulsar Membro\n§7[Remova alguem]", ICONE_REMOVER);
		form.button("Warp do Clan\n§7[Pontos do clan]", ICONE_WARP);
		form.button("Icone do Clan\n§7[Mudar o icone]", meuClan.clan.icone ?? ICONE_CLAN);
		form.button("Deletar Clan\n§7[Acao permanente]", "textures/items/diamond_sword");
	} else {
		form.button("Warp do Clan\n§7[Pontos do clan]", ICONE_WARP);
		form.button("Sair do Clan\n§7[Deixar o grupo]", ICONE_REMOVER);
	}
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (souLider) {
			if (res.selection === 0) {
				abrirSelecionarJogadorConvite(player);
				return;
			}
			if (res.selection === 1) {
				abrirGerenciarSolicitacoes(player);
				return;
			}
			if (res.selection === 2) {
				pedirTexto(player, "Expulsar Membro", "Nome do jogador", (nome) => {
					expulsarClan(player, nome);
					abrirMeuClan(player);
				});
				return;
			}
			if (res.selection === 3) {
				abrirMenuWarpClan(player);
				return;
			}
			if (res.selection === 4) {
				abrirIconeClan(player);
				return;
			}
			if (res.selection === 5) {
				confirmarAcao(
					player,
					"Deletar Clan",
					`Tem certeza que quer deletar o clan §e${meuClan.nome}§r? Essa acao nao pode ser desfeita.`,
					() => {
						deletarClan(player);
						abrirMenuClan(player);
					},
					() => abrirMeuClan(player)
				);
				return;
			}
			abrirMenuClan(player);
			return;
		}

		if (res.selection === 0) {
			abrirMenuWarpClan(player);
			return;
		}
		if (res.selection === 1) {
			confirmarAcao(
				player,
				"Sair do Clan",
				`Tem certeza que quer sair do clan §e${meuClan.nome}§r?`,
				() => {
					sairClan(player);
					abrirMenuClan(player);
				},
				() => abrirMeuClan(player)
			);
			return;
		}
		abrirMenuClan(player);
	});
}

function abrirMenuWarpClan(player) {
	const meuClan = getMeuClan(player);
	if (!meuClan) {
		abrirMenuClan(player);
		return;
	}

	const souLider = meuClan.clan.lider === player.id;
	const warps = getWarpsClan(player);
	const nomes = Object.keys(warps);

	const form = new ActionFormData()
		.title("Warp do Clan")
		.body(nomes.length > 0 ? "Toque em uma warp para teleportar." : "Seu clan ainda nao tem nenhuma warp.");

	nomes.forEach((nome) => form.button(nome, ICONE_WARP));

	if (souLider) {
		form.button("Criar Warp", ICONE_CRIAR);
		if (nomes.length > 0) form.button("Remover Warp", ICONE_REMOVER);
	}
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;

		if (res.selection < nomes.length) {
			teleportarWarpClan(player, nomes[res.selection]);
			return;
		}

		let acao = res.selection - nomes.length;

		if (souLider) {
			if (acao === 0) {
				pedirTexto(player, "Criar Warp do Clan", "Nome da warp", (nome) => {
					criarWarpClan(player, nome);
					abrirMenuWarpClan(player);
				});
				return;
			}
			acao -= 1;

			if (nomes.length > 0) {
				if (acao === 0) {
					abrirMenuRemoverWarpClan(player, nomes);
					return;
				}
				acao -= 1;
			}
		}

		abrirMeuClan(player);
	});
}

function abrirMenuRemoverWarpClan(player, nomes) {
	const form = new ActionFormData().title("Remover Warp do Clan");
	nomes.forEach((nome) => form.button(nome, ICONE_REMOVER));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < nomes.length) {
			removerWarpClan(player, nomes[res.selection]);
		}
		abrirMenuWarpClan(player);
	});
}

function abrirSelecionarJogadorConvite(player) {
	const meuClan = getMeuClan(player);
	const jogadores = world.getAllPlayers().filter((p) => !getMeuClan(p));

	const form = new ActionFormData()
		.title("Convidar Jogador")
		.body(jogadores.length > 0 ? "Toque em um jogador para convidar." : "Nao ha jogadores sem clan online.");

	jogadores.forEach((p) => form.button(p.name, ICONE_JOGADOR));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < jogadores.length) {
			convidarClan(player, jogadores[res.selection].name);
		}
		abrirMeuClan(player);
	});
}

// ===== REPORTAR =====

export function abrirMenuReportar(player) {
	const form = new ActionFormData()
		.title("Reportar")
		.body("Escolha o tipo de denuncia:")
		.button("Denunciar Jogador", ICONE_JOGADOR)
		.button("Denunciar Servidor", "textures/items/ender_pearl")
		.button("Voltar", ICONE_VOLTAR);

	form
		.show(player)
		.then((res) => {
			if (res.canceled) return;
			if (res.selection === 0) abrirDenunciaJogador(player);
			if (res.selection === 1) abrirDenunciaServidor(player);
			if (res.selection === 2) abrirMenuPrincipal(player);
		})
		.catch((erro) => console.warn(`Erro ao abrir menu de reportar: ${erro}`));
}

function abrirDenunciaJogador(player) {
	const jogadores = world.getAllPlayers().filter((p) => p.id !== player.id);

	const form = new ActionFormData()
		.title("Denunciar Jogador")
		.body(jogadores.length > 0 ? "Selecione o jogador que deseja denunciar." : "Nenhum outro jogador online.");

	jogadores.forEach((p) => form.button(p.name, ICONE_JOGADOR));
	form.button("Voltar", ICONE_VOLTAR);

	form
		.show(player)
		.then((res) => {
			if (res.canceled) return;
			if (res.selection < jogadores.length) {
				const alvo = jogadores[res.selection];
				const modal = new ModalFormData()
					.title(`Denunciar ${alvo.name}`)
					.textField("Motivo da denuncia", "Descreva o que aconteceu");

				modal
					.show(player)
					.then((res2) => {
						if (res2.canceled) return;
						const motivo = (res2.formValues[0] ?? "").trim();
						denunciarJogador(player, alvo.name, motivo);
						abrirMenuReportar(player);
					})
					.catch((erro) => console.warn(`Erro ao denunciar jogador: ${erro}`));
				return;
			}
			abrirMenuReportar(player);
		})
		.catch((erro) => console.warn(`Erro ao abrir lista de denuncia: ${erro}`));
}

function abrirDenunciaServidor(player) {
	const modal = new ModalFormData().title("Denunciar Servidor").textField("Motivo da denuncia", "Descreva o que aconteceu");

	modal
		.show(player)
		.then((res) => {
			if (res.canceled) return;
			const motivo = (res.formValues[0] ?? "").trim();
			denunciarServidor(player, motivo);
			abrirMenuReportar(player);
		})
		.catch((erro) => console.warn(`Erro ao denunciar servidor: ${erro}`));
}

// ===== UTIL =====

function pedirTexto(player, titulo, campo, callback) {
	const form = new ModalFormData().title(titulo).textField(campo, "");

	form.show(player).then((res) => {
		if (res.canceled) return;
		const valor = (res.formValues[0] ?? "").trim();
		callback(valor);
	});
}

// Mostra uma confirmacao (Sim/Cancelar) antes de executar uma acao irreversivel.
// onConfirmar: executado se o jogador confirmar.
// onCancelar: executado se o jogador cancelar ou fechar o formulario (opcional).
function confirmarAcao(player, titulo, mensagem, onConfirmar, onCancelar) {
	const form = new MessageFormData().title(titulo).body(mensagem).button1("Sim, tenho certeza").button2("Cancelar");

	form.show(player).then((res) => {
		if (res.canceled || res.selection === 1) {
			if (onCancelar) onCancelar();
			return;
		}
		onConfirmar();
	});
}
