import { world, ItemStack } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { getData, setData, getJogadoresConhecidos } from "./database.js";
import { getSaldo, adicionarSaldo } from "./money.js";
import { formatarNomeItem } from "./itemNomes.js";

// Cada jogador pode ter no maximo 1 loja. Guardado como um mapa
// { [idDoDono]: loja }, entao achar/editar a loja de alguem e sempre O(1).
const KEY = "re:lojas";

const LIMITE_NOME_LOJA = 30;
const LIMITE_DESC_LOJA = 80;
const LIMITE_NOME_ITEM = 30;
const LIMITE_DESC_ITEM = 80;
const PRECO_MAXIMO = 1000000;

const ICONE_SHOP = "textures/icons/shop";
const ICONE_CRIAR = "textures/ui/color_plus";
const ICONE_VENDER = "textures/items/gold_ingot";
const ICONE_COMPRAR = "textures/items/emerald";
const ICONE_ITEM = "textures/items/emerald";
const ICONE_PRECO = "textures/items/emerald";
const ICONE_REMOVER = "textures/ui/icon_trash";
const ICONE_VOLTAR = "textures/icons/left_arrow";

// ===== DADOS =====

function getLojas() {
	return getData(KEY, {});
}

function salvarLojas(lojas) {
	setData(KEY, lojas);
}

function getLoja(donoId) {
	return getLojas()[donoId] ?? null;
}

function nomeAtualDoDono(loja) {
	return getJogadoresConhecidos()[loja.dono] ?? loja.donoNome;
}

function gerarIdItem() {
	return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

export function criarLoja(player, nome, descricao) {
	nome = (nome ?? "").trim();
	if (!nome) {
		player.sendMessage("§cDigite um nome valido para a loja.");
		return;
	}
	if (nome.length > LIMITE_NOME_LOJA) {
		player.sendMessage(`§cO nome da loja deve ter no maximo ${LIMITE_NOME_LOJA} letras.`);
		return;
	}

	descricao = (descricao ?? "").trim();
	if (descricao.length > LIMITE_DESC_LOJA) {
		player.sendMessage(`§cA descricao deve ter no maximo ${LIMITE_DESC_LOJA} caracteres.`);
		return;
	}

	const lojas = getLojas();
	if (lojas[player.id]) {
		player.sendMessage("§cVoce ja tem uma loja.");
		return;
	}

	lojas[player.id] = { dono: player.id, donoNome: player.name, nome, descricao, itens: [] };
	salvarLojas(lojas);
	player.sendMessage(`§aLoja §e${nome}§a criada! Use §eVender Item§a na Loja para colocar itens a venda.`);
}

function adicionarItemNaLoja(donoId, itemLoja) {
	const lojas = getLojas();
	const loja = lojas[donoId];
	if (!loja) return false;
	loja.itens.push(itemLoja);
	salvarLojas(lojas);
	return true;
}

function removerItemDaLoja(donoId, itemId) {
	const lojas = getLojas();
	const loja = lojas[donoId];
	if (!loja) return null;
	const indice = loja.itens.findIndex((i) => i.id === itemId);
	if (indice === -1) return null;
	const [item] = loja.itens.splice(indice, 1);
	salvarLojas(lojas);
	return item;
}

function alterarPrecoItem(donoId, itemId, novoPreco) {
	const lojas = getLojas();
	const item = lojas[donoId]?.itens.find((i) => i.id === itemId);
	if (!item) return false;
	item.precoUnitario = novoPreco;
	salvarLojas(lojas);
	return true;
}

// Confirmacao generica (sim/cancelar), no mesmo estilo usado no resto do addon.
function confirmar(player, titulo, mensagem, onConfirmar, onCancelar) {
	const form = new MessageFormData().title(titulo).body(mensagem).button1("Sim, tenho certeza").button2("Cancelar");
	form.show(player).then((res) => {
		if (res.canceled || res.selection === 1) {
			if (onCancelar) onCancelar();
			return;
		}
		onConfirmar();
	});
}

// ===== MENU PRINCIPAL DA LOJA =====

export function abrirLoja(player) {
	const loja = getLoja(player.id);

	const form = new ActionFormData().title("Loja").body(`§aSeu saldo: §e${getSaldo(player)} moedas`);
	form.button(
		loja ? "Minha Loja\n§7Gerencie seus itens" : "Criar Loja\n§7Abra sua propria loja",
		loja ? ICONE_SHOP : ICONE_CRIAR
	);
	form.button("Vender Item\n§7Coloque um item a venda", ICONE_VENDER);
	form.button("Comprar Item\n§7Veja as lojas dos jogadores", ICONE_COMPRAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			if (loja) abrirGerenciarLoja(player);
			else abrirFormCriarLoja(player);
			return;
		}
		if (res.selection === 1) {
			abrirVenderItem(player);
			return;
		}
		if (res.selection === 2) abrirComprarItem(player);
	});
}

function abrirFormCriarLoja(player) {
	const modal = new ModalFormData()
		.title("Criar Loja")
		.textField("Nome da loja", "Ex: Mercado do Steve")
		.textField(`Descricao da loja (opcional, max ${LIMITE_DESC_LOJA} caracteres)`, "Uma frase curta sobre a loja");

	modal.show(player).then((res) => {
		if (res.canceled) {
			abrirLoja(player);
			return;
		}

		const nome = (res.formValues[0] ?? "").trim();
		const descricao = (res.formValues[1] ?? "").trim();

		criarLoja(player, nome, descricao);
		abrirLoja(player);
	});
}

// ===== MINHA LOJA (gerenciar itens) =====

function abrirGerenciarLoja(player) {
	const loja = getLoja(player.id);
	if (!loja) {
		abrirLoja(player);
		return;
	}

	const corpo =
		loja.itens.length > 0
			? `§7${loja.descricao || "Sem descricao."}\n\n§fToque num item para remover ou alterar o preco:`
			: `§7${loja.descricao || "Sem descricao."}\n\n§eVoce ainda nao colocou nenhum item a venda.`;

	const form = new ActionFormData().title(loja.nome).body(corpo);
	loja.itens.forEach((item) => form.button(`${item.nome} x${item.quantidade}\n§7${item.precoUnitario} moedas cada`, ICONE_ITEM));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < loja.itens.length) {
			abrirGerenciarItem(player, loja.itens[res.selection].id);
			return;
		}
		abrirLoja(player);
	});
}

function abrirGerenciarItem(player, itemId) {
	const loja = getLoja(player.id);
	const item = loja?.itens.find((i) => i.id === itemId);
	if (!item) {
		abrirGerenciarLoja(player);
		return;
	}

	const form = new ActionFormData()
		.title(item.nome)
		.body(`§7${item.descricao || "Sem descricao."}\n\n§fQuantidade: §e${item.quantidade}\n§fPreco: §e${item.precoUnitario} moedas cada`)
		.button("Alterar Preco", ICONE_PRECO)
		.button("Remover da Loja", ICONE_REMOVER)
		.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection === 0) {
			abrirFormAlterarPreco(player, itemId);
			return;
		}
		if (res.selection === 1) {
			removerItemComDevolucao(player, itemId);
			return;
		}
		abrirGerenciarLoja(player);
	});
}

function abrirFormAlterarPreco(player, itemId) {
	const loja = getLoja(player.id);
	const item = loja?.itens.find((i) => i.id === itemId);
	if (!item) {
		abrirGerenciarLoja(player);
		return;
	}

	const modal = new ModalFormData()
		.title("Alterar Preco")
		.textField("Novo preco (por unidade)", "Ex: 10", { defaultValue: String(item.precoUnitario) });

	modal.show(player).then((res) => {
		if (res.canceled) {
			abrirGerenciarItem(player, itemId);
			return;
		}

		const novoPreco = Math.floor(Number(res.formValues[0]));
		if (!Number.isFinite(novoPreco) || novoPreco <= 0 || novoPreco > PRECO_MAXIMO) {
			player.sendMessage("§cDigite um preco valido.");
			abrirGerenciarItem(player, itemId);
			return;
		}

		alterarPrecoItem(player.id, itemId, novoPreco);
		player.sendMessage(`§aPreco de §e${item.nome}§a atualizado para §e${novoPreco} moedas cada§a.`);
		abrirGerenciarLoja(player);
	});
}

function removerItemComDevolucao(player, itemId) {
	const loja = getLoja(player.id);
	const item = loja?.itens.find((i) => i.id === itemId);
	if (!item) {
		abrirGerenciarLoja(player);
		return;
	}

	confirmar(
		player,
		"Remover Item",
		`Remover §e${item.nome} x${item.quantidade}§r da loja e devolver pro seu inventario?`,
		() => {
			const inventory = player.getComponent("minecraft:inventory")?.container;
			if (!inventory) {
				player.sendMessage("§cNao foi possivel acessar seu inventario.");
				abrirGerenciarLoja(player);
				return;
			}

			try {
				inventory.addItem(new ItemStack(item.itemId, item.quantidade));
			} catch (erro) {
				player.sendMessage("§cSeu inventario esta cheio. Abra espaco e tente de novo.");
				console.warn(`Erro ao devolver item removido da loja: ${erro}`);
				abrirGerenciarLoja(player);
				return;
			}

			removerItemDaLoja(player.id, itemId);
			player.sendMessage(`§aVoce removeu §e${item.nome} x${item.quantidade}§a da loja.`);
			abrirGerenciarLoja(player);
		},
		() => abrirGerenciarItem(player, itemId)
	);
}

// ===== VENDER ITEM =====

function abrirVenderItem(player) {
	const loja = getLoja(player.id);
	if (!loja) {
		player.sendMessage("§cVoce precisa criar uma loja antes de vender itens. Abra a Loja e escolha §eCriar Loja§c.");
		abrirLoja(player);
		return;
	}

	const inventory = player.getComponent("minecraft:inventory")?.container;
	if (!inventory) {
		player.sendMessage("§cNao foi possivel acessar seu inventario.");
		return;
	}

	const slots = [];
	for (let i = 0; i < inventory.size; i++) {
		const stack = inventory.getItem(i);
		if (stack) slots.push({ slot: i, stack });
	}

	if (slots.length === 0) {
		player.sendMessage("§eVoce nao tem nenhum item no inventario para vender.");
		abrirLoja(player);
		return;
	}

	const form = new ActionFormData().title("Vender Item").body("Selecione o item que deseja colocar a venda na sua loja:");
	slots.forEach(({ stack }) => form.button(`${stack.nameTag ?? formatarNomeItem(stack.typeId)} x${stack.amount}`, ICONE_ITEM));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < slots.length) {
			abrirFormVenderItem(player, slots[res.selection].slot);
			return;
		}
		abrirLoja(player);
	});
}

function abrirFormVenderItem(player, slotIndex) {
	const inventory = player.getComponent("minecraft:inventory")?.container;
	const stack = inventory?.getItem(slotIndex);
	if (!stack) {
		abrirVenderItem(player);
		return;
	}

	const nomePadrao = stack.nameTag ?? formatarNomeItem(stack.typeId);

	const modal = new ModalFormData()
		.title("Vender Item")
		.textField("Nome do item", "Ex: Espada Encantada", { defaultValue: nomePadrao })
		.textField("Preco por unidade", "Ex: 10")
		.textField(`Descricao do item (opcional, max ${LIMITE_DESC_ITEM} caracteres)`, "Uma frase curta sobre o item");

	modal.show(player).then((res) => {
		if (res.canceled) {
			abrirVenderItem(player);
			return;
		}

		const nome = (res.formValues[0] ?? "").trim() || nomePadrao;
		const preco = Math.floor(Number(res.formValues[1]));
		const descricao = (res.formValues[2] ?? "").trim();

		if (nome.length > LIMITE_NOME_ITEM) {
			player.sendMessage(`§cO nome do item deve ter no maximo ${LIMITE_NOME_ITEM} letras.`);
			abrirVenderItem(player);
			return;
		}
		if (!Number.isFinite(preco) || preco <= 0 || preco > PRECO_MAXIMO) {
			player.sendMessage("§cDigite um preco valido.");
			abrirVenderItem(player);
			return;
		}
		if (descricao.length > LIMITE_DESC_ITEM) {
			player.sendMessage(`§cA descricao deve ter no maximo ${LIMITE_DESC_ITEM} caracteres.`);
			abrirVenderItem(player);
			return;
		}

		// Confere de novo se o item ainda esta no slot - o jogador pode ter
		// mexido no inventario enquanto preenchia o formulario.
		const inventoryAtual = player.getComponent("minecraft:inventory")?.container;
		const stackAtual = inventoryAtual?.getItem(slotIndex);
		if (!stackAtual) {
			player.sendMessage("§cEsse item nao esta mais no seu inventario.");
			abrirVenderItem(player);
			return;
		}

		const quantidade = stackAtual.amount;
		const itemId = stackAtual.typeId;
		inventoryAtual.setItem(slotIndex, undefined);

		const sucesso = adicionarItemNaLoja(player.id, {
			id: gerarIdItem(),
			itemId,
			nome,
			descricao,
			precoUnitario: preco,
			quantidade
		});

		if (!sucesso) {
			// Loja sumiu enquanto o jogador preenchia o formulario (bem raro) - devolve o item.
			inventoryAtual.addItem(new ItemStack(itemId, quantidade));
			player.sendMessage("§cVoce precisa ter uma loja para vender itens.");
			abrirLoja(player);
			return;
		}

		player.sendMessage(`§aVoce colocou §e${nome} x${quantidade}§a a venda por §e${preco} moedas cada§a.`);
		abrirLoja(player);
	});
}

// ===== COMPRAR ITEM =====

function abrirComprarItem(player) {
	const lojas = Object.values(getLojas()).filter((loja) => loja.dono !== player.id && loja.itens.length > 0);

	if (lojas.length === 0) {
		player.sendMessage("§eNenhuma loja com itens a venda no momento.");
		abrirLoja(player);
		return;
	}

	const form = new ActionFormData().title("Comprar Item").body("Selecione uma loja para ver os itens a venda:");
	lojas.forEach((loja) => form.button(`${loja.nome}\n§7Dono: ${nomeAtualDoDono(loja)} - ${loja.itens.length} item(s)`, ICONE_SHOP));
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < lojas.length) {
			abrirLojaDetalhe(player, lojas[res.selection].dono);
			return;
		}
		abrirLoja(player);
	});
}

function abrirLojaDetalhe(player, donoId) {
	const loja = getLoja(donoId);
	if (!loja || loja.itens.length === 0) {
		player.sendMessage("§eEssa loja nao tem mais itens a venda.");
		abrirComprarItem(player);
		return;
	}

	const form = new ActionFormData()
		.title(loja.nome)
		.body(
			`§7Dono: §f${nomeAtualDoDono(loja)}\n§7${loja.descricao || "Sem descricao."}\n\n§aSeu saldo: §e${getSaldo(player)} moedas`
		);
	loja.itens.forEach((item) =>
		form.button(`${item.nome} x${item.quantidade}\n§7${item.precoUnitario * item.quantidade} moedas no total`, ICONE_ITEM)
	);
	form.button("Voltar", ICONE_VOLTAR);

	form.show(player).then((res) => {
		if (res.canceled) return;
		if (res.selection < loja.itens.length) {
			abrirConfirmarCompra(player, donoId, loja.itens[res.selection].id);
			return;
		}
		abrirComprarItem(player);
	});
}

function abrirConfirmarCompra(player, donoId, itemId) {
	const loja = getLoja(donoId);
	const item = loja?.itens.find((i) => i.id === itemId);
	if (!item) {
		abrirComprarItem(player);
		return;
	}

	const total = item.precoUnitario * item.quantidade;

	confirmar(
		player,
		"Confirmar Compra",
		`Comprar §e${item.nome} x${item.quantidade}§r por §e${total} moedas§r?${item.descricao ? `\n§7${item.descricao}` : ""}`,
		() => comprarItemDaLoja(player, donoId, itemId),
		() => abrirLojaDetalhe(player, donoId)
	);
}

function comprarItemDaLoja(player, donoId, itemId) {
	const loja = getLoja(donoId);
	const item = loja?.itens.find((i) => i.id === itemId);
	if (!item) {
		player.sendMessage("§cEsse item nao esta mais a venda.");
		abrirComprarItem(player);
		return;
	}

	const total = item.precoUnitario * item.quantidade;
	const saldo = getSaldo(player);
	if (saldo < total) {
		player.sendMessage(`§cVoce nao tem moedas suficientes. §7(Voce tem ${saldo}, precisa de ${total})`);
		abrirLojaDetalhe(player, donoId);
		return;
	}

	const inventory = player.getComponent("minecraft:inventory")?.container;
	if (!inventory) {
		player.sendMessage("§cNao foi possivel acessar seu inventario.");
		return;
	}

	try {
		inventory.addItem(new ItemStack(item.itemId, item.quantidade));
	} catch (erro) {
		player.sendMessage("§cSeu inventario esta cheio. Abra espaco e tente de novo.");
		console.warn(`Erro ao entregar item comprado na loja: ${erro}`);
		abrirLojaDetalhe(player, donoId);
		return;
	}

	const removido = removerItemDaLoja(donoId, itemId);
	if (!removido) {
		player.sendMessage("§cEsse item acabou de ser vendido pra outro jogador.");
		return;
	}

	adicionarSaldo(player, -total);

	const vendedorOnline = world.getAllPlayers().find((p) => p.id === donoId);
	if (vendedorOnline) {
		adicionarSaldo(vendedorOnline, total);
		vendedorOnline.sendMessage(`§aVoce vendeu §e${item.nome} x${item.quantidade}§a para §e${player.name}§a por §e${total} moedas§a.`);
	} else {
		// Dono offline: credita mesmo assim (adicionarSaldo so precisa do id).
		adicionarSaldo({ id: donoId }, total);
	}

	player.sendMessage(`§aVoce comprou §e${item.nome} x${item.quantidade}§a por §e${total} moedas§a.`);
	abrirComprarItem(player);
}
