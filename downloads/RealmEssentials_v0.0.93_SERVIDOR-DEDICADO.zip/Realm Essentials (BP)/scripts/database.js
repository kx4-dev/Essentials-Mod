import { world } from "@minecraft/server";

// Cache em memoria pra evitar reler e reparsear o JSON dos dynamic
// properties toda hora (a nametag, por exemplo, le isso varias vezes por
// segundo pra cada jogador online).
const cache = new Map();

// Le um valor salvo no mundo (sempre um JSON).
export function getData(key, fallback) {
	if (cache.has(key)) return cache.get(key);

	const raw = world.getDynamicProperty(key);
	if (typeof raw !== "string") {
		cache.set(key, fallback);
		return fallback;
	}
	try {
		const valor = JSON.parse(raw);
		cache.set(key, valor);
		return valor;
	} catch {
		cache.set(key, fallback);
		return fallback;
	}
}

// Quem quiser ser avisado quando um salvamento falhar (ex: o sistema de logs
// do Discord) se registra aqui. Fica nesse arquivo pra evitar import circular.
let aoFalharSalvar = null;

export function registrarAoFalharSalvar(funcao) {
	aoFalharSalvar = funcao;
}

// Salva um valor no mundo (sempre como JSON). O Minecraft tem um limite de
// tamanho por chave (uns 32KB). Se estourar, o valor continua valendo na
// memória (a sessão segue normal), mas NÃO é gravado: ao reiniciar o servidor
// o dado volta pra versão antiga. Por isso o erro agora é avisado de verdade
// (console + logs do Discord) em vez de passar batido.
export function setData(key, value) {
	cache.set(key, value);
	try {
		world.setDynamicProperty(key, JSON.stringify(value));
		return true;
	} catch (erro) {
		console.warn(`Erro ao salvar dado "${key}" (pode ter estourado o limite de tamanho): ${erro}`);
		try {
			aoFalharSalvar?.(key, erro);
		} catch {
			// avisar não pode derrubar o salvamento
		}
		return false;
	}
}

// Guarda um registro { id -> nome } de todo jogador que ja entrou no mundo.
// Usado pros "Top" (abates, saldo, etc.) conseguirem listar gente offline.
const KEY_JOGADORES_CONHECIDOS = "re:jogadores_conhecidos";

export function registrarJogadorConhecido(player) {
	const mapa = getData(KEY_JOGADORES_CONHECIDOS, {});
	if (mapa[player.id] === player.name) return; // ja esta atualizado, nao precisa salvar de novo
	mapa[player.id] = player.name;
	setData(KEY_JOGADORES_CONHECIDOS, mapa);
}

export function getJogadoresConhecidos() {
	return getData(KEY_JOGADORES_CONHECIDOS, {});
}
