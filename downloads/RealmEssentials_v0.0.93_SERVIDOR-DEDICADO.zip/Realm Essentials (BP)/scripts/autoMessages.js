import { world } from "@minecraft/server";
import { getData, setData } from "./database.js";
import { SONS } from "./sounds.js";

const KEY_CONFIG = "re:automsg:config";
const KEY_MENSAGENS = "re:automsg:mensagens";
const LIMITE_MENSAGENS = 50;

function configPadrao() {
	return {
		ativo: false,
		intervaloMinutos: 30,
		som: "",
		ultimoEnvioMs: 0
	};
}

export function getConfigAuto() {
	return { ...configPadrao(), ...getData(KEY_CONFIG, {}) };
}

function saveConfigAuto(config) {
	setData(KEY_CONFIG, config);
}

export function getMensagens() {
	return getData(KEY_MENSAGENS, []);
}

function saveMensagens(mensagens) {
	setData(KEY_MENSAGENS, mensagens);
}

export function adicionarMensagem(texto) {
	texto = (texto ?? "").trim();
	if (!texto) return false;

	const mensagens = getMensagens();
	if (mensagens.length >= LIMITE_MENSAGENS) return false;

	mensagens.push(texto);
	saveMensagens(mensagens);
	return true;
}

export function removerMensagem(indice) {
	const mensagens = getMensagens();
	if (indice < 0 || indice >= mensagens.length) return false;

	mensagens.splice(indice, 1);
	saveMensagens(mensagens);
	return true;
}

export function definirAtivo(ativo) {
	const config = getConfigAuto();
	config.ativo = !!ativo;
	saveConfigAuto(config);
}

export function definirIntervaloMinutos(minutos) {
	const numero = Math.floor(Number(minutos));
	if (!Number.isFinite(numero) || numero < 1) return false;
	const config = getConfigAuto();
	config.intervaloMinutos = Math.min(1440, numero); // ate 24h
	saveConfigAuto(config);
	return true;
}

// Agora recebe a CHAVE do som (ex: "xp", "levelUp"), escolhida no dropdown -
// nao precisa mais digitar o id tecnico. "" continua sendo "sem som".
export function definirSom(somChave) {
	const chave = (somChave ?? "").trim();
	if (chave && !SONS[chave]) return;
	const config = getConfigAuto();
	config.som = chave;
	saveConfigAuto(config);
}

// Lista de sons prontos (nome em portugues) pra usar no dropdown do menu -
// antes disso o dono tinha que digitar o id tecnico do som na mao (ex:
// "random.levelup"), agora e so escolher da lista.
export function getSonsDisponiveis() {
	return Object.keys(SONS);
}

// Chamado periodicamente (ex: uma vez por segundo). Ve se ja passou o
// intervalo configurado desde o ultimo envio e, se sim, manda a proxima
// mensagem da lista pra todo mundo (com som, se tiver um definido).
export function tickAutoMensagens() {
	const config = getConfigAuto();
	if (!config.ativo) return;

	const mensagens = getMensagens();
	if (mensagens.length === 0) return;

	const agora = Date.now();
	const intervaloMs = config.intervaloMinutos * 60 * 1000;
	if (agora - config.ultimoEnvioMs < intervaloMs) return;

	const indice = Math.floor(Math.random() * mensagens.length);
	world.sendMessage(mensagens[indice]);

	if (config.som) {
		// SONS[chave] cobre quem escolheu pelo dropdown novo; o "?? config.som"
		// mantem funcionando pra quem ja tinha um id digitado manualmente antes.
		const idDoSom = SONS[config.som] ?? config.som;
		world.getAllPlayers().forEach((p) => {
			try {
				p.playSound(idDoSom);
			} catch (erro) {
				console.warn(`Erro ao tocar som da mensagem automatica: ${erro}`);
			}
		});
	}

	config.ultimoEnvioMs = agora;
	saveConfigAuto(config);
}
