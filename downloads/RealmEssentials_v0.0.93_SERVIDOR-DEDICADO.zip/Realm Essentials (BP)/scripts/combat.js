import { getData, setData, getJogadoresConhecidos } from "./database.js";
import { getPermissoes } from "./rank.js";

const golpes = {};

// Guarda o golpe e o abate mais recentes de qualquer jogador do servidor -
// usado no scoreboard pra mostrar "quem bateu agora" em vez de um recorde
// historico. Fica so na memoria (nao precisa sobreviver a um reinicio).
let ultimoGolpe = null; // { nome, cps, quando }
let ultimoAbate = null; // { nome, total, quando }

// Depois desse tempo sem ninguem bater/matar, a linha "ao vivo" do
// scoreboard some de vez (em vez de ficar mostrando o ultimo valor parado).
const VALIDADE_MS = 3000;

export function getUltimoGolpe() {
	if (!ultimoGolpe || Date.now() - ultimoGolpe.quando > VALIDADE_MS) return null;
	return ultimoGolpe;
}

export function getUltimoAbate() {
	if (!ultimoAbate || Date.now() - ultimoAbate.quando > VALIDADE_MS) return null;
	return ultimoAbate;
}

function keyRecordeCps(playerId) {
	return `re:recordecps:${playerId}`;
}

export function registrarGolpe(playerId, nome) {
	const agora = Date.now();
	const lista = (golpes[playerId] ?? []).filter((t) => agora - t <= 1000);
	lista.push(agora);
	golpes[playerId] = lista;

	// Atualiza o recorde de CPS do jogador se ele bateu um novo maximo.
	if (lista.length > getRecordeCps(playerId)) {
		setData(keyRecordeCps(playerId), lista.length);
	}

	ultimoGolpe = { nome: nome ?? "?", cps: lista.length, quando: agora };
}

export function getCps(playerId) {
	const agora = Date.now();
	const lista = (golpes[playerId] ?? []).filter((t) => agora - t <= 1000);
	golpes[playerId] = lista;
	return lista.length;
}

// Maior CPS que o jogador ja fez (fica salvo, nao reseta como o CPS atual).
export function getRecordeCps(playerId) {
	return getData(keyRecordeCps(playerId), 0);
}

// Lista os N jogadores com maior recorde de CPS (inclui quem ta offline).
export function getTopRecordeCps(limite = 10) {
	const jogadores = getJogadoresConhecidos();
	return Object.entries(jogadores)
		.map(([id, nome]) => ({ nome, valor: getData(keyRecordeCps(id), 0) }))
		.filter((j) => j.valor > 0)
		.sort((a, b) => b.valor - a.valor)
		.slice(0, limite);
}

function corDoCps(cps) {
	if (cps <= 0) return "§7";
	if (cps < 5) return "§a";
	if (cps < 8) return "§2";
	if (cps < 10) return "§6";
	if (cps < 14) return "§c";
	if (cps < 20) return "§4";
	return "§4§l";
}

function key(player) {
	return `re:abates:${player.id}`;
}

export function getAbates(player) {
	return getData(key(player), 0);
}

export function adicionarAbate(player) {
	const limite = getPermissoes(player).limiteAbates;
	const atual = getAbates(player);
	if (atual >= limite) return;
	setData(key(player), atual + 1);
	ultimoAbate = { nome: player.name, total: atual + 1, quando: Date.now() };
}

// Lista os N jogadores com mais abates (inclui quem ta offline).
export function getTopAbates(limite = 10) {
	const jogadores = getJogadoresConhecidos();
	return Object.entries(jogadores)
		.map(([id, nome]) => ({ nome, valor: getData(`re:abates:${id}`, 0) }))
		.filter((j) => j.valor > 0)
		.sort((a, b) => b.valor - a.valor)
		.slice(0, limite);
}

// Soma os abates de todo mundo que ja passou pelo servidor - usado no
// scoreboard, que so pode mostrar um numero geral (nao um por jogador).
export function getTotalAbates() {
	const jogadores = getJogadoresConhecidos();
	return Object.keys(jogadores).reduce((soma, id) => soma + getData(`re:abates:${id}`, 0), 0);
}

// Combo: golpes seguidos num alvo, sem passar 3s entre um e outro. Se o
// jogador levar dano de alguem, o combo zera (igual em servidor de pvp).
const COMBO_TIMEOUT_MS = 3000;
const combos = {};

export function registrarComboGolpe(playerId) {
	const agora = Date.now();
	const estado = combos[playerId];
	if (estado && agora - estado.ultimoGolpe <= COMBO_TIMEOUT_MS) {
		estado.contagem++;
		estado.ultimoGolpe = agora;
	} else {
		combos[playerId] = { contagem: 1, ultimoGolpe: agora };
	}
}

export function getCombo(playerId) {
	const estado = combos[playerId];
	if (!estado) return 0;
	if (Date.now() - estado.ultimoGolpe > COMBO_TIMEOUT_MS) return 0;
	return estado.contagem;
}

export function resetarCombo(playerId) {
	delete combos[playerId];
}

const NOMES_PLATAFORMA = { Desktop: "PC", Mobile: "Celular", Console: "Console" };

// Cada uma dessas monta 1 linha pra nametag (ou pra hotbar). Cada modelo e
// independente - o dono escolhe quais ficam ligados em Configuracao.
export function getLinhaCps(player) {
	const cps = getCps(player.id);
	const textoCps = cps > 100 ? "100+" : `${cps}`;
	return `§fcps: ${corDoCps(cps)}${textoCps}§r`;
}

export function getLinhaAbates(player) {
	return `§fabates: §c${getAbates(player)}§r`;
}

export function getLinhaVida(player) {
	try {
		const health = player.getComponent("minecraft:health");
		const atual = Math.ceil(health?.currentValue ?? 0);
		const max = Math.ceil(health?.effectiveMax ?? 20);
		return `§c♥ ${atual}§7/${max}§r`;
	} catch {
		return "§c♥ §7?§r";
	}
}

export function getLinhaCombo(player) {
	return `§fcombo: §e${getCombo(player.id)}§r`;
}

export function getLinhaPlataforma(player) {
	try {
		const tipo = player.clientSystemInfo?.platformType;
		return `§fplataforma: §b${NOMES_PLATAFORMA[tipo] ?? "Desconhecida"}§r`;
	} catch {
		return "§fplataforma: §7?§r";
	}
}
